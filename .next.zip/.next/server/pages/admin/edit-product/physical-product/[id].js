"use strict";
(() => {
var exports = {};
exports.id = 7116;
exports.ids = [7116];
exports.modules = {

/***/ 25213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Product),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(46555);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var danfojs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16607);
/* harmony import */ var danfojs__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(danfojs__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45641);
/* harmony import */ var _layouts_Layout_Layout__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(93019);
/* harmony import */ var _components_admin_ui_ButtonSaveProgress__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(11773);
/* harmony import */ var _components_admin_products_add_product_AddFeatures__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(75217);
/* harmony import */ var _components_admin_products_add_product_UploadImage__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(8923);
/* harmony import */ var _components_admin_products_add_product_ProductStatus__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(63751);
/* harmony import */ var _components_admin_products_add_product_Pricing__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(94180);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_admin_products_add_product_ChooseCategories__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(58226);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(15612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71507);
/* harmony import */ var _mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(28742);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(21598);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(36042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(55374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(76563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(88185);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _components_admin_products_add_product_DigitalFileUpload__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(96932);
/* harmony import */ var _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(21292);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(73142);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(817);
/* harmony import */ var _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(18638);
/* harmony import */ var _mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(68383);
/* harmony import */ var _mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_21__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_22__, _layouts_Layout_Layout__WEBPACK_IMPORTED_MODULE_23__, _components_admin_products_add_product_AddFeatures__WEBPACK_IMPORTED_MODULE_29__]);
([uuid__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_7__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_22__, _layouts_Layout_Layout__WEBPACK_IMPORTED_MODULE_23__, _components_admin_products_add_product_AddFeatures__WEBPACK_IMPORTED_MODULE_29__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


































function Product({ product  }) {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { redirect  } = router.query;
    const { enqueueSnackbar , closeSnackbar  } = (0,notistack__WEBPACK_IMPORTED_MODULE_20__.useSnackbar)();
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_22__/* .AdminDataStore */ .p);
    const { adminStoreInfo  } = state;
    const { handleSubmit , control , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_7__.useForm)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!adminStoreInfo) {
            router.push("/admin/login");
        }
    // async function fetch() {
    //     const productsData = await axios.post('/api/admin/products/get-all', { storeID: adminStoreInfo._id })
    //     const df = new dfd.DataFrame(productsData.data)
    // }
    // fetch()
    }, [
        router,
        adminStoreInfo
    ]);
    function slugify(string) {
        return string.toString().trim().toLowerCase().replace(/\s+/g, "-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "");
    }
    const { 0: image , 1: setImage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.images[0]?.url);
    const { 0: imageAlt1 , 1: setImageAlt  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.images[0]?.altText);
    const { 0: document , 1: setDocument  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.document);
    const { 0: descriptionHtml1 , 1: setDescription  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.descriptionHtml);
    const { 0: type , 1: setType  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("physical");
    const { 0: options , 1: setOptions  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.options);
    const { 0: categories , 1: setCategories  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.categories);
    const { 0: reviews , 1: setReviews  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.reviews);
    const { 0: features , 1: setFeatures  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.features);
    const { 0: isFeatured , 1: setIsFeatured  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.isFeatured);
    const { 0: isDeleted , 1: setIsDeleted  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.isDeleted);
    const { 0: rating , 1: setRating  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.rating);
    const { 0: status , 1: setStatus  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.status);
    const { 0: size , 1: setSize  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(product.size);
    const { 0: price , 1: setPrice  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        value: product.price?.value,
        currencyCode: "INR",
        comparePrice: product.price?.comparePrice,
        costPerItem: product.price?.costPerItem,
        listPrice: product.price?.listPrice
    });
    // const [inventory, setInventory] = useState("");
    // const [vendor, setVendor] = useState("");
    // const [sku, setSKU] = useState("");
    // const [barcode, setBarcode] = useState("");
    const submitHandler = async ({ name , descriptionHtml , imageAlt , image , vendor , sku , barcode , inventory  })=>{
        closeSnackbar();
        try {
            setButtonProgressLoading(true);
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_4___default().post("/api/admin/products/edit/physical", {
                productID: product._id,
                storeID: adminStoreInfo._id,
                name: name,
                vendor: vendor,
                slug: slugify(name),
                price: price,
                listPrice: price.listPrice,
                descriptionHtml: descriptionHtml,
                images: product.images[0] ? [
                    {
                        url: `${product.images[0]?.url}`,
                        altText: imageAlt
                    }
                ] : null,
                documents: document ? [
                    `/${document.name}`
                ] : null,
                variants: [],
                options: options,
                status: status,
                isFeatured: isFeatured,
                isDeleted: isDeleted,
                type: type,
                categories: categories,
                features: features,
                reviews: reviews,
                rating: rating,
                sku: sku,
                barcode: barcode,
                inventory: inventory,
                size: size
            });
            if (data.code == "exists") {
                enqueueSnackbar(" Name/SKU/Barcode Already Exists", {
                    variant: "error"
                });
            } else {
                setButtonProgressLoading(false);
                enqueueSnackbar("Successfully Updated", {
                    variant: "success"
                });
                router.push(redirect || "/admin/edit-product");
            }
            setButtonProgressLoading(false);
        } catch (err) {
            enqueueSnackbar(err, {
                variant: "error"
            });
        }
    };
    const discard = ()=>{
        router.push("/admin/products");
    };
    const { 0: featureFields , 1: setFeatureFields  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        {
            id: (0,uuid__WEBPACK_IMPORTED_MODULE_3__.v4)(),
            name: "",
            value: ""
        }, 
    ]);
    const [buttonProgressLoading, setButtonProgressLoading] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_layouts_Layout_Layout__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
            onSubmit: handleSubmit(submitHandler),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                container: true,
                justifyContent: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 2,
                            lg: 1
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 7,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Product Information"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "name",
                                control: control,
                                defaultValue: product?.name,
                                rules: {
                                    required: true,
                                    minLength: 2
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "Name",
                                        inputProps: {
                                            type: "text"
                                        },
                                        error: Boolean(errors.name),
                                        helperText: errors.name ? errors.name.type === "minLength" ? "Name can not be less than 3 charactes" : "Name is required" : "",
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                component: "p",
                                children: "Description"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "descriptionHtml",
                                control: control,
                                defaultValue: product?.descriptionHtml,
                                rules: {
                                    required: true,
                                    minLength: 2
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextareaAutosize__WEBPACK_IMPORTED_MODULE_21___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "Description",
                                        inputProps: {
                                            type: "text"
                                        },
                                        error: Boolean(errors.descriptionHtml),
                                        helperText: errors.description ? errors.descriptionHtml.type === "minLength" ? "Description can not be less than 3 charactes" : "Description is required" : "",
                                        ...field
                                    })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 1,
                            lg: 2
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 4,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Stack__WEBPACK_IMPORTED_MODULE_11___default()), {
                                sx: {
                                    mb: 3
                                },
                                spacing: 2,
                                direction: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_12___default()), {
                                        onClick: ()=>discard()
                                        ,
                                        variant: "outlined",
                                        children: "Discard"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_ui_ButtonSaveProgress__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                        text: "Save",
                                        size: "md",
                                        buttonProgressLoading: buttonProgressLoading,
                                        setButtonProgressLoading: setButtonProgressLoading
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_ProductStatus__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                status: status,
                                setStatus: setStatus
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                sx: {
                                    my: 1
                                },
                                component: "p",
                                fontSize: 13,
                                children: "This product will be hidden from all sales channels."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 3
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 7,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Pricing"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_Pricing__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                                price: price,
                                setPrice: setPrice,
                                control: control,
                                errors: errors
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                sx: {
                                    mt: 3
                                },
                                fontWeight: 700,
                                component: "p",
                                children: "Categories"
                            }),
                            adminStoreInfo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: adminStoreInfo.categories ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_ChooseCategories__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z, {
                                    categories: adminStoreInfo.categories
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                            component: "p",
                                            children: "No Category Found"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                                            href: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                    "aria-label": "delete",
                                                    size: "small",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                        fontSize: "inherit"
                                                    })
                                                })
                                            })
                                        })
                                    ]
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 4
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 4,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Media"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                                sx: {
                                    width: "100%"
                                },
                                container: true,
                                justifyContent: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_UploadImage__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                                        image: image,
                                        setImage: setImage
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                        name: "imageAlt",
                                        control: control,
                                        defaultValue: product?.images[0].altText,
                                        rules: {
                                            required: true,
                                            minLength: 2
                                        },
                                        render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                variant: "outlined",
                                                fullWidth: true,
                                                id: "",
                                                label: "Image Alt",
                                                inputProps: {
                                                    type: "text"
                                                },
                                                error: Boolean(errors.imageAlt),
                                                helperText: errors.imageAlt ? errors.imageAlt.type === "minLength" ? "Image Alt can not be less than 3 charactes" : "Image Alt is required" : "",
                                                ...field
                                            })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 5
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 7,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Inventory"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "sku",
                                control: control,
                                defaultValue: product?.sku,
                                rules: {
                                    required: true
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "SKU",
                                        inputProps: {
                                            type: "text"
                                        },
                                        error: Boolean(errors.sku),
                                        helperText: errors.sku ? "SKU is required" : "",
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "barcode",
                                control: control,
                                defaultValue: product?.barcode,
                                rules: {
                                    required: true
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "Barcode",
                                        inputProps: {
                                            type: "text"
                                        },
                                        error: Boolean(errors.barcode),
                                        helperText: errors.barcode ? "Barcode is required" : "",
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                required: true,
                                sx: {
                                    my: 1
                                },
                                component: "p",
                                fontSize: 13,
                                children: "Quantity"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "inventory",
                                control: control,
                                defaultValue: product?.inventory,
                                rules: {
                                    required: true
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "Inventory",
                                        inputProps: {
                                            type: "number"
                                        },
                                        error: Boolean(errors.inventory),
                                        helperText: errors.inventory ? "Inventory is required" : "",
                                        ...field
                                    })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                required: true,
                                sx: {
                                    my: 1
                                },
                                component: "p",
                                fontSize: 13,
                                children: "Vendor Name"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_7__.Controller, {
                                name: "vendor",
                                control: control,
                                defaultValue: product?.vendor,
                                rules: {
                                    required: true
                                },
                                render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        variant: "outlined",
                                        fullWidth: true,
                                        id: "",
                                        label: "Vendor",
                                        inputProps: {
                                            type: "text"
                                        },
                                        error: Boolean(errors.vendor),
                                        helperText: errors.vendor ? "Vendor is required" : "",
                                        ...field
                                    })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 6
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 4,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Features & Options"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_AddFeatures__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z, {
                                featureFields: featureFields,
                                setFeatureFields: setFeatureFields
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 7
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 7,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                                variant: "h6",
                                fontWeight: 700,
                                component: "p",
                                children: "Documents"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_products_add_product_DigitalFileUpload__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z, {
                                document: document,
                                setDocument: setDocument
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_9___default()), {
                        order: {
                            xs: 8
                        },
                        item: true,
                        component: (_mui_material_Paper__WEBPACK_IMPORTED_MODULE_13___default()),
                        lg: 4,
                        xs: 12,
                        sx: {
                            p: 3,
                            m: 1
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_14___default()), {
                            variant: "h6",
                            fontWeight: 700,
                            component: "p",
                            children: "Extra"
                        })
                    })
                ]
            })
        })
    });
};
async function getServerSideProps(ctx) {
    const { params  } = ctx;
    const { id  } = params;
    console.log(id);
    await _utils_db__WEBPACK_IMPORTED_MODULE_31__/* ["default"].connect */ .Z.connect();
    const product = await _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_32__/* ["default"].find */ .Z.find({
        _id: id
    }).lean();
    await _utils_db__WEBPACK_IMPORTED_MODULE_31__/* ["default"].disconnect */ .Z.disconnect();
    console.log(product);
    return {
        props: {
            product: product.map(_utils_db__WEBPACK_IMPORTED_MODULE_31__/* ["default"].convertDocToObj */ .Z.convertDocToObj)[0]
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 88930:
/***/ ((module) => {

module.exports = require("@chakra-ui/react");

/***/ }),

/***/ 86466:
/***/ ((module) => {

module.exports = require("@fortawesome/free-solid-svg-icons");

/***/ }),

/***/ 87197:
/***/ ((module) => {

module.exports = require("@fortawesome/react-fontawesome");

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 48308:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ 34628:
/***/ ((module) => {

module.exports = require("@material-ui/core/styles/colorManipulator");

/***/ }),

/***/ 72105:
/***/ ((module) => {

module.exports = require("@material-ui/icons");

/***/ }),

/***/ 43349:
/***/ ((module) => {

module.exports = require("@material-ui/styles");

/***/ }),

/***/ 71507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddCircleOutline");

/***/ }),

/***/ 1783:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckBox");

/***/ }),

/***/ 51779:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckBoxOutlineBlank");

/***/ }),

/***/ 53924:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CurrencyRupee");

/***/ }),

/***/ 48012:
/***/ ((module) => {

module.exports = require("@mui/icons-material/DeleteOutline");

/***/ }),

/***/ 89226:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Email");

/***/ }),

/***/ 34492:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Google");

/***/ }),

/***/ 65538:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Help");

/***/ }),

/***/ 10032:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 74502:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StoreMallDirectory");

/***/ }),

/***/ 58189:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SwitchAccount");

/***/ }),

/***/ 58551:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TravelExplore");

/***/ }),

/***/ 17608:
/***/ ((module) => {

module.exports = require("@mui/icons-material/VerifiedUser");

/***/ }),

/***/ 2311:
/***/ ((module) => {

module.exports = require("@mui/material/Autocomplete");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 53819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 58330:
/***/ ((module) => {

module.exports = require("@mui/material/Checkbox");

/***/ }),

/***/ 49048:
/***/ ((module) => {

module.exports = require("@mui/material/CircularProgress");

/***/ }),

/***/ 68891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 88185:
/***/ ((module) => {

module.exports = require("@mui/material/FormControlLabel");

/***/ }),

/***/ 76096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 15612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 67934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 33103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 60911:
/***/ ((module) => {

module.exports = require("@mui/material/InputLabel");

/***/ }),

/***/ 29271:
/***/ ((module) => {

module.exports = require("@mui/material/MenuItem");

/***/ }),

/***/ 37730:
/***/ ((module) => {

module.exports = require("@mui/material/OutlinedInput");

/***/ }),

/***/ 21598:
/***/ ((module) => {

module.exports = require("@mui/material/Paper");

/***/ }),

/***/ 55374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 76563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 42651:
/***/ ((module) => {

module.exports = require("@mui/material/Select");

/***/ }),

/***/ 28742:
/***/ ((module) => {

module.exports = require("@mui/material/Stack");

/***/ }),

/***/ 36042:
/***/ ((module) => {

module.exports = require("@mui/material/TextField");

/***/ }),

/***/ 68383:
/***/ ((module) => {

module.exports = require("@mui/material/TextareaAutosize");

/***/ }),

/***/ 27163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 72929:
/***/ ((module) => {

module.exports = require("@paypal/react-paypal-js");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 59003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 16607:
/***/ ((module) => {

module.exports = require("danfojs");

/***/ }),

/***/ 11185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 73142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 32680:
/***/ ((module) => {

module.exports = require("tinycolor2");

/***/ }),

/***/ 69915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 46555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9505,1664,5675,1292,3019,1773,817,8638,7770], () => (__webpack_exec__(25213)));
module.exports = __webpack_exports__;

})();