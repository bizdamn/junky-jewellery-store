"use strict";
(() => {
var exports = {};
exports.id = 3858;
exports.ids = [3858];
exports.modules = {

/***/ 3666:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 2953:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ customer)
});

;// CONCATENATED MODULE: ./framework/local/api/endpoints/customer/index.ts
function noopApi(...args) {};

// EXTERNAL MODULE: ./lib/api/commerce.ts + 13 modules
var commerce = __webpack_require__(9441);
;// CONCATENATED MODULE: ./pages/api/customer/index.ts


/* harmony default export */ const customer = (noopApi(commerce/* default */.Z));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9441], () => (__webpack_exec__(2953)));
module.exports = __webpack_exports__;

})();