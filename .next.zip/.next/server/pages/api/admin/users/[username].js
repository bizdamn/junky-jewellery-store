"use strict";
(() => {
var exports = {};
exports.id = 1590;
exports.ids = [1590];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 3853:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ userHandler)
/* harmony export */ });
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8989);


function userHandler(req, res) {
    const { query: { username  } , method ,  } = req;
    switch(method){
        case "GET":
            {
                return getUser(req, res);
            }
        case "PUT":
            {
                return updateUser(req, res);
            }
        default:
            res.setHeader("Allow", [
                "GET",
                "PUT"
            ]);
            res.status(405).end(`Method ${method} Not Allowed`);
    }
};
async function getUser(req, res) {
    const { query: { username  }  } = req;
    try {
        await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].connect */ .Z.connect();
        const users = await User.find({
            "username": username
        });
        await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].disconnect */ .Z.disconnect();
        // return the products
        return res.json({
            message: JSON.parse(JSON.stringify(users)),
            success: true
        });
    } catch (error) {
        // return the error
        return res.json({
            message: new Error(error).message,
            success: false
        });
    }
}
async function updateUser(req, res) {
    const { query: { username  }  } = req;
    try {
        await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].connect */ .Z.connect();
        const users = await User.updateMany({
            "username": username
        });
        user_data = {
            $set: {
                quantity: 500,
                details: {
                    model: "14Q3",
                    make: "xyz"
                },
                tags: [
                    "coats",
                    "outerwear",
                    "clothing"
                ]
            }
        };
        await _utils_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"].disconnect */ .Z.disconnect();
        // return the products
        return res.json({
            message: JSON.parse(JSON.stringify(users)),
            success: true
        });
    } catch (error) {
        // return the error
        return res.json({
            message: new Error(error).message,
            success: false
        });
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8989], () => (__webpack_exec__(3853)));
module.exports = __webpack_exports__;

})();