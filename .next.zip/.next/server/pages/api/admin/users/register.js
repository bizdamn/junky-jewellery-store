"use strict";
(() => {
var exports = {};
exports.id = 9671;
exports.ids = [9671];
exports.modules = {

/***/ 98432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 11185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 45616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 9544:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(45616);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(98432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _models_Store__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(34054);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(78989);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
function slugify(string) {
    return string.toString();
    slug.toLowerCase().replace(/\s+/g, "-").replace(/[^\w\-]+/g, "").replace(/\-\-+/g, "-").replace(/^-+/, "").replace(/-+$/, "");
}
handler.post(async (req, res)=>{
    // console.log({
    //   storeName: req.body.storeName,
    //   storeLink: `https://makemycommerce.in/${req.body.storeName}`,
    //   name: req.body.name,
    //   email: req.body.email,
    //   phone: req.body.phone,
    //   verified: false,
    //   plan: 'Basic',
    //   password: bcrypt.hashSync(req.body.password),
    //   companyName: req.body.companyName,
    //   title: 'My Online Store',
    //   metatitle: 'My Online Store',
    //   metadescription: 'My Online Store',
    //   address: {
    //     addressLine1: req.body.addressLine1,
    //     addressLine2: req.body.addressLine2,
    //     city: req.body.city,
    //     state: req.body.state,
    //     pinCode: req.body.pinCode,
    //     country: req.body.country,
    //   },
    //   storeDetails: {
    //     storeIndustry: req.body.storeIndustry,
    //     // storeAudience: { type: String, required: false },
    //     companyName: req.body.companyName,
    //   },
    //   paymentProviders: {
    //     CodAvailable: true,
    //     // razorpay: { type: Object, required: false },
    //   },
    //   checkout: {
    //     checkoutCustomerAccount: 'required',
    //     checkoutCustomerContact: 'phoneEmail',
    //     marketingConsent: {
    //       emailMarketingSubscribe: true,
    //       smsMarketingSubscribe: false,
    //     },
    //     formOptions: {
    //       lastName: 'hidden',
    //       companyName: 'hidden',
    //       addressLine2: 'hidden',
    //       shippingAddressPhone: 'hidden',
    //     },
    //     taxes: {
    //       allPricesIncludeTaxes: false,
    //       shippingRatesTax: false,
    //       digitalProductVAT: false,
    //     },
    //     policies: {
    //       RefundPolicyHtml: false,
    //       PrivacyPolicyHtml: false,
    //       ShippingPolicyHtml: false,
    //       TermsOfServiceHtml: false,
    //     },
    //   }
    // })
    try {
        await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].connect */ .Z.connect();
        const newStore = new _models_Store__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z({
            storeName: req.body.storeName,
            storeLink: `https://makemycommerce.in/${slugify(req.body.storeName)}`,
            name: req.body.name,
            email: req.body.email,
            phone: req.body.phone,
            verified: false,
            plan: "Basic",
            password: bcryptjs__WEBPACK_IMPORTED_MODULE_1___default().hashSync(req.body.password),
            companyName: req.body.companyName,
            title: "My Online Store",
            metatitle: "My Online Store",
            metadescription: "My Online Store",
            bio: "Write Bio about Your Company",
            address: {
                addressLine1: req.body.addressLine1,
                addressLine2: req.body.addressLine2,
                city: req.body.city,
                state: req.body.state,
                pinCode: req.body.pinCode,
                country: req.body.country
            },
            storeDetails: {
                storeIndustry: req.body.storeIndustry,
                // storeAudience: { type: String, required: false },
                companyName: req.body.companyName
            },
            paymentProviders: {
                CodAvailable: true
            },
            checkout: {
                checkoutCustomerAccount: "required",
                checkoutCustomerContact: "phoneEmail",
                marketingConsent: {
                    emailMarketingSubscribe: true,
                    smsMarketingSubscribe: false
                },
                formOptions: {
                    lastName: "hidden",
                    companyName: "hidden",
                    addressLine2: "hidden",
                    shippingAddressPhone: "hidden"
                },
                taxes: {
                    allPricesIncludeTaxes: false,
                    shippingRatesTax: false,
                    digitalProductVAT: false
                },
                policies: {
                    RefundPolicyHtml: false,
                    PrivacyPolicyHtml: false,
                    ShippingPolicyHtml: false,
                    TermsOfServiceHtml: false
                }
            }
        });
        const store = await newStore.save();
        await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].disconnect */ .Z.disconnect();
        res.send(store);
    } catch  {
        res.send({
            code: "exists",
            message: "Store Name Already Exist"
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8989,4054], () => (__webpack_exec__(9544)));
module.exports = __webpack_exports__;

})();