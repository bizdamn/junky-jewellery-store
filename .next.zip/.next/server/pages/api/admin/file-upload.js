"use strict";
(() => {
var exports = {};
exports.id = 3105;
exports.ids = [3105];
exports.modules = {

/***/ 22616:
/***/ ((module) => {

module.exports = require("formidable");

/***/ }),

/***/ 99932:
/***/ ((module) => {

module.exports = require("mv");

/***/ }),

/***/ 57147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 99976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "config": () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(22616);
/* harmony import */ var formidable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(formidable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(57147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_1__);


var mv = __webpack_require__(99932);
const config = {
    api: {
        bodyParser: false
    }
};
const FileUpload = async (req, res)=>{
    const data = await new Promise((resolve, reject)=>{
        const form = new formidable__WEBPACK_IMPORTED_MODULE_0__.IncomingForm();
        form.parse(req, (err, fields, files)=>{
            if (err) return reject(err);
            // console.log(fields, files)
            // console.log(files.file.filepath)
            var oldPath = files.file.filepath;
            var newPath = `./public/assets/${files.file.originalFilename}`;
            mv(oldPath, newPath, function(err) {});
            res.status(200).json({
                fields,
                files
            });
        });
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FileUpload);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(99976));
module.exports = __webpack_exports__;

})();