"use strict";
(() => {
var exports = {};
exports.id = 1217;
exports.ids = [1217];
exports.modules = {

/***/ 11185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 45616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 57053:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(45616);
/* harmony import */ var _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(56779);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(78989);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);
next_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
handler.post(async (req, res)=>{
    try {
        await _utils_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"].connect */ .Z.connect();
        const filter = {
            _id: req.body.productID
        };
        const update = {
            storeID: req.body.storeID,
            name: req.body.name,
            vendor: req.body.vendor,
            path: `/${req.body.slug}`,
            slug: req.body.slug,
            price: req.body.price,
            listPrice: req.body.listPrice,
            descriptionHtml: req.body.descriptionHtml,
            images: req.body.images,
            variants: req.body.variants,
            options: req.body.options,
            status: req.body.status,
            isFeatured: req.body.isFeatured,
            isDeleted: req.body.isDeleted,
            type: req.body.type,
            categories: req.body.categories,
            features: req.body.features,
            reviews: req.body.reviews,
            rating: req.body.rating,
            sku: req.body.sku,
            barcode: req.body.barcode,
            inventory: req.body.inventory,
            size: req.body.size
        };
        let doc = await _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findOneAndUpdate */ .Z.findOneAndUpdate(filter, update);
        await _utils_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"].disconnect */ .Z.disconnect();
        res.send({
            code: "success",
            message: "Success"
        });
    } catch  {
        res.send({
            code: "exists",
            message: "Some Error"
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8989,6779], () => (__webpack_exec__(57053)));
module.exports = __webpack_exports__;

})();