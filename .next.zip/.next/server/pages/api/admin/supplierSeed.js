"use strict";
(() => {
var exports = {};
exports.id = 9789;
exports.ids = [9789];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 6555:
/***/ ((module) => {

module.exports = import("uuid");;

/***/ }),

/***/ 4980:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5409);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8989);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__, uuid__WEBPACK_IMPORTED_MODULE_1__]);
([next_connect__WEBPACK_IMPORTED_MODULE_0__, uuid__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
const beautyProducts = [];
const agricultureProducts = [];
const clothesProducts = [];
const mashineryProducts = [];
const sportsProducts = [];
const homeProducts = [];
const webpProducts = [];
for(let i = 1; i < 8; i++){
    beautyProducts.push({
        categories: "sensors",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/sensors/1 (${i}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (30 - 0 + 1)) + 0,
        inventory: 2,
        location: "delhi",
        title: "Product 3",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        added: false,
        liked: false,
        pricing: {
            price: Math.floor(Math.random() * (500 - 0 + 1)) + 0,
            currency: "USD",
            comparePrice: "",
            costPerItem: 1
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i1 = 1; i1 < 27; i1++){
    homeProducts.push({
        categories: "printing",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/printing/1 (${i1}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (30 - 0 + 1)) + 0,
        inventory: 2,
        location: "kolkata",
        title: "Product 3",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        added: false,
        liked: false,
        pricing: {
            price: Math.floor(Math.random() * (500 - 0 + 1)) + 0,
            currency: "USD",
            comparePrice: "",
            costPerItem: 1
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i2 = 1; i2 < 17; i2++){
    agricultureProducts.push({
        categories: "sewing-knitting",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/sewing-knitting/1 (${i2}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (40 - 0 + 1)) + 0,
        inventory: 2,
        location: "hyderabad",
        added: false,
        liked: false,
        title: "Product 3",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        pricing: {
            price: "2",
            currency: "USD",
            comparePrice: "",
            costPerItem: "1"
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i3 = 1; i3 < 21; i3++){
    clothesProducts.push({
        categories: "food-processing",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/food-processing/1 (${i3}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (40 - 0 + 1)) + 0,
        inventory: 2,
        added: false,
        liked: true,
        title: "Product 3",
        location: "kolkata",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        pricing: {
            price: "2",
            currency: "USD",
            comparePrice: "",
            costPerItem: "1"
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i4 = 1; i4 < 25; i4++){
    mashineryProducts.push({
        categories: "water-purification",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/water-purification/1 (${i4}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (40 - 0 + 1)) + 0,
        inventory: 2,
        added: true,
        liked: false,
        title: "Product 3",
        location: "chennai",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        pricing: {
            price: "2",
            currency: "USD",
            comparePrice: "",
            costPerItem: "1"
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i5 = 1; i5 < 8; i5++){
    sportsProducts.push({
        categories: "automation",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/automation/1 (${i5}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (40 - 0 + 1)) + 0,
        inventory: 2,
        added: false,
        liked: true,
        title: "Product 3",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        pricing: {
            price: "2",
            currency: "USD",
            comparePrice: "",
            costPerItem: "1"
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
for(let i6 = 1; i6 < 10; i6++){
    webpProducts.push({
        categories: "webp",
        supplierID: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        status: true,
        features: [],
        image: [
            {
                src: `/images/supplier/products/webp/1 (${i6}).jpg`,
                alt: ""
            }
        ],
        rating: Math.floor(Math.random() * (5 - 0 + 1)) + 0,
        numReviews: Math.floor(Math.random() * (40 - 0 + 1)) + 0,
        inventory: 2,
        added: false,
        liked: false,
        title: "Product 3",
        description: "In publishing and graphic design, Lorem ipsum is a placeholder text ",
        slug: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        type: "physical",
        isFeatured: false,
        pricing: {
            price: "2",
            currency: "USD",
            comparePrice: "",
            costPerItem: "1"
        },
        isDeleted: false,
        barcode: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        sku: (0,uuid__WEBPACK_IMPORTED_MODULE_1__.v4)(),
        size: null
    });
}
handler.get(async (req, res)=>{
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].connect */ .Z.connect();
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].deleteMany */ .Z.deleteMany();
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(beautyProducts);
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(agricultureProducts);
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(clothesProducts);
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(mashineryProducts);
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(sportsProducts);
    await _models_SupplierProduct__WEBPACK_IMPORTED_MODULE_3__/* ["default"].insertMany */ .Z.insertMany(homeProducts);
    //   await SupplierProduct.insertMany(webpProducts);
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].disconnect */ .Z.disconnect();
    res.send({
        message: "seeded successfully"
    });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8989,5409], () => (__webpack_exec__(4980)));
module.exports = __webpack_exports__;

})();