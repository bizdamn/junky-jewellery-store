"use strict";
(() => {
var exports = {};
exports.id = 6189;
exports.ids = [6189];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 869:
/***/ ((module) => {

module.exports = import("emailjs");;

/***/ }),

/***/ 5616:
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ 248:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5616);
/* harmony import */ var _models_Order__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53);
/* harmony import */ var _models_Customer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4615);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8989);
/* harmony import */ var emailjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(869);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__, emailjs__WEBPACK_IMPORTED_MODULE_1__]);
([next_connect__WEBPACK_IMPORTED_MODULE_0__, emailjs__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__["default"])();
handler.put(async (req, res)=>{
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].connect */ .Z.connect();
    const order = await _models_Order__WEBPACK_IMPORTED_MODULE_3__/* ["default"].findById */ .Z.findById(req.body.orderID);
    order.isConfirmed = true;
    await order.save();
    const customer = await _models_Customer__WEBPACK_IMPORTED_MODULE_4__/* ["default"].findById */ .Z.findById(order.customer);
    const client = new emailjs__WEBPACK_IMPORTED_MODULE_1__.SMTPClient({
        user: "bizdamn@gmail.com",
        password: "Bizdamn1435@#$%",
        host: "smtp.gmail.com",
        ssl: true
    });
    try {
        client.send({
            text: `Your Order with Order Id:${order._id} is Confirmed.
        We will deliver it soon
        `,
            to: customer.email,
            subject: `Your Order is Confirmed !!`,
            from: "bizdamn@gmail.com"
        });
    } catch (e) {
        console.log(e);
        res.status(400).end(JSON.stringify({
            message: e
        }));
        return;
    }
    await _utils_db__WEBPACK_IMPORTED_MODULE_2__/* ["default"].disconnect */ .Z.disconnect();
    res.send({
        message: "success"
    });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8989,53,4615], () => (__webpack_exec__(248)));
module.exports = __webpack_exports__;

})();