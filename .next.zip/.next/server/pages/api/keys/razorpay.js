"use strict";
(() => {
var exports = {};
exports.id = 9646;
exports.ids = [9646];
exports.modules = {

/***/ 4871:
/***/ ((module) => {

module.exports = require("razorpay");

/***/ }),

/***/ 5031:
/***/ ((module) => {

module.exports = require("shortid");

/***/ }),

/***/ 7496:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
const Razorpay = __webpack_require__(4871);
const shortid = __webpack_require__(5031);
async function handler(req, res) {
    if (req.method === "POST") {
        // Initialize razorpay object
        const razorpay = new Razorpay({
            key_id: process.env.RAZORPAY_KEY,
            key_secret: process.env.RAZORPAY_SECRET
        });
        // Create an order -> generate the OrderID -> Send it to the Front-end
        // Also, check the amount and currency on the backend (Security measure)
        const payment_capture = 1;
        // const amount = 499;
        const currency = "INR";
        const options = {
            amount: (JSON.parse(req.body).amount * 100).toString(),
            currency,
            receipt: shortid.generate(),
            payment_capture
        };
        try {
            const response = await razorpay.orders.create(options);
            res.status(200).json({
                id: response.id,
                currency: response.currency,
                amount: response.amount
            });
        } catch (err) {
            console.log(err);
            res.status(400).json(err);
        }
    } else {
    // Handle any other HTTP method
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7496));
module.exports = __webpack_exports__;

})();