"use strict";
(() => {
var exports = {};
exports.id = 9756;
exports.ids = [9756];
exports.modules = {

/***/ 33666:
/***/ ((module) => {

module.exports = require("@vercel/fetch");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 98790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ checkout)
});

;// CONCATENATED MODULE: ./framework/local/api/endpoints/checkout/index.ts
function noopApi(...args) {};

// EXTERNAL MODULE: ./lib/api/commerce.ts + 13 modules
var commerce = __webpack_require__(69441);
;// CONCATENATED MODULE: ./pages/api/checkout.ts


/* harmony default export */ const checkout = (noopApi(commerce/* default */.Z));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9441], () => (__webpack_exec__(98790)));
module.exports = __webpack_exports__;

})();