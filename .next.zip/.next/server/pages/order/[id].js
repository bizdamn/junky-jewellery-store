"use strict";
(() => {
var exports = {};
exports.id = 8441;
exports.ids = [8441];
exports.modules = {

/***/ 2623:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2767);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4467);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2129);
/* harmony import */ var _mui_material_Stepper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4531);
/* harmony import */ var _mui_material_Stepper__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Stepper__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Step__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(793);
/* harmony import */ var _mui_material_Step__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Step__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_StepLabel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5723);
/* harmony import */ var _mui_material_StepLabel__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_StepLabel__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_StepContent__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8816);
/* harmony import */ var _mui_material_StepContent__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_StepContent__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils_styles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4740);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3142);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__, _components_common__WEBPACK_IMPORTED_MODULE_15__]);
([_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__, _components_common__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// import { Layout } from '@components/common'










// import { PayPalButtons, usePayPalScriptReducer } from '@paypal/react-paypal-js';
function reducer(state, action) {
    switch(action.type){
        case "FETCH_REQUEST":
            return {
                ...state,
                loading: true,
                error: ""
            };
        case "FETCH_SUCCESS":
            return {
                ...state,
                loading: false,
                order: action.payload,
                error: ""
            };
        case "FETCH_FAIL":
            return {
                ...state,
                loading: false,
                error: action.payload
            };
        case "PAY_REQUEST":
            return {
                ...state,
                loadingPay: true
            };
        case "PAY_SUCCESS":
            return {
                ...state,
                loadingPay: false,
                successPay: true
            };
        case "PAY_FAIL":
            return {
                ...state,
                loadingPay: false,
                errorPay: action.payload
            };
        case "PAY_RESET":
            return {
                ...state,
                loadingPay: false,
                successPay: false,
                errorPay: ""
            };
        case "DELIVER_REQUEST":
            return {
                ...state,
                loadingDeliver: true
            };
        case "DELIVER_SUCCESS":
            return {
                ...state,
                loadingDeliver: false,
                successDeliver: true
            };
        case "DELIVER_FAIL":
            return {
                ...state,
                loadingDeliver: false,
                errorDeliver: action.payload
            };
        case "DELIVER_RESET":
            return {
                ...state,
                loadingDeliver: false,
                successDeliver: false,
                errorDeliver: ""
            };
        default:
            state;
    }
}
const steps = [
    {
        label: "Order Placed",
        description: ``
    },
    {
        label: "Order Confirmed",
        description: ""
    },
    {
        label: "Order Shipped",
        description: ``
    },
    {
        label: "Order Delivered",
        description: ``
    }, 
];
function Order({ params  }) {
    const orderId = params.id;
    // const [{ isPending }, paypalDispatch] = usePayPalScriptReducer();
    const classes = (0,_utils_styles__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__/* .DataStore */ .K);
    const { customerInfo , storeInfo  } = state;
    const { 0: { loading , error , order , successPay , loadingDeliver , successDeliver  } , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, {
        loading: true,
        order: {},
        error: ""
    });
    const { shippingAddress , paymentMethod , orderItems , itemsPrice , taxPrice , shippingPrice , totalPrice: totalPrice1 , isPaid , paidAt , isDelivered , deliveredAt ,  } = order;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // if (!storeInfo) {
        //   return router.push('/')
        // }
        if (!customerInfo) {
            return router.push("/login");
        }
        if (order?.orderStatus == "Confirmed") {
            setActiveStep(1);
        } else if (order?.orderStatus == "Shipped") {
            setActiveStep(2);
        } else if (order?.orderStatus == "Delivered") {
            setActiveStep(3);
        }
        const fetchOrder = async ()=>{
            try {
                dispatch({
                    type: "FETCH_REQUEST"
                });
                const { data  } = await axios__WEBPACK_IMPORTED_MODULE_10___default().get(`/api/orders/${orderId}`, {
                    headers: {
                        authorization: `Bearer ${customerInfo.token}`
                    }
                });
                dispatch({
                    type: "FETCH_SUCCESS",
                    payload: data
                });
            } catch (err) {
                dispatch({
                    type: "FETCH_FAIL",
                    payload: err
                });
            }
        };
        if (!order._id || successPay || successDeliver || order._id && order._id !== orderId) {
            fetchOrder();
            if (successPay) {
                dispatch({
                    type: "PAY_RESET"
                });
            }
            if (successDeliver) {
                dispatch({
                    type: "DELIVER_RESET"
                });
            }
        } else {
        // const loadPaypalScript = async () => {
        //   const { data: clientId } = await axios.get('/api/keys/paypal', {
        //     headers: { authorization: `Bearer ${customerInfo.token}` },
        //   });
        //   paypalDispatch({
        //     type: 'resetOptions',
        //     value: {
        //       'client-id': clientId,
        //       currency: 'USD',
        //     },
        //   });
        //   paypalDispatch({ type: 'setLoadingStatus', value: 'pending' });
        // };
        // loadPaypalScript();
        }
    }, [
        order,
        successPay,
        successDeliver,
        customerInfo,
        router,
        // paypalDispatch,
        orderId, 
    ]);
    const { enqueueSnackbar  } = (0,notistack__WEBPACK_IMPORTED_MODULE_12__.useSnackbar)();
    function createOrder(data, actions) {
        return actions.order.create({
            purchase_units: [
                {
                    amount: {
                        value: totalPrice1
                    }
                }, 
            ]
        }).then((orderID)=>{
            return orderID;
        });
    }
    function onApprove(data1, actions) {
        return actions.order.capture().then(async function(details) {
            try {
                dispatch({
                    type: "PAY_REQUEST"
                });
                const { data  } = await axios__WEBPACK_IMPORTED_MODULE_10___default().put(`/api/orders/${order._id}/pay`, details, {
                    headers: {
                        authorization: `Bearer ${customerInfo.token}`
                    }
                });
                dispatch({
                    type: "PAY_SUCCESS",
                    payload: data
                });
                enqueueSnackbar("Order is paid", {
                    variant: "success"
                });
            } catch (err) {
                dispatch({
                    type: "PAY_FAIL",
                    payload: err
                });
                enqueueSnackbar(err, {
                    variant: "error"
                });
            }
        });
    }
    function onError(err) {
        enqueueSnackbar(err, {
            variant: "error"
        });
    }
    async function deliverOrderHandler() {
        try {
            dispatch({
                type: "DELIVER_REQUEST"
            });
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_10___default().put(`/api/orders/${order._id}/deliver`, {}, {
                headers: {
                    authorization: `Bearer ${customerInfo.token}`
                }
            });
            dispatch({
                type: "DELIVER_SUCCESS",
                payload: data
            });
            enqueueSnackbar("Order is delivered", {
                variant: "success"
            });
        } catch (err) {
            dispatch({
                type: "DELIVER_FAIL",
                payload: err
            });
            enqueueSnackbar(err, {
                variant: "error"
            });
        }
    }
    // RazorPay
    const makeRazorPayPayment = async (totalPrice)=>{
        const res = await initializeRazorpay();
        if (!res) {
            alert("Razorpay SDK Failed to load");
            return;
        }
        // Make API call to the serverless API
        const data = await fetch("/api/keys/razorpay", {
            method: "POST",
            body: JSON.stringify({
                amount: totalPrice
            })
        }).then((t)=>t.json()
        );
        var options = {
            key: process.env.RAZORPAY_KEY,
            name: storeInfo.name,
            currency: data.currency,
            amount: data.amount,
            order_id: data.id,
            description: "Thankyou for your test donation",
            image: storeInfo.logo,
            handler: function(response) {
                // Validate payment at server - using webhooks is a better idea.
                alert(response.razorpay_payment_id);
                alert(response.razorpay_order_id);
                alert(response.razorpay_signature);
            },
            prefill: {
                name: storeInfo.name,
                email: storeInfo.email,
                contact: storeInfo.phone
            }
        };
        const paymentObject = new window.Razorpay(options);
        paymentObject.open();
    };
    const initializeRazorpay = ()=>{
        return new Promise((resolve)=>{
            const script = document.createElement("script");
            script.src = "https://checkout.razorpay.com/v1/checkout.js";
            // document.body.appendChild(script);
            script.onload = ()=>{
                resolve(true);
            };
            script.onerror = ()=>{
                resolve(false);
            };
            document.body.appendChild(script);
        });
    };
    const [activeStep, setActiveStep] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(0);
    const handleNext = ()=>{
        setActiveStep((prevActiveStep)=>prevActiveStep + 1
        );
    };
    const handleBack = ()=>{
        setActiveStep((prevActiveStep)=>prevActiveStep - 1
        );
    };
    const handleReset = ()=>{
        setActiveStep(0);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                align: "center",
                component: "h1",
                variant: "h4",
                children: [
                    "Order ID - ",
                    orderId
                ]
            }),
            loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.CircularProgress, {}) : error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                className: classes.error,
                children: error
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                container: true,
                justifyContent: "center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                        style: {
                            margin: "1rem"
                        },
                        item: true,
                        md: 8,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Card, {
                                className: classes.section,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.List, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                variant: "pageHeading",
                                                children: " Shipping Address"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: [
                                                shippingAddress.fullName,
                                                ", ",
                                                shippingAddress.address,
                                                ",",
                                                " ",
                                                shippingAddress.city,
                                                ", ",
                                                shippingAddress.postalCode,
                                                ",",
                                                " ",
                                                shippingAddress.country,
                                                "\xa0",
                                                shippingAddress.location && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Link, {
                                                    variant: "button",
                                                    target: "_new",
                                                    href: `https://maps.google.com?q=${shippingAddress.location.lat},${shippingAddress.location.lng}`,
                                                    children: "Show On Map"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Card, {
                                className: classes.section,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.List, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                variant: "pageHeading",
                                                children: "Payment Method"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: paymentMethod
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Card, {
                                className: classes.section,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.List, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                variant: "pageHeading",
                                                children: "Order Items"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableContainer, {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Table, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableHead, {
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableRow, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                        children: "Image"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                        children: "Name"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                        align: "right",
                                                                        children: "Quantity"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                        align: "right",
                                                                        children: "Price"
                                                                    })
                                                                ]
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableBody, {
                                                            children: orderItems.map((item)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableRow, {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                                href: `/product/${item.slug}`,
                                                                                passHref: true,
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Link, {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                                                        src: `/assets${item.images[0]?.url}`,
                                                                                        alt: item.images[0].altText,
                                                                                        width: 50,
                                                                                        height: 50
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                                href: `/product/${item.slug}`,
                                                                                passHref: true,
                                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Link, {
                                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                                                        children: item.name
                                                                                    })
                                                                                })
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                            align: "right",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                                                children: item.quantity
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.TableCell, {
                                                                            align: "right",
                                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                                                children: [
                                                                                    "$",
                                                                                    item.price.value
                                                                                ]
                                                                            })
                                                                        })
                                                                    ]
                                                                }, item._id)
                                                            )
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                        item: true,
                        style: {
                            margin: "1rem"
                        },
                        md: 3,
                        xs: 12,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Box, {
                                sx: {
                                    maxWidth: 400
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Stepper__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        activeStep: activeStep,
                                        orientation: "vertical",
                                        children: steps.map((step, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Step__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_StepLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        optional: index === 3 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            variant: "caption",
                                                            children: "Last step"
                                                        }) : null,
                                                        children: step.label
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_StepContent__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            children: step.description
                                                        })
                                                    })
                                                ]
                                            }, step.label)
                                        )
                                    }),
                                    activeStep === steps.length && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Paper, {
                                        square: true,
                                        elevation: 0,
                                        sx: {
                                            p: 3
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                children: "All steps completed - you're finished"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Button, {
                                                onClick: handleReset,
                                                sx: {
                                                    mt: 1,
                                                    mr: 1
                                                },
                                                children: "Reset"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Card, {
                                className: classes.section,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.List, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                variant: "pageHeading",
                                                children: " Order Summary"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                container: true,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            children: "Items:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            align: "right",
                                                            children: [
                                                                "$",
                                                                itemsPrice
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                container: true,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            children: "Shipping:"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            align: "right",
                                                            children: [
                                                                "$",
                                                                shippingPrice
                                                            ]
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                container: true,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                                children: "Total:"
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                                                        item: true,
                                                        xs: 6,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Typography, {
                                                            align: "right",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                                                                children: [
                                                                    "$",
                                                                    totalPrice1
                                                                ]
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        }),
                                        customerInfo.isAdmin && order.isPaid && !order.isDelivered && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.ListItem, {
                                            children: [
                                                loadingDeliver && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.CircularProgress, {}),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_9__.Button, {
                                                    fullWidth: true,
                                                    variant: "contained",
                                                    color: "primary",
                                                    onClick: deliverOrderHandler,
                                                    children: "Deliver Order"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
async function getServerSideProps({ params  }) {
    return {
        props: {
            params
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>Promise.resolve(Order)
, {
    ssr: false
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 2369:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddLocationAlt");

/***/ }),

/***/ 9486:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckCircleOutline");

/***/ }),

/***/ 9026:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Mail");

/***/ }),

/***/ 6872:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Phone");

/***/ }),

/***/ 793:
/***/ ((module) => {

module.exports = require("@mui/material/Step");

/***/ }),

/***/ 8816:
/***/ ((module) => {

module.exports = require("@mui/material/StepContent");

/***/ }),

/***/ 5723:
/***/ ((module) => {

module.exports = require("@mui/material/StepLabel");

/***/ }),

/***/ 4531:
/***/ ((module) => {

module.exports = require("@mui/material/Stepper");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 5782:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 9003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 3746:
/***/ ((module) => {

module.exports = require("lodash.random");

/***/ }),

/***/ 8622:
/***/ ((module) => {

module.exports = require("lodash.throttle");

/***/ }),

/***/ 1162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 5874:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 3142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 824:
/***/ ((module) => {

module.exports = require("react-merge-refs");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9505,1664,5675,5152,5844,2767,3968,2129,4740], () => (__webpack_exec__(2623)));
module.exports = __webpack_exports__;

})();