"use strict";
(() => {
var exports = {};
exports.id = 9603;
exports.ids = [9603];
exports.modules = {

/***/ 55935:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Search),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58369);
/* harmony import */ var _mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(30802);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(88185);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_product__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(44437);
/* harmony import */ var _material_ui_icons_Cancel__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(50090);
/* harmony import */ var _material_ui_icons_Cancel__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Cancel__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _utils_db__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(817);
/* harmony import */ var _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(18638);
/* harmony import */ var _utils_styles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(84740);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(52767);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(50770);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(74116);
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__, _components_product__WEBPACK_IMPORTED_MODULE_15__, _components_common__WEBPACK_IMPORTED_MODULE_18__]);
([_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__, _components_product__WEBPACK_IMPORTED_MODULE_15__, _components_common__WEBPACK_IMPORTED_MODULE_18__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const PAGE_SIZE = 3;
const prices = [
    {
        name: "$1 to $50",
        value: "1-50"
    },
    {
        name: "$51 to $200",
        value: "51-200"
    },
    {
        name: "$201 to $1000",
        value: "201-1000"
    }, 
];
const ratings = (/* unused pure expression or super */ null && ([
    1,
    2,
    3,
    4,
    5
]));
function Search(props) {
    const classes = (0,_utils_styles__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { query: query1 = "all" , category: category1 = "all" , brand: brand1 = "all" , price: price1 = "all" , rating: rating1 = "all" , sort: sort1 = "featured" ,  } = router.query;
    const { products , countProducts , categories , brands , totalPages  } = props;
    const filterSearch = ({ page , category , brand , sort , min , max , searchQuery , price , rating ,  })=>{
        const path = router.pathname;
        const { query  } = router;
        if (page) query.page = page;
        if (searchQuery) query.searchQuery = searchQuery;
        if (sort) query.sort = sort;
        if (category) query.category = category;
        if (brand) query.brand = brand;
        if (price) query.price = price;
        if (rating) query.rating = rating;
        if (min) query.min ? query.min : query.min === 0 ? 0 : min;
        if (max) query.max ? query.max : query.max === 0 ? 0 : max;
        router.push({
            pathname: path,
            query: query
        });
    };
    const categoryHandler = (e)=>{
        filterSearch({
            category: e
        });
    };
    const pageHandler = (e, page)=>{
        filterSearch({
            page
        });
    };
    const brandHandler = (e)=>{
        filterSearch({
            brand: e.target.value
        });
    };
    const sortHandler = (e)=>{
        filterSearch({
            sort: e
        });
    };
    const priceHandler = (e)=>{
        filterSearch({
            price: e.target.value
        });
    };
    const ratingHandler = (e)=>{
        filterSearch({
            rating: e
        });
    };
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_10__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_14__/* .DataStore */ .K);
    const addToCartHandler = async (product)=>{
        const existItem = state.cart.cartItems.find((x)=>x._id === product._id
        );
        const quantity = existItem ? existItem.quantity + 1 : 1;
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_11___default().get(`/api/products/${product._id}`);
        if (data.countInStock < quantity) {
            window.alert("Sorry. Product is out of stock");
            return;
        }
        dispatch({
            type: "CART_ADD_ITEM",
            payload: {
                ...product,
                quantity
            }
        });
        router.push("/cart");
    };
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            className: classes.mt1,
            container: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    md: 3,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.List, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: classes.fullWidth,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            style: {
                                                fontWeight: 700
                                            },
                                            children: "Categories"
                                        }),
                                        categories && categories.map((category)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                style: {
                                                    pointer: "cursor"
                                                },
                                                onClick: ()=>categoryHandler(category)
                                                ,
                                                children: [
                                                    "   ",
                                                    category
                                                ]
                                            }, category)
                                        )
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: classes.fullWidth,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            style: {
                                                fontWeight: 700
                                            },
                                            children: "Brands"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_5___default()), {
                                                value: brand1,
                                                onChange: brandHandler,
                                                children: brands && brands.map((brand)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        value: brand,
                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_4___default()), {
                                                            size: "small"
                                                        }),
                                                        label: capitalizeFirstLetter(brand)
                                                    }, brand)
                                                )
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: classes.fullWidth,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            style: {
                                                fontWeight: 700
                                            },
                                            children: "Prices"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                            value: price1,
                                            onChange: priceHandler,
                                            fullWidth: true,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                                                    value: "all",
                                                    children: "All"
                                                }),
                                                prices.map((price)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.MenuItem, {
                                                        value: price.value,
                                                        children: price.name
                                                    }, price.value)
                                                )
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.ListItem, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    className: classes.fullWidth,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            style: {
                                                fontWeight: 700
                                            },
                                            children: "Ratings"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            name: "simple-controlled",
                                            value: rating1,
                                            onChange: (event, newValue)=>{
                                                ratingHandler(newValue);
                                            }
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    md: 7,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            container: true,
                            justifyContent: "space-between",
                            alignItems: "center",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                children: [
                                    products.length === 0 ? "No" : countProducts,
                                    " Results: \xa0",
                                    query1 !== "all" && query1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        label: capitalizeFirstLetter(query1),
                                        variant: "outlined"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    category1 !== "all" && category1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        label: capitalizeFirstLetter(category1),
                                        variant: "outlined"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    brand1 !== "all" && brand1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        label: capitalizeFirstLetter(brand1),
                                        variant: "outlined"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    price1 !== "all" && price1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        label: `Price: ₹${price1}`,
                                        variant: "outlined"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    rating1 !== "all" && rating1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Chip__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        label: `Rating: ${rating1}`,
                                        variant: "outlined"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    query1 !== "all" && query1 !== "" || category1 !== "all" || brand1 !== "all" || rating1 !== "all" || price1 !== "all" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        onClick: ()=>router.push("/search")
                                        ,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_material_ui_icons_Cancel__WEBPACK_IMPORTED_MODULE_8___default()), {})
                                    }) : null
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            className: classes.mt1,
                            container: true,
                            spacing: 3,
                            children: products.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                    item: true,
                                    md: 4,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                        variant: "simple",
                                        className: "animated fadeIn",
                                        product: product,
                                        imgProps: {
                                            width: 480,
                                            height: 480
                                        }
                                    }, product.path)
                                }, product.name)
                            )
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_lab__WEBPACK_IMPORTED_MODULE_12__.Pagination, {
                            className: classes.mt1,
                            defaultPage: parseInt(query1.page || "1"),
                            count: totalPages,
                            onChange: pageHandler
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    md: 2,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        className: classes.fullWidth,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    fontWeight: 700
                                },
                                children: "Relevance"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    pointer: "cursor"
                                },
                                onClick: ()=>sortHandler("featured")
                                ,
                                children: "Featured"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    pointer: "cursor"
                                },
                                onClick: ()=>sortHandler("lowest")
                                ,
                                children: "Price: Low to high"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    pointer: "cursor"
                                },
                                onClick: ()=>sortHandler("highest")
                                ,
                                children: "Price: High to low"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    pointer: "cursor"
                                },
                                onClick: ()=>sortHandler("toprated")
                                ,
                                children: "Top Rated"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                style: {
                                    pointer: "cursor"
                                },
                                onClick: ()=>sortHandler("newest")
                                ,
                                children: "Latest arrivals"
                            })
                        ]
                    })
                })
            ]
        })
    });
};
async function getServerSideProps({ query  }) {
    await _utils_db__WEBPACK_IMPORTED_MODULE_16__/* ["default"].connect */ .Z.connect();
    const pageSize = query.pageSize || PAGE_SIZE;
    const page = query.page || 1;
    const category = query.category || "";
    const brand = query.brand || "";
    const price = query.price || "";
    const rating = query.rating || "";
    const sort = query.sort || "";
    const searchQuery = query.query || "";
    const queryFilter = searchQuery && searchQuery !== "all" ? {
        name: {
            $regex: searchQuery,
            $options: "i"
        }
    } : {};
    const categoryFilter = category && category !== "all" ? {
        category
    } : {};
    const brandFilter = brand && brand !== "all" ? {
        brand
    } : {};
    const ratingFilter = rating && rating !== "all" ? {
        rating: {
            $gte: Number(rating)
        }
    } : {};
    // 10-50
    const priceFilter = price && price !== "all" ? {
        price: {
            $gte: Number(price.split("-")[0]),
            $lte: Number(price.split("-")[1])
        }
    } : {};
    const order = sort === "featured" ? {
        featured: -1
    } : sort === "lowest" ? {
        price: 1
    } : sort === "highest" ? {
        price: -1
    } : sort === "toprated" ? {
        rating: -1
    } : sort === "newest" ? {
        createdAt: -1
    } : {
        _id: -1
    };
    const categories = [
        "LoRawan Technology",
        "SMT Accessories",
        "IoT Products",
        "IoT Accessories",
        "NB IoT",
        "PCB Accessories"
    ];
    const brands = [
        "Dragino",
        "Mitsubishi"
    ];
    const productDocs = await _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_17__/* ["default"].find */ .Z.find({
        ...queryFilter,
        ...categoryFilter,
        ...priceFilter,
        ...brandFilter,
        ...ratingFilter
    }, "-reviews").sort(order).skip(pageSize * (page - 1)).limit(pageSize).lean();
    const countProducts = await _models_PhysicalProduct__WEBPACK_IMPORTED_MODULE_17__/* ["default"].countDocuments */ .Z.countDocuments({
        ...queryFilter,
        ...categoryFilter,
        ...priceFilter,
        ...brandFilter,
        ...ratingFilter
    });
    await _utils_db__WEBPACK_IMPORTED_MODULE_16__/* ["default"].disconnect */ .Z.disconnect();
    const products = productDocs.map(_utils_db__WEBPACK_IMPORTED_MODULE_16__/* ["default"].convertDocToObj */ .Z.convertDocToObj);
    return {
        props: {
            products,
            countProducts,
            page,
            totalPages: Math.ceil(countProducts / pageSize),
            categories,
            brands
        }
    };
}
Search.Layout = _components_common__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 50090:
/***/ ((module) => {

module.exports = require("@material-ui/icons/Cancel");

/***/ }),

/***/ 74116:
/***/ ((module) => {

module.exports = require("@material-ui/lab");

/***/ }),

/***/ 22369:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddLocationAlt");

/***/ }),

/***/ 79486:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckCircleOutline");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 17666:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Facebook");

/***/ }),

/***/ 73281:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Instagram");

/***/ }),

/***/ 9026:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Mail");

/***/ }),

/***/ 86872:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Phone");

/***/ }),

/***/ 85631:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Twitter");

/***/ }),

/***/ 12232:
/***/ ((module) => {

module.exports = require("@mui/icons-material/WhatsApp");

/***/ }),

/***/ 93765:
/***/ ((module) => {

module.exports = require("@mui/material/Alert");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 58369:
/***/ ((module) => {

module.exports = require("@mui/material/Chip");

/***/ }),

/***/ 15732:
/***/ ((module) => {

module.exports = require("@mui/material/Collapse");

/***/ }),

/***/ 68891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 88185:
/***/ ((module) => {

module.exports = require("@mui/material/FormControlLabel");

/***/ }),

/***/ 15612:
/***/ ((module) => {

module.exports = require("@mui/material/Grid");

/***/ }),

/***/ 67934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 55374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 76563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 30802:
/***/ ((module) => {

module.exports = require("@mui/material/Rating");

/***/ }),

/***/ 27163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 52167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 25782:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 59003:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 81072:
/***/ ((module) => {

module.exports = require("email-validator");

/***/ }),

/***/ 43746:
/***/ ((module) => {

module.exports = require("lodash.random");

/***/ }),

/***/ 38622:
/***/ ((module) => {

module.exports = require("lodash.throttle");

/***/ }),

/***/ 11185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 51162:
/***/ ((module) => {

module.exports = require("next-themes");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 94957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 64365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 73142:
/***/ ((module) => {

module.exports = require("notistack");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 70824:
/***/ ((module) => {

module.exports = require("react-merge-refs");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 549:
/***/ ((module) => {

module.exports = require("swr");

/***/ }),

/***/ 69915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 45641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9505,1664,5675,5152,5844,2767,3968,2129,770,817,7399,8638,4740,4437], () => (__webpack_exec__(55935)));
module.exports = __webpack_exports__;

})();