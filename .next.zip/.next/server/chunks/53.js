"use strict";
exports.id = 53;
exports.ids = [53];
exports.modules = {

/***/ 40053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const orderSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    customer: {
        type: String
    },
    storeID: {
        type: String,
        required: false
    },
    orderItems: {
        type: Array,
        required: false
    },
    shippingAddress: {
        fullName: {
            type: String,
            required: false
        },
        address: {
            type: String,
            required: false
        },
        city: {
            type: String,
            required: false
        },
        postalCode: {
            type: String,
            required: false
        },
        country: {
            type: String,
            required: false
        },
        location: {
            lat: String,
            lng: String,
            address: String,
            name: String,
            vicinity: String,
            googleAddressId: String
        }
    },
    paymentMethod: {
        type: String,
        required: false
    },
    // paymentResult: { id: String, status: String, email_address: String },
    itemsPrice: {
        type: Number,
        required: false
    },
    shippingPrice: {
        type: Number,
        required: false
    },
    taxPrice: {
        type: Number,
        required: false
    },
    totalPrice: {
        type: Number,
        required: false
    },
    isPaid: {
        type: Boolean,
        required: false,
        default: false
    },
    orderStatus: {
        type: String,
        required: false,
        default: "Pending"
    },
    paidAt: {
        type: Date,
        required: false
    },
    deliveredAt: {
        type: Date,
        required: false
    }
}, {
    timestamps: true
});
const Order = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Order) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Order", orderSchema, "orders");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Order);


/***/ })

};
;