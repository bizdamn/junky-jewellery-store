exports.id = 770;
exports.ids = [770];
exports.modules = {

/***/ 37410:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartItem_root__n8ra_",
	"quantity": "CartItem_quantity__qmi6Q",
	"productImage": "CartItem_productImage__VapbI",
	"productName": "CartItem_productName__RYrlX"
};


/***/ }),

/***/ 86352:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartSidebarView_root__5gpRe",
	"empty": "CartSidebarView_empty__fvfi0",
	"lineItemsList": "CartSidebarView_lineItemsList__StJOa"
};


/***/ }),

/***/ 93668:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CheckoutSidebarView_root__hj993",
	"lineItemsList": "CheckoutSidebarView_lineItemsList__zjdUk"
};


/***/ }),

/***/ 73207:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "PaymentMethodView_fieldset__QEB59",
	"label": "PaymentMethodView_label__xM6ed",
	"input": "PaymentMethodView_input__vj9M1",
	"select": "PaymentMethodView_select__32jl5"
};


/***/ }),

/***/ 33195:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "PaymentWidget_root__Y8ogL"
};


/***/ }),

/***/ 15705:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "ShippingView_fieldset__h5IA5",
	"label": "ShippingView_label__Mempp",
	"input": "ShippingView_input__lslSw",
	"select": "ShippingView_select__n5mpB",
	"radio": "ShippingView_radio__MFeU4"
};


/***/ }),

/***/ 55969:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ShippingWidget_root__b3tUJ"
};


/***/ }),

/***/ 2524:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Footer_root__r3DO1",
	"link": "Footer_link__gh2xK"
};


/***/ }),

/***/ 55739:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Layout_root___g0be"
};


/***/ }),

/***/ 21092:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "SidebarLayout_root__d94Sj",
	"header": "SidebarLayout_header__szwlA",
	"container": "SidebarLayout_container__hqrjW"
};


/***/ }),

/***/ 58566:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "MenuSidebarView_root__QjWQB",
	"item": "MenuSidebarView_item__Y2hvw"
};


/***/ }),

/***/ 86442:
/***/ ((module) => {

// Exports
module.exports = {
	"actions": "Quantity_actions__C9fVt",
	"input": "Quantity_input__yBzs3"
};


/***/ }),

/***/ 99793:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Sidebar_root__hUV6J",
	"sidebar": "Sidebar_sidebar__7UX4L",
	"backdrop": "Sidebar_backdrop__uAThX"
};


/***/ }),

/***/ 34520:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(36108);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(24106);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23968);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(52767);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(69915);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45641);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(73142);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_8__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_3__, react_hook_form__WEBPACK_IMPORTED_MODULE_4__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const LoginView = ()=>{
    const { handleSubmit , control , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)();
    const { enqueueSnackbar , closeSnackbar  } = (0,notistack__WEBPACK_IMPORTED_MODULE_5__.useSnackbar)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_8__/* .DataStore */ .K);
    const { customerInfo  } = state;
    // Form State
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: message , 1: setMessage  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: disabled , 1: setDisabled  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { setModalView , closeModal  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_9__/* .useUI */ .l8)();
    const submitHandler = async (mainData)=>{
        closeSnackbar();
        try {
            const { data  } = await axios__WEBPACK_IMPORTED_MODULE_2___default().post("/api/customers/login", {
                email: mainData.email,
                password: mainData.password
            });
            dispatch({
                type: "CUSTOMER_LOGIN",
                payload: data
            });
            js_cookie__WEBPACK_IMPORTED_MODULE_3__["default"].set("customerInfo", JSON.stringify(data));
            closeModal();
        } catch (err) {
            enqueueSnackbar(err.response.data ? err.response.data.message : err.message, {
                variant: "error"
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            onSubmit: handleSubmit(submitHandler),
            className: "w-80 flex flex-col justify-between p-3",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex justify-center pb-12 ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        width: "64px",
                        height: "64px"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col space-y-3",
                    children: [
                        message && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-red border border-red p-3",
                            children: [
                                message,
                                ". Did you ",
                                ` `,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "text-accent-9 inline font-bold hover:underline cursor-pointer",
                                    onClick: ()=>setModalView("FORGOT_VIEW")
                                    ,
                                    children: "forgot your password?"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
                            name: "email",
                            control: control,
                            defaultValue: "",
                            rules: {
                                required: true,
                                pattern: /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/
                            },
                            render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__.TextField, {
                                    variant: "outlined",
                                    fullWidth: true,
                                    id: "email",
                                    label: "Email",
                                    inputProps: {
                                        type: "email"
                                    },
                                    error: Boolean(errors.email),
                                    helperText: errors.email ? errors.email.type === "pattern" ? "Email is not valid" : "Email is required" : "",
                                    ...field
                                })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_4__.Controller, {
                            name: "password",
                            control: control,
                            defaultValue: "",
                            rules: {
                                required: true,
                                minLength: 6
                            },
                            render: ({ field  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_7__.TextField, {
                                    variant: "outlined",
                                    fullWidth: true,
                                    id: "password",
                                    label: "Password",
                                    inputProps: {
                                        type: "password"
                                    },
                                    error: Boolean(errors.password),
                                    helperText: errors.password ? errors.password.type === "minLength" ? "Password length is more than 5" : "Password is required" : "",
                                    ...field
                                })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            variant: "slim",
                            type: "submit",
                            loading: loading,
                            disabled: disabled,
                            children: "Log In"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "pt-1 text-center text-sm",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-accent-7",
                                    children: "Don't have an account?"
                                }),
                                ` `,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    className: "text-accent-9 font-bold hover:underline cursor-pointer",
                                    onClick: ()=>setModalView("SIGNUP_VIEW")
                                    ,
                                    children: "Sign Up"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 33564:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _CartItem_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(37410);
/* harmony import */ var _CartItem_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_CartItem_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23968);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(79747);
/* harmony import */ var _framework_cart_use_update_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(42639);
/* harmony import */ var _framework_cart_use_remove_item__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(46704);
/* harmony import */ var _components_ui_Quantity__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(59795);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(52767);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_6__]);
_utils_DataStore__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const placeholderImg = "/product-img-placeholder.svg";
const CartItem = ({ item , variant ="default" , currencyCode , ...rest })=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_6__/* .DataStore */ .K);
    const { cart  } = state;
    const { closeSidebarIfPresent  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_7__/* .useUI */ .l8)();
    const { 0: removing , 1: setRemoving  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: quantity , 1: setQuantity  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(item.quantity);
    const removeItem = (0,_framework_cart_use_remove_item__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const updateItem = (0,_framework_cart_use_update_item__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)({
        item
    });
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .ZP)({
        amount: item.price.value * item.quantity,
        baseAmount: item.listPrice * item.quantity,
        currencyCode
    });
    const handleChange = async ({ target: { value  }  })=>{
        setQuantity(Number(value));
        await dispatch({
            type: "CART_ADD_ITEM",
            payload: {
                ...item,
                quantity: Number(value)
            }
        });
        await updateItem({
            quantity: Number(value)
        });
    };
    const increaseQuantity = async (n = 1)=>{
        const val = Number(quantity) + n;
        await setQuantity(val);
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_5___default().get(`/api/products/${item._id}`);
        if (data.countInStock < val) {
            window.alert("Sorry. Product is out of stock");
            return;
        }
        dispatch({
            type: "CART_ADD_ITEM",
            payload: {
                ...item,
                quantity: val
            }
        });
    };
    const handleRemove = async ()=>{
        setRemoving(true);
        try {
            dispatch({
                type: "CART_REMOVE_ITEM",
                payload: item
            });
        } catch (error) {
            setRemoving(false);
        }
    };
    // TODO: Add a type for this
    const options = item.options;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Reset the quantity state if the item quantity changes
        if (item.quantity !== Number(quantity)) {
            setQuantity(item.quantity);
        }
    // TODO: currently not including quantity in deps is intended, but we should
    // do this differently as it could break easily
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        item.quantity
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_CartItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().root), {
            "opacity-50 pointer-events-none": removing
        }),
        ...rest,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row space-x-4 py-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-16 h-16 bg-violet relative overflow-hidden cursor-pointer z-0",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/product${item.path}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    onClick: ()=>closeSidebarIfPresent()
                                    ,
                                    className: (_CartItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().productImage),
                                    width: 150,
                                    height: 150,
                                    src: `/assets${item.images[0]?.url}` || placeholderImg,
                                    alt: item.images[0]?.altText || "Product Image",
                                    unoptimized: true
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex flex-col text-base",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/product${item.path}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: (_CartItem_module_css__WEBPACK_IMPORTED_MODULE_11___default().productName),
                                        onClick: ()=>closeSidebarIfPresent()
                                        ,
                                        children: item.name
                                    })
                                })
                            }),
                            options && options.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex items-center pb-1",
                                children: options.map((option, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "text-sm font-semibold text-accent-7 inline-flex items-center justify-center",
                                        children: [
                                            option.color ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    "Color",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "mx-2 rounded-full bg-transparent border w-5 h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
                                                        style: {
                                                            backgroundColor: `${option.color}`
                                                        }
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mx-2 rounded-full bg-transparent border h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
                                                children: option.color
                                            }),
                                            i === options.length - 1 ? "" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "mr-3"
                                            })
                                        ]
                                    }, `${item._id}-${option.displayName}`)
                                )
                            }),
                            variant === "display" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text-sm tracking-wider",
                                children: [
                                    quantity,
                                    "x"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col justify-between space-y-2 text-sm",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: price
                        })
                    })
                ]
            }),
            variant === "default" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Quantity__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                value: quantity,
                handleRemove: handleRemove,
                handleChange: handleChange,
                increase: ()=>increaseQuantity(1)
                ,
                decrease: ()=>increaseQuantity(-1)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartItem);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 73763:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86352);
/* harmony import */ var _CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(69915);
/* harmony import */ var _CartItem__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(33564);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(44467);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(24106);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(23968);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(49817);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3748);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(95407);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57646);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(52767);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(88185);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_4__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_9__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_11__, _CartItem__WEBPACK_IMPORTED_MODULE_17__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_4__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_9__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_11__, _CartItem__WEBPACK_IMPORTED_MODULE_17__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










// import useCart from '@framework/cart/use-cart'
// import usePrice from '@framework/product/use-price'






const CartSidebarView = ()=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_9__/* .DataStore */ .K);
    const { cart  } = state;
    const { closeSidebar , setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_10__/* .useUI */ .l8)();
    // const { isLoading, isEmpty } = useCart()
    const isEmpty = cart.cartItems.length == 0 ? true : false;
    const isLoading = false;
    const handleClose = ()=>closeSidebar()
    ;
    const goToCheckout = ()=>setSidebarView("CHECKOUT_VIEW")
    ;
    const error = null;
    const success = null;
    const round2 = (num)=>Math.round(num * 100 + Number.EPSILON) / 100 // 123.456 => 123.46
    ;
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        const itemsPrice = round2(cart.cartItems.reduce((a, c)=>a + c.price.value * c.quantity
        , 0));
        setSubTotal(itemsPrice);
    }, [
        cart
    ]);
    const { 0: subTotal , 1: setSubTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const { 0: shipping , 1: setShipping  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(50);
    let total = round2(subTotal) + round2(shipping);
    const handleShippingChange = (event)=>{
        setShipping(event.target.value);
    };
    async function CheckoutCookieSet() {
        js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].set("orderInfo", JSON.stringify({
            subTotal: subTotal,
            total: total,
            shippingPrice: shipping
        }));
    // dispatch({ type: 'ORDER_INFO_SETUP', payload: JSON.stringify({subTotal: subTotal,total: total,shippingPrice: shipping})});
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()({
            [(_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_12___default().empty)]: error || success || isLoading || isEmpty
        }),
        handleClose: handleClose,
        children: isLoading || isEmpty ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-dashed border-primary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-secondary text-secondary",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                        className: "absolute"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-2xl font-bold tracking-wide text-center",
                    children: "Your cart is empty"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-accent-3 px-10 text-center pt-2",
                    children: "ice cream tiramisu pudding cupcake."
                })
            ]
        }) : error ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        width: 24,
                        height: 24
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-xl font-light text-center",
                    children: "We couldn\u2019t process the purchase. Please check your card information and try again."
                })
            ]
        }) : success ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-xl font-light text-center",
                    children: "Thank you for your order."
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/cart",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                    variant: "sectionHeading",
                                    onClick: handleClose,
                                    children: "My Cart"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: (_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_12___default().lineItemsList),
                            children: cart.cartItems.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CartItem__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                    item: item,
                                    currencyCode: item.price.currencyCode
                                }, item.id)
                            )
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "pb-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Total Items"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                "(",
                                                cart.cartItems.reduce((a, c)=>a + c.quantity
                                                , 0),
                                                " ",
                                                "items)"
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Subtotal"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: subTotal
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Shipping"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_8___default()), {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                "aria-labelledby": "demo-controlled-radio-buttons-group",
                                                name: "controlled-radio-buttons-group",
                                                value: shipping,
                                                onChange: handleShippingChange,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        value: 50,
                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_5___default()), {}),
                                                        label: "Delhi/ NCR - \u20B950"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        value: 80,
                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_5___default()), {}),
                                                        label: "NorthEast/ J&K - \u20B980"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                        value: 70,
                                                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_5___default()), {}),
                                                        label: "Rest Of India - \u20B970"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold tracking-wide",
                                            children: shipping
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Total"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: total
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children:  true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/shipping",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                        Component: "a",
                                        width: "100%",
                                        onClick: CheckoutCookieSet,
                                        children: [
                                            "Proceed to Checkout (",
                                            total,
                                            ")"
                                        ]
                                    })
                                })
                            }) : /*#__PURE__*/ 0
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartSidebarView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 16168:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(33564);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(44467);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(24106);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23968);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(57646);
/* harmony import */ var _framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18464);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(79747);
/* harmony import */ var _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(84823);
/* harmony import */ var _ShippingWidget__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(76566);
/* harmony import */ var _PaymentWidget__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5417);
/* harmony import */ var _CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(93668);
/* harmony import */ var _CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67282);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__, _components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__]);
([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__, _components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const CheckoutSidebarView = ()=>{
    const { 0: loadingSubmit , 1: setLoadingSubmit  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { setSidebarView , closeSidebar  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
    const { data: cartData , revalidate: refreshCart  } = (0,_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { data: checkoutData , submit: onCheckout  } = (0,_framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { clearCheckoutFields  } = (0,_context__WEBPACK_IMPORTED_MODULE_6__/* .useCheckoutContext */ .w6)();
    async function handleSubmit(event) {
        try {
            setLoadingSubmit(true);
            event.preventDefault();
            await onCheckout();
            clearCheckoutFields();
            setLoadingSubmit(false);
            refreshCart();
            closeSidebar();
        } catch  {
            // TODO - handle error UI here.
            setLoadingSubmit(false);
        }
    }
    const { price: subTotal  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(cartData && {
        amount: Number(cartData.subtotalPrice),
        currencyCode: cartData.currency.code
    });
    const { price: total  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(cartData && {
        amount: Number(cartData.totalPrice),
        currencyCode: cartData.currency.code
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        className: (_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default().root),
        handleBack: ()=>setSidebarView("CART_VIEW")
        ,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-4 sm:px-6 flex-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/cart",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                variant: "sectionHeading",
                                children: "Checkout"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentWidget__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        isValid: checkoutData?.hasPayment,
                        onClick: ()=>setSidebarView("PAYMENT_VIEW")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ShippingWidget__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        isValid: checkoutData?.hasShipping,
                        onClick: ()=>setSidebarView("SHIPPING_VIEW")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: (_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default().lineItemsList),
                        children: cartData.lineItems.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                item: item,
                                currencyCode: cartData.currency.code,
                                variant: "display"
                            }, item.id)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit,
                className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Subtotal"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: subTotal
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Taxes"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Calculated at checkout"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Shipping"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold tracking-wide",
                                        children: "FREE"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Total"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: total
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            type: "submit",
                            width: "100%",
                            disabled: !checkoutData?.hasPayment || !checkoutData?.hasShipping,
                            loading: loadingSubmit,
                            children: "Confirm Purchase"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckoutSidebarView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 62199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _framework_customer_card_use_add_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42616);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(44467);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24106);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23968);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57646);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(73207);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__]);
_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const PaymentMethodView = ()=>{
    const { setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    const addCard = (0,_framework_customer_card_use_add_item__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    async function handleSubmit(event) {
        event.preventDefault();
        await addCard({
            cardHolder: event.target.cardHolder.value,
            cardNumber: event.target.cardNumber.value,
            cardExpireDate: event.target.cardExpireDate.value,
            cardCvc: event.target.cardCvc.value,
            firstName: event.target.firstName.value,
            lastName: event.target.lastName.value,
            company: event.target.company.value,
            streetNumber: event.target.streetNumber.value,
            zipCode: event.target.zipCode.value,
            city: event.target.city.value,
            country: event.target.country.value
        });
        setSidebarView("CHECKOUT_VIEW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        className: "h-full",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            handleBack: ()=>setSidebarView("CHECKOUT_VIEW")
            ,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            variant: "sectionHeading",
                            children: " Payment Method"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Cardholder Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "cardHolder",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-7"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Card Number"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardNumber",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-3"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Expires"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardExpireDate",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input),
                                                    placeholder: "MM/YY"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-2"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "CVC"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardCvc",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    className: "border-accent-2 my-6"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "First Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "firstName",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Last Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "lastName",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Company (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "company",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Street and House Number"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "streetNumber",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Apartment, Suite, Etc. (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input),
                                            name: "apartment"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Postal Code"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "zipCode",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "City"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "city",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Country/Region"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            name: "country",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().select),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                children: "Hong Kong"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        type: "submit",
                        width: "100%",
                        variant: "ghost",
                        children: "Continue"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentMethodView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ PaymentWidget_PaymentWidget)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: ./components/checkout/PaymentWidget/PaymentWidget.module.css
var PaymentWidget_module = __webpack_require__(33195);
var PaymentWidget_module_default = /*#__PURE__*/__webpack_require__.n(PaymentWidget_module);
;// CONCATENATED MODULE: ./components/icons/CreditCard.tsx

const CreditCard = ({ ...props })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                x: "1",
                y: "4",
                width: "22",
                height: "16",
                rx: "2",
                ry: "2"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M1 10h22"
            })
        ]
    });
};
/* harmony default export */ const icons_CreditCard = (CreditCard);

// EXTERNAL MODULE: ./components/icons/Check.tsx
var Check = __webpack_require__(95407);
// EXTERNAL MODULE: ./components/icons/ChevronRight.tsx
var ChevronRight = __webpack_require__(41936);
;// CONCATENATED MODULE: ./components/checkout/PaymentWidget/PaymentWidget.tsx



const PaymentWidget = ({ onClick , isValid  })=>{
    /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */ return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        onClick: onClick,
        className: (PaymentWidget_module_default()).root,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-1 items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(icons_CreditCard, {
                        className: "w-5 flex"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "ml-5 text-sm text-center font-medium",
                        children: "Add Payment Method"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: isValid ? /*#__PURE__*/ jsx_runtime_.jsx(Check/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
            })
        ]
    });
};
/* harmony default export */ const PaymentWidget_PaymentWidget = (PaymentWidget);


/***/ }),

/***/ 55517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(24106);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23968);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57646);
/* harmony import */ var _framework_customer_address_use_add_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45195);
/* harmony import */ var _ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(15705);
/* harmony import */ var _ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__]);
_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ShippingView = ()=>{
    const { setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    const addAddress = (0,_framework_customer_address_use_add_item__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    async function handleSubmit(event) {
        event.preventDefault();
        await addAddress({
            type: event.target.type.value,
            firstName: event.target.firstName.value,
            lastName: event.target.lastName.value,
            company: event.target.company.value,
            streetNumber: event.target.streetNumber.value,
            apartments: event.target.streetNumber.value,
            zipCode: event.target.zipCode.value,
            city: event.target.city.value,
            country: event.target.country.value
        });
        setSidebarView("CHECKOUT_VIEW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        className: "h-full",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            handleBack: ()=>setSidebarView("CHECKOUT_VIEW")
            ,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "pt-1 pb-8 text-2xl font-semibold tracking-wide cursor-pointer inline-block",
                            children: "Shipping"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row my-3 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "type",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio),
                                            type: "radio"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "ml-3 text-sm",
                                            children: "Same as billing address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row my-3 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "type",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio),
                                            type: "radio"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "ml-3 text-sm",
                                            children: "Use a different shipping address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    className: "border-accent-2 my-6"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "First Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "firstName",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "Last Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "lastName",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Company (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "company",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Street and House Number"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "streetNumber",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Apartment, Suite, Etc. (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "apartments",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "Postal Code"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "zipCode",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "City"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "city",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Country/Region"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            name: "country",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().select),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                children: "Hong Kong"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: "submit",
                        width: "100%",
                        variant: "ghost",
                        children: "Continue"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShippingView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 76566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(55969);
/* harmony import */ var _ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76985);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(95407);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41936);



const ShippingWidget = ({ onClick , isValid  })=>{
    /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */ return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: onClick,
        className: (_ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-1 items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "w-5 flex"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ml-5 text-sm text-center font-medium",
                        children: "Add Shipping Address"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: isValid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShippingWidget);


/***/ }),

/***/ 67282:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "oo": () => (/* binding */ CheckoutProvider),
/* harmony export */   "w6": () => (/* binding */ useCheckoutContext)
/* harmony export */ });
/* unused harmony export CheckoutContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const initialState = {
    cardFields: {},
    addressFields: {}
};
const CheckoutContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(initialState);
CheckoutContext.displayName = "CheckoutContext";
const checkoutReducer = (state, action)=>{
    switch(action.type){
        case "SET_CARD_FIELDS":
            return {
                ...state,
                cardFields: action.card
            };
        case "SET_ADDRESS_FIELDS":
            return {
                ...state,
                addressFields: action.address
            };
        case "CLEAR_CHECKOUT_FIELDS":
            return {
                ...state,
                cardFields: initialState.cardFields,
                addressFields: initialState.addressFields
            };
        default:
            return state;
    }
};
const CheckoutProvider = (props)=>{
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(checkoutReducer, initialState);
    const setCardFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((card)=>dispatch({
            type: "SET_CARD_FIELDS",
            card
        })
    , [
        dispatch
    ]);
    const setAddressFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((address)=>dispatch({
            type: "SET_ADDRESS_FIELDS",
            address
        })
    , [
        dispatch
    ]);
    const clearCheckoutFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>dispatch({
            type: "CLEAR_CHECKOUT_FIELDS"
        })
    , [
        dispatch
    ]);
    const cardFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>state.cardFields
    , [
        state.cardFields
    ]);
    const addressFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>state.addressFields
    , [
        state.addressFields
    ]);
    const value = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            cardFields,
            addressFields,
            setCardFields,
            setAddressFields,
            clearCheckoutFields
        })
    , [
        cardFields,
        addressFields,
        setCardFields,
        setAddressFields,
        clearCheckoutFields
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CheckoutContext.Provider, {
        value: value,
        ...props
    });
};
const useCheckoutContext = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CheckoutContext);
    if (context === undefined) {
        throw new Error(`useCheckoutContext must be used within a CheckoutProvider`);
    }
    return context;
};


/***/ }),

/***/ 74833:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(52767);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_get_slug__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(83438);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(17381);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(40510);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(36108);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2524);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(73281);
/* harmony import */ var _mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(17666);
/* harmony import */ var _mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(85631);
/* harmony import */ var _mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_AddLocationAlt__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22369);
/* harmony import */ var _mui_icons_material_AddLocationAlt__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddLocationAlt__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(86872);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_10__]);
_utils_DataStore__WEBPACK_IMPORTED_MODULE_10__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const links = [
    {
        name: "Home",
        url: "/"
    },
    {
        name: "About",
        url: "/about"
    }, 
];
const Footer = ({ className , pages  })=>{
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_10__/* .DataStore */ .K);
    const { storeInfo  } = state;
    const { sitePages  } = usePages(pages);
    const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_2___default()((_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().root), className);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: rootClassName,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 lg:grid-cols-12 gap-8 border-b border-accent-2 py-12 text-primary bg-primary transition-colors duration-150",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-span-1 lg:col-span-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "flex flex-initial items-center font-bold md:mr-24",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                                    })
                                }),
                                storeInfo?.address.city ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    href: `/`,
                                    className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddLocationAlt__WEBPACK_IMPORTED_MODULE_8___default()), {}),
                                        " \xa0",
                                        storeInfo.address.city
                                    ]
                                }) : null,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                storeInfo?.phone ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                    href: `tel:${storeInfo.phone}`,
                                    className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_9___default()), {}),
                                        " \xa0",
                                        storeInfo.phone
                                    ]
                                }) : null
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-1 lg:col-span-8",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "grid md:grid-rows-4 md:grid-cols-3 md:grid-flow-col",
                                children: [
                                    [
                                        ...links,
                                        ...sitePages
                                    ].map((page)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "py-3 md:py-0 md:pb-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                href: page.url,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                                    children: page.name
                                                })
                                            })
                                        }, page.url)
                                    ),
                                    storeInfo?.policies?.RefundPolicyHtml ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "py-3 md:py-0 md:pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/policies/refund-policy",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                                children: "Refund Policy"
                                            })
                                        })
                                    }) : null,
                                    storeInfo?.policies?.PrivacyPolicyHtml ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "py-3 md:py-0 md:pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/policies/privacy-policy",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                                children: "Privacy Policy"
                                            })
                                        })
                                    }) : null,
                                    storeInfo?.policies?.ShippingPolicyHtml ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "py-3 md:py-0 md:pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/policies/shipping-policy",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                                children: "Shipping Policy"
                                            })
                                        })
                                    }) : null,
                                    storeInfo?.policies?.TermsOfServiceHtml ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "py-3 md:py-0 md:pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            href: "/policies/terms-of-services",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                                children: "Terms Of Services"
                                            })
                                        })
                                    }) : null
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-1 lg:col-span-2 flex items-start lg:justify-end text-primary",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex space-x-6 items-center h-10",
                                children: storeInfo ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        storeInfo.socialMediaLinks?.github ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                            "aria-label": "Github",
                                            href: storeInfo.socialMediaLinks?.github,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                                        }) : null,
                                        storeInfo.socialMediaLinks?.instagram ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                            "aria-label": "Instagram",
                                            href: storeInfo.socialMediaLinks?.instagram,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Instagram__WEBPACK_IMPORTED_MODULE_5___default()), {})
                                        }) : null,
                                        storeInfo.socialMediaLinks?.facebook ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                            "aria-label": "Facebook",
                                            href: storeInfo.socialMediaLinks?.facebook,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Facebook__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                        }) : null,
                                        storeInfo.socialMediaLinks?.twitter ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_11___default().link),
                                            "aria-label": "Twitter",
                                            href: storeInfo.socialMediaLinks?.twitter,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Twitter__WEBPACK_IMPORTED_MODULE_7___default()), {})
                                        }) : null
                                    ]
                                }) : null
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "pt-6 pb-10 flex flex-col md:flex-row justify-between items-center space-y-4 text-accent-6 text-sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "Powered By \xa9",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "https://makemycommerce.in/",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            children: " Make My Commerce"
                                        })
                                    }),
                                    " "
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center text-primary text-sm",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-primary",
                                    children: "All Right Reserved  @\xa0"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        rel: "noopener noreferrer",
                                        className: "text-primary",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
function usePages(pages) {
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const sitePages = [];
    if (pages) {
        pages.forEach((page)=>{
            const slug = page.url && (0,_lib_get_slug__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(page.url);
            if (!slug) return;
            if (locale && !slug.startsWith(`${locale}/`)) return;
            sitePages.push(page);
        });
    }
    return {
        sitePages: sitePages.sort(bySortOrder)
    };
}
// Sort pages by the sort order assigned in the BC dashboard
function bySortOrder(a, b) {
    return (a.sort_order ?? 0) - (b.sort_order ?? 0);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 50770:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _framework__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(44706);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(23968);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(62129);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(74833);
/* harmony import */ var _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(55517);
/* harmony import */ var _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(73763);
/* harmony import */ var _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(95453);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(74757);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(85210);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(24106);
/* harmony import */ var _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(62199);
/* harmony import */ var _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(16168);
/* harmony import */ var _components_checkout_context__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(67282);
/* harmony import */ var _UserNav_MenuSidebarView__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(31992);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(52767);
/* harmony import */ var _components_auth_LoginView__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(34520);
/* harmony import */ var _Layout_module_css__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(55739);
/* harmony import */ var _Layout_module_css__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_Layout_module_css__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _mui_icons_material_WhatsApp__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(12232);
/* harmony import */ var _mui_icons_material_WhatsApp__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_WhatsApp__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(93765);
/* harmony import */ var _mui_material_Alert__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Alert__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Collapse__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(15732);
/* harmony import */ var _mui_material_Collapse__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Collapse__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_13__, _UserNav_MenuSidebarView__WEBPACK_IMPORTED_MODULE_16__, _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_17__, _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_18__, _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_19__, _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_20__, _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_21__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_22__, _framework__WEBPACK_IMPORTED_MODULE_23__, _components_common__WEBPACK_IMPORTED_MODULE_25__, _components_common__WEBPACK_IMPORTED_MODULE_26__]);
([_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_13__, _UserNav_MenuSidebarView__WEBPACK_IMPORTED_MODULE_16__, _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_17__, _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_18__, _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_19__, _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_20__, _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_21__, _utils_DataStore__WEBPACK_IMPORTED_MODULE_22__, _framework__WEBPACK_IMPORTED_MODULE_23__, _components_common__WEBPACK_IMPORTED_MODULE_25__, _components_common__WEBPACK_IMPORTED_MODULE_26__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


























const Loading = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-80 h-80 flex items-center text-center justify-center p-3",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
    })
;
const dynamicProps = {
    loading: Loading
};
const SignUpView = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>__webpack_require__.e(/* import() */ 7413).then(__webpack_require__.bind(__webpack_require__, 67413))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\common\\Layout\\Layout.tsx -> " + "@components/auth/SignUpView"
        ]
    },
    ...dynamicProps
});
const ForgotPassword = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>__webpack_require__.e(/* import() */ 8099).then(__webpack_require__.bind(__webpack_require__, 48099))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\common\\Layout\\Layout.tsx -> " + "@components/auth/ForgotPassword"
        ]
    },
    ...dynamicProps
});
const FeatureBar = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>__webpack_require__.e(/* import() */ 7701).then(__webpack_require__.bind(__webpack_require__, 37701))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\common\\Layout\\Layout.tsx -> " + "@components/common/FeatureBar"
        ]
    },
    ...dynamicProps
});
const Modal = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\common\\Layout\\Layout.tsx -> " + "@components/ui/Modal"
        ]
    },
    ...dynamicProps,
    ssr: false
});
const ModalView = ({ modalView , closeModal ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Modal, {
        onClose: closeModal,
        children: [
            modalView === "LOGIN_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
            modalView === "SIGNUP_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SignUpView, {}),
            modalView === "FORGOT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ForgotPassword, {})
        ]
    });
};
const ModalUI = ()=>{
    const { displayModal , closeModal , modalView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_14__/* .useUI */ .l8)();
    return displayModal ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalView, {
        modalView: modalView,
        closeModal: closeModal
    }) : null;
};
const SidebarView = ({ sidebarView , closeSidebar , links  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
        onClose: closeSidebar,
        children: [
            sidebarView === "MOBILEMENU_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UserNav_MenuSidebarView__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                links: links
            }),
            sidebarView === "CART_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
            sidebarView === "CHECKOUT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {}),
            sidebarView === "PAYMENT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {}),
            sidebarView === "SHIPPING_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {})
        ]
    });
};
const SidebarUI = ({ links  })=>{
    const { displaySidebar , closeSidebar , sidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_14__/* .useUI */ .l8)();
    return displaySidebar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarView, {
        sidebarView: sidebarView,
        closeSidebar: closeSidebar,
        links: links
    }) : null;
};
const Layout = ({ children , pageProps: { categories =[] , ...pageProps } ,  })=>{
    const { acceptedCookies , onAcceptCookies  } = (0,_lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_21__/* .useAcceptCookies */ .X)();
    const { locale ="en-US"  } = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const navBarlinks = categories.slice(0, 2).map((c)=>({
            label: c.name,
            href: `/search/${c.slug}`
        })
    );
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_22__/* .DataStore */ .K);
    const { storeInfo  } = state;
    const [discountOpen, setDiscountOpen] = react__WEBPACK_IMPORTED_MODULE_2___default().useState(true);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_framework__WEBPACK_IMPORTED_MODULE_23__/* .CommerceProvider */ .SN, {
        locale: locale,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_Layout_module_css__WEBPACK_IMPORTED_MODULE_24___default().root)),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_6___default()), {
                    sx: {
                        width: "100%"
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Collapse__WEBPACK_IMPORTED_MODULE_10___default()), {
                        in: discountOpen,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Alert__WEBPACK_IMPORTED_MODULE_7___default()), {
                            action: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default()), {
                                "aria-label": "close",
                                color: "info",
                                size: "small",
                                onClick: ()=>{
                                    setDiscountOpen(false);
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    fontSize: "inherit"
                                })
                            }),
                            sx: {
                                mb: 2
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default()), {
                                align: "center",
                                sx: {
                                    fontWeight: 700
                                },
                                children: "Surprise Gift for Order above \u20B92000....\uD83D\uDE0D\uD83D\uDE0D"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                    links: navBarlinks
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    className: "fit",
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z, {
                    pages: pageProps.pages
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalUI, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_context__WEBPACK_IMPORTED_MODULE_27__/* .CheckoutProvider */ .oo, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarUI, {
                        links: navBarlinks
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FeatureBar, {
                    title: "This site uses cookies to improve your experience. By clicking, you agree to our Privacy Policy.",
                    hide: acceptedCookies,
                    action: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z, {
                        className: "mx-5",
                        onClick: ()=>onAcceptCookies()
                        ,
                        children: "Accept cookies"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    href: `https://api.whatsapp.com/send?phone=${storeInfo?.phone}&text=Hello`,
                    className: "float",
                    target: "_blank",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_WhatsApp__WEBPACK_IMPORTED_MODULE_5___default()), {
                        sx: {
                            fontSize: "2.6rem"
                        }
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 57646:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3748);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(76277);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(19933);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21092);
/* harmony import */ var _SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common__WEBPACK_IMPORTED_MODULE_6__]);
_components_common__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const SidebarLayout = ({ children , className , handleClose , handleBack ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                className: (_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().header),
                children: [
                    handleClose && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: handleClose,
                        "aria-label": "Close",
                        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none mr-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                className: "h-6 w-6 hover:text-accent-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ml-2 text-accent-7 text-sm ",
                                children: "Close"
                            })
                        ]
                    }),
                    handleBack && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: handleBack,
                        "aria-label": "Go back",
                        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "h-6 w-6 hover:text-accent-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ml-2 text-accent-7 text-xs",
                                children: "Back"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: (_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().nav),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().container),
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 31992:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58566);
/* harmony import */ var _MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23968);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57646);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const MenuSidebarView = (props)=>{
    const { closeSidebar  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    const handleClose = ()=>closeSidebar()
    ;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        handleClose: handleClose,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().root),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().item),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/search",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    children: "All"
                                })
                            })
                        }),
                        props.links?.map((l)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().item),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: l.href,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: l.label
                                    })
                                })
                            }, l.href)
                        )
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MenuSidebarView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95407:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Check = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M20 6L9 17L4 12",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Check);


/***/ }),

/***/ 76277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ChevronLeft = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M15 18l-6-6 6-6"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChevronLeft);


/***/ }),

/***/ 41936:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ChevronRight = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M9 18l6-6-6-6"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChevronRight);


/***/ }),

/***/ 3748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Cross = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M18 6L6 18"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M6 6l12 12"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cross);


/***/ }),

/***/ 17381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Github = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M12 0C5.37 0 0 5.50583 0 12.3035C0 17.7478 3.435 22.3463 8.205 23.9765C8.805 24.0842 9.03 23.715 9.03 23.3921C9.03 23.0999 9.015 22.131 9.015 21.1005C6 21.6696 5.22 20.347 4.98 19.6549C4.845 19.3012 4.26 18.2092 3.75 17.917C3.33 17.6863 2.73 17.1173 3.735 17.1019C4.68 17.0865 5.355 17.9939 5.58 18.363C6.66 20.2239 8.385 19.701 9.075 19.3781C9.18 18.5783 9.495 18.04 9.84 17.7325C7.17 17.4249 4.38 16.3637 4.38 11.6576C4.38 10.3196 4.845 9.21227 5.61 8.35102C5.49 8.04343 5.07 6.78232 5.73 5.09058C5.73 5.09058 6.735 4.76762 9.03 6.3517C9.99 6.07487 11.01 5.93645 12.03 5.93645C13.05 5.93645 14.07 6.07487 15.03 6.3517C17.325 4.75224 18.33 5.09058 18.33 5.09058C18.99 6.78232 18.57 8.04343 18.45 8.35102C19.215 9.21227 19.68 10.3042 19.68 11.6576C19.68 16.3791 16.875 17.4249 14.205 17.7325C14.64 18.1169 15.015 18.8552 15.015 20.0086C15.015 21.6542 15 22.9768 15 23.3921C15 23.715 15.225 24.0995 15.825 23.9765C18.2072 23.1519 20.2773 21.5822 21.7438 19.4882C23.2103 17.3942 23.9994 14.8814 24 12.3035C24 5.50583 18.63 0 12 0Z",
            fill: "currentColor"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Github);


/***/ }),

/***/ 76985:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const MapPin = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                cx: "12",
                cy: "10",
                r: "3"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapPin);


/***/ }),

/***/ 59795:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Quantity_Quantity)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./components/ui/Quantity/Quantity.module.css
var Quantity_module = __webpack_require__(86442);
var Quantity_module_default = /*#__PURE__*/__webpack_require__.n(Quantity_module);
;// CONCATENATED MODULE: ./components/icons/Minus.tsx

const Minus = ({ ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M5 12H19",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const icons_Minus = (Minus);

;// CONCATENATED MODULE: ./components/icons/Plus.tsx

const Plus = ({ ...props })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12 5V19",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 12H19",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};
/* harmony default export */ const icons_Plus = (Plus);

// EXTERNAL MODULE: ./components/icons/Cross.tsx
var Cross = __webpack_require__(3748);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(59003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./components/ui/Quantity/Quantity.tsx





const Quantity = ({ value , increase , decrease , handleChange , handleRemove , max =6 ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row h-9",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: (Quantity_module_default()).actions,
                onClick: handleRemove,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Cross/* default */.Z, {
                    width: 20,
                    height: 20
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "w-full border-accent-2 border ml-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    className: (Quantity_module_default()).input,
                    onChange: (e)=>Number(e.target.value) < max + 1 ? handleChange(e) : ()=>{}
                    ,
                    value: value,
                    type: "number",
                    max: max,
                    min: "0",
                    readOnly: true
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                onClick: decrease,
                className: (Quantity_module_default()).actions,
                style: {
                    marginLeft: "-1px"
                },
                disabled: value <= 1,
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Minus, {
                    width: 18,
                    height: 18
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                onClick: increase,
                className: external_classnames_default()((Quantity_module_default()).actions),
                style: {
                    marginLeft: "-1px"
                },
                disabled: value < 1 || value >= max,
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Plus, {
                    width: 18,
                    height: 18
                })
            })
        ]
    });
};
/* harmony default export */ const Quantity_Quantity = (Quantity);


/***/ }),

/***/ 85210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(99793);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25782);
/* harmony import */ var body_scroll_lock__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__);





const Sidebar = ({ children , onClose  })=>{
    const sidebarRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const onKeyDownSidebar = (event)=>{
        if (event.code === "Escape") {
            onClose();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (sidebarRef.current) {
            sidebarRef.current.focus();
        }
        const contentElement = contentRef.current;
        if (contentElement) {
            (0,body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__.disableBodyScroll)(contentElement, {
                reserveScrollBarGap: true
            });
        }
        return ()=>{
            (0,body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__.clearAllBodyScrollLocks)();
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().root)),
        ref: sidebarRef,
        onKeyDown: onKeyDownSidebar,
        tabIndex: 1,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "absolute inset-0 overflow-hidden",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().backdrop),
                    onClick: onClose
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "absolute inset-y-0 right-0 w-full md:w-auto max-w-full flex outline-none md:pl-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-full w-full md:w-screen md:max-w-md",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().sidebar),
                            ref: contentRef,
                            children: children
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);


/***/ }),

/***/ 32285:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export fetcher */
/* harmony import */ var _utils_use_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9789);
/* harmony import */ var _utils_default_fetcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5849);


const fetcher = _utils_default_fetcher__WEBPACK_IMPORTED_MODULE_0__/* .mutationFetcher */ .B5;
const fn = (provider)=>provider.cart?.useAddItem
;
const useAddItem = (...args)=>{
    const hook = (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useHook */ .dV)(fn);
    return (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useMutationHook */ .wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAddItem);


/***/ }),

/***/ 48824:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export fetcher */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(69915);
/* harmony import */ var _utils_use_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9789);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87101);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetcher = async ({ options , input: { cartId  } , fetch ,  })=>{
    return cartId ? await fetch(options) : null;
};
const fn = (provider)=>provider.cart?.useCart
;
const useCart = (input)=>{
    const hook = (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useHook */ .dV)(fn);
    const { cartCookie  } = (0,___WEBPACK_IMPORTED_MODULE_2__/* .useCommerce */ .aF)();
    const fetcherFn = hook.fetcher ?? fetcher;
    const wrapper = (context)=>{
        context.input.cartId = js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(cartCookie);
        return fetcherFn(context);
    };
    return (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useSWRHook */ .Lz)({
        ...hook,
        fetcher: wrapper
    })(input);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98370:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export fetcher */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(69915);
/* harmony import */ var _utils_use_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9789);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87101);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetcher = async ({ options , input: { cartId  } , fetch ,  })=>{
    return cartId ? await fetch(options) : null;
};
const fn = (provider)=>provider.checkout?.useCheckout
;
const useCheckout = (input)=>{
    const hook = (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useHook */ .dV)(fn);
    const { cartCookie  } = (0,___WEBPACK_IMPORTED_MODULE_2__/* .useCommerce */ .aF)();
    const fetcherFn = hook.fetcher ?? fetcher;
    const wrapper = (context)=>{
        context.input.cartId = js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(cartCookie);
        return fetcherFn(context);
    };
    return (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useSWRHook */ .Lz)({
        ...hook,
        fetcher: wrapper
    })(input);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCheckout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 87101:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DX": () => (/* binding */ getCommerceProvider),
/* harmony export */   "aF": () => (/* binding */ useCommerce)
/* harmony export */ });
/* unused harmony export CoreCommerceProvider */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Commerce = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
function CoreCommerceProvider({ provider , children  }) {
    const providerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(provider);
    // TODO: Remove the fetcherRef
    const fetcherRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(provider.fetcher);
    // If the parent re-renders this provider will re-render every
    // consumer unless we memoize the config
    const { locale , cartCookie  } = providerRef.current;
    const cfg = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            providerRef,
            fetcherRef,
            locale,
            cartCookie
        })
    , [
        locale,
        cartCookie
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Commerce.Provider, {
        value: cfg,
        children: children
    });
}
function getCommerceProvider(provider) {
    return function CommerceProvider({ children , ...props }) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoreCommerceProvider, {
            provider: {
                ...provider,
                ...props
            },
            children: children
        });
    };
}
function useCommerce() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Commerce);
}


/***/ }),

/***/ 79747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ usePrice)
/* harmony export */ });
/* unused harmony exports formatPrice, formatVariantPrice */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(87101);


function formatPrice({ amount , currencyCode , locale  }) {
    const formatCurrency = new Intl.NumberFormat(locale, {
        style: "currency",
        currency: currencyCode
    });
    return formatCurrency.format(amount);
}
function formatVariantPrice({ amount , baseAmount , currencyCode , locale  }) {
    const hasDiscount = baseAmount > amount;
    const formatDiscount = new Intl.NumberFormat(locale, {
        style: "percent"
    });
    const discount = hasDiscount ? formatDiscount.format((baseAmount - amount) / baseAmount) : null;
    const price = formatPrice({
        amount,
        currencyCode,
        locale
    });
    const basePrice = hasDiscount ? formatPrice({
        amount: baseAmount,
        currencyCode,
        locale
    }) : null;
    return {
        price,
        basePrice,
        discount
    };
}
function usePrice(data) {
    const { amount , baseAmount , currencyCode  } = data ?? {};
    const { locale  } = (0,___WEBPACK_IMPORTED_MODULE_1__/* .useCommerce */ .aF)();
    const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (typeof amount !== "number" || !currencyCode) return "";
        return baseAmount ? formatVariantPrice({
            amount,
            baseAmount,
            currencyCode,
            locale
        }) : formatPrice({
            amount,
            currencyCode,
            locale
        });
    }, [
        amount,
        baseAmount,
        currencyCode
    ]);
    return typeof value === "string" ? {
        price: value
    } : value;
};


/***/ }),

/***/ 5849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B5": () => (/* binding */ mutationFetcher),
/* harmony export */   "DO": () => (/* binding */ SWRFetcher)
/* harmony export */ });
const SWRFetcher = ({ options , fetch  })=>fetch(options)
;
const mutationFetcher = ({ input , options , fetch ,  })=>fetch({
        ...options,
        body: input
    })
;
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SWRFetcher)));


/***/ }),

/***/ 48428:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T4": () => (/* binding */ FetcherError),
/* harmony export */   "yG": () => (/* binding */ CommerceError)
/* harmony export */ });
/* unused harmony export ValidationError */
class CommerceError extends Error {
    constructor({ message , code , errors  }){
        const error = message ? {
            message,
            ...code ? {
                code
            } : {}
        } : errors[0];
        super(error.message);
        this.errors = message ? [
            error
        ] : errors;
        if (error.code) this.code = error.code;
    }
}
// Used for errors that come from a bad implementation of the hooks
class ValidationError extends (/* unused pure expression or super */ null && (CommerceError)) {
    constructor(options){
        super(options);
        this.code = "validation_error";
    }
}
class FetcherError extends CommerceError {
    constructor(options){
        super(options);
        this.status = options.status;
    }
}


/***/ }),

/***/ 9789:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "dV": () => (/* binding */ useHook),
  "wf": () => (/* binding */ useMutationHook),
  "Lz": () => (/* binding */ useSWRHook)
});

// UNUSED EXPORTS: useFetcher

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./framework/commerce/index.tsx
var commerce = __webpack_require__(87101);
// EXTERNAL MODULE: external "swr"
var external_swr_ = __webpack_require__(549);
var external_swr_default = /*#__PURE__*/__webpack_require__.n(external_swr_);
;// CONCATENATED MODULE: ./framework/commerce/utils/define-property.ts
function defineProperty(obj, prop, val) {
    Object.defineProperty(obj, prop, val);
};

// EXTERNAL MODULE: ./framework/commerce/utils/errors.ts
var errors = __webpack_require__(48428);
;// CONCATENATED MODULE: ./framework/commerce/utils/use-data.tsx



const useData = (options, input, fetcherFn, swrOptions)=>{
    const hookInput = Array.isArray(input) ? input : Object.entries(input);
    const fetcher = async (url, query, method, ...args)=>{
        try {
            return await options.fetcher({
                options: {
                    url,
                    query,
                    method
                },
                // Transform the input array into an object
                input: args.reduce((obj, val, i)=>{
                    obj[hookInput[i][0]] = val;
                    return obj;
                }, {}),
                fetch: fetcherFn
            });
        } catch (error) {
            // SWR will not log errors, but any error that's not an instance
            // of CommerceError is not welcomed by this hook
            if (!(error instanceof errors/* CommerceError */.yG)) {
                console.error(error);
            }
            throw error;
        }
    };
    const response = external_swr_default()(()=>{
        const opts = options.fetchOptions;
        return opts ? [
            opts.url,
            opts.query,
            opts.method,
            ...hookInput.map((e)=>e[1]
            )
        ] : null;
    }, fetcher, swrOptions);
    if (!("isLoading" in response)) {
        defineProperty(response, "isLoading", {
            get () {
                return response.data === undefined;
            },
            enumerable: true
        });
    }
    return response;
};
/* harmony default export */ const use_data = (useData);

;// CONCATENATED MODULE: ./framework/commerce/utils/use-hook.ts



function useFetcher() {
    const { providerRef , fetcherRef  } = (0,commerce/* useCommerce */.aF)();
    return providerRef.current.fetcher ?? fetcherRef.current;
}
function useHook(fn) {
    const { providerRef  } = (0,commerce/* useCommerce */.aF)();
    const provider = providerRef.current;
    return fn(provider);
}
function useSWRHook(hook) {
    const fetcher = useFetcher();
    return hook.useHook({
        useData (ctx) {
            const response = use_data(hook, ctx?.input ?? [], fetcher, ctx?.swrOptions);
            return response;
        }
    });
}
function useMutationHook(hook) {
    const fetcher = useFetcher();
    return hook.useHook({
        fetch: (0,external_react_.useCallback)(({ input  } = {})=>{
            return hook.fetcher({
                input,
                options: hook.fetchOptions,
                fetch: fetcher
            });
        }, [
            fetcher,
            hook.fetchOptions
        ])
    });
}


/***/ }),

/***/ 93489:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(48428);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);



/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useLogin)));
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input: { email , password  }  }) {
        if (!(email && password)) {
            throw new _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_1__/* .CommerceError */ .yG({
                message: "An email and password are required to login"
            });
        }
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("/api/customer/login", {
            email,
            password
        });
        return data;
    },
    useHook: ()=>()=>{
            return async function() {};
        }
};


/***/ }),

/***/ 68610:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useLogout)));
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher () {
        return null;
    },
    useHook: ({ fetch  })=>()=>async ()=>{}
};


/***/ }),

/***/ 82711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _customer_use_customer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(74215);
/* harmony import */ var _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48428);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);





/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (useSignup)));
const handler = {
    fetchOptions: {
        url: "/api/customer/register",
        method: "POST"
    },
    async fetcher ({ input: { firstName , lastName , email , password  } , options , fetch ,  }) {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/api/customer/register", {
            firstName,
            lastName,
            email,
            password
        });
        if (!(firstName && lastName && email && password)) {
            throw new _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_2__/* .CommerceError */ .yG({
                message: "A first name, last name, email and password are required to signup"
            });
        }
        return data;
    },
    useHook: ({ fetch  })=>()=>{
            const { revalidate  } = (0,_customer_use_customer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
            return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async function signup(input) {
                const data = await fetch({
                    input
                });
                await revalidate();
                return data;
            }, [
                fetch,
                revalidate
            ]);
        }
};


/***/ }),

/***/ 87098:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(48428);
/* harmony import */ var _commerce_cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32285);
/* harmony import */ var _use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(18464);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_use_cart__WEBPACK_IMPORTED_MODULE_4__]);
_use_cart__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_commerce_cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z);
const handler = {
    fetchOptions: {
        url: "/api/cart/add-item",
        method: "POST"
    },
    async fetcher ({ input: item , options , fetch  }) {
        console.log("use-add");
        if (item.quantity && (!Number.isInteger(item.quantity) || item.quantity < 1)) {
            throw new _commerce_utils_errors__WEBPACK_IMPORTED_MODULE_3__/* .CommerceError */ .yG({
                message: "The item quantity has to be a valid integer greater than 0"
            });
        }
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().post("/api/cart/add-item", {
            item: item
        });
        console.log(data.data);
        console.log(data.data.lineItems);
        // console.log(options)
        // console.log(item)
        // const data = await fetch({
        //   url: '/api/cart/add-item',
        //   method: 'POST',
        //   body: JSON.stringify({ item }),
        // })
        return data.data;
    },
    useHook: ({ fetch  })=>()=>{
            const { mutate  } = (0,_use_cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
            return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async function addItem(input) {
                const data = await fetch({
                    input
                });
                await mutate(data, false);
                return data;
            }, [
                fetch,
                mutate
            ]);
        }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 18464:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48824);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_2__]);
_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z);
const handler = {
    fetchOptions: {
        url: "/api/cart/get-cart",
        method: "GET"
    },
    async fetcher () {
        const data = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("/api/cart/get-cart");
        return data.data;
    },
    useHook: ({ useData  })=>(input)=>{
            const response = useData({
                swrOptions: {
                    revalidateOnFocus: false,
                    ...input?.swrOptions
                }
            });
            return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>Object.create(response, {
                    isEmpty: {
                        get () {
                            return (response.data?.lineItems.length ?? 0) <= 0;
                        },
                        enumerable: true
                    }
                })
            , [
                response
            ]);
        }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 46704:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_remove_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-remove-item.tsx


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>provider.cart?.useRemoveItem
;
const useRemoveItem = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_remove_item = (useRemoveItem);

;// CONCATENATED MODULE: ./framework/local/cart/use-remove-item.tsx

/* harmony default export */ const cart_use_remove_item = (use_remove_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>{
            return async function removeItem(input) {
                return {};
            };
        }
};


/***/ }),

/***/ 42639:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_update_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/cart/use-update-item.tsx


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>provider.cart?.useUpdateItem
;
const useUpdateItem = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_update_item = (useUpdateItem);

;// CONCATENATED MODULE: ./framework/local/cart/use-update-item.tsx

/* harmony default export */ const cart_use_update_item = (use_update_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>{
            return async function addItem() {
                return {};
            };
        }
};


/***/ }),

/***/ 84823:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export handler */
/* harmony import */ var _commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(98370);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__]);
_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ useData  })=>async (input)=>({})
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 45195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ address_use_add_item)
});

// UNUSED EXPORTS: handler

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/customer/address/use-add-item.tsx


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>provider.customer?.address?.useAddItem
;
const useAddItem = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_add_item = (useAddItem);

;// CONCATENATED MODULE: ./framework/local/customer/address/use-add-item.tsx

/* harmony default export */ const address_use_add_item = (use_add_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>async ()=>({})
};


/***/ }),

/***/ 42616:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ card_use_add_item)
});

// UNUSED EXPORTS: handler

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/customer/card/use-add-item.tsx


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>provider.customer?.card?.useAddItem
;
const useAddItem = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_add_item = (useAddItem);

;// CONCATENATED MODULE: ./framework/local/customer/card/use-add-item.tsx

/* harmony default export */ const card_use_add_item = (use_add_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>async ()=>({})
};


/***/ }),

/***/ 74215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ customer_use_customer),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/customer/use-customer.tsx


const fetcher = default_fetcher/* SWRFetcher */.DO;
const fn = (provider)=>provider.customer?.useCustomer
;
const useCustomer = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useSWRHook */.Lz)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_customer = (useCustomer);

;// CONCATENATED MODULE: ./framework/local/customer/use-customer.tsx

/* harmony default export */ const customer_use_customer = (use_customer);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ()=>()=>{
            return async function addItem() {
                return {};
            };
        }
};


/***/ }),

/***/ 17570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ fetcher)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(52167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

const fetcher = async ()=>{
    const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0___default().post("/api/products", {
        _id: process.env.STORE_OBJECT_ID
    });
    return data.physicalProducts;
};


/***/ }),

/***/ 44706:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SN": () => (/* binding */ CommerceProvider)
/* harmony export */ });
/* unused harmony export useCommerce */
/* harmony import */ var _commerce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(87101);
/* harmony import */ var _provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66116);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_provider__WEBPACK_IMPORTED_MODULE_1__]);
_provider__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const CommerceProvider = (0,_commerce__WEBPACK_IMPORTED_MODULE_0__/* .getCommerceProvider */ .DX)(_provider__WEBPACK_IMPORTED_MODULE_1__/* .localProvider */ .W);
const useCommerce = ()=>useCoreCommerce()
;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 50606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_use_search),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./framework/commerce/utils/use-hook.ts + 2 modules
var use_hook = __webpack_require__(9789);
// EXTERNAL MODULE: ./framework/commerce/utils/default-fetcher.ts
var default_fetcher = __webpack_require__(5849);
;// CONCATENATED MODULE: ./framework/commerce/product/use-search.tsx


const fetcher = default_fetcher/* SWRFetcher */.DO;
const fn = (provider)=>provider.products?.useSearch
;
const useSearch = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useSWRHook */.Lz)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_search = (useSearch);

;// CONCATENATED MODULE: ./framework/local/product/use-search.tsx

/* harmony default export */ const product_use_search = (use_search);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ()=>()=>{
            return {
                data: {
                    products: []
                }
            };
        }
};


/***/ }),

/***/ 66116:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ localProvider)
/* harmony export */ });
/* harmony import */ var _fetcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(17570);
/* harmony import */ var _cart_use_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18464);
/* harmony import */ var _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(87098);
/* harmony import */ var _cart_use_update_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(42639);
/* harmony import */ var _cart_use_remove_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(46704);
/* harmony import */ var _customer_use_customer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74215);
/* harmony import */ var _product_use_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(50606);
/* harmony import */ var _auth_use_login__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(93489);
/* harmony import */ var _auth_use_logout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(68610);
/* harmony import */ var _auth_use_signup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(82711);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__, _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__]);
([_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__, _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const localProvider = {
    locale: "en-us",
    cartCookie: "session",
    fetcher: _fetcher__WEBPACK_IMPORTED_MODULE_0__/* .fetcher */ ._,
    cart: {
        useCart: _cart_use_cart__WEBPACK_IMPORTED_MODULE_1__/* .handler */ .y,
        useAddItem: _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__/* .handler */ .y,
        useUpdateItem: _cart_use_update_item__WEBPACK_IMPORTED_MODULE_3__/* .handler */ .y,
        useRemoveItem: _cart_use_remove_item__WEBPACK_IMPORTED_MODULE_4__/* .handler */ .y
    },
    customer: {
        useCustomer: _customer_use_customer__WEBPACK_IMPORTED_MODULE_5__/* .handler */ .y
    },
    products: {
        useSearch: _product_use_search__WEBPACK_IMPORTED_MODULE_6__/* .handler */ .y
    },
    auth: {
        useLogin: _auth_use_login__WEBPACK_IMPORTED_MODULE_7__/* .handler */ .y,
        useLogout: _auth_use_logout__WEBPACK_IMPORTED_MODULE_8__/* .handler */ .y,
        useSignup: _auth_use_signup__WEBPACK_IMPORTED_MODULE_9__/* .handler */ .y
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 83438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = (path)=>path.replace(/^\/|\/$/g, "")
;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSlug);


/***/ }),

/***/ 95453:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useAcceptCookies)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(69915);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const COOKIE_NAME = "accept_cookies";
const useAcceptCookies = ()=>{
    const { 0: acceptedCookies , 1: setAcceptedCookies  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(COOKIE_NAME)) {
            setAcceptedCookies(false);
        }
    }, []);
    const acceptCookies = ()=>{
        setAcceptedCookies(true);
        js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set(COOKIE_NAME, "accepted", {
            expires: 365
        });
    };
    return {
        acceptedCookies,
        onAcceptCookies: acceptCookies
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;