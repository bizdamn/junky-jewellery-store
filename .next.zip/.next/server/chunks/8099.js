exports.id = 8099;
exports.ids = [8099];
exports.modules = {

/***/ 3411:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Input_root__eG6Wl"
};


/***/ }),

/***/ 8268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ auth_ForgotPassword)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "email-validator"
var external_email_validator_ = __webpack_require__(1072);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(3968);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./components/ui/Input/Input.module.css
var Input_module = __webpack_require__(3411);
var Input_module_default = /*#__PURE__*/__webpack_require__.n(Input_module);
;// CONCATENATED MODULE: ./components/ui/Input/Input.tsx




const Input = (props)=>{
    const { className , children , onChange , ...rest } = props;
    const rootClassName = external_classnames_default()((Input_module_default()).root, {}, className);
    const handleOnChange = (e)=>{
        if (onChange) {
            onChange(e.target.value);
        }
        return null;
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("label", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
            className: rootClassName,
            onChange: handleOnChange,
            autoComplete: "off",
            autoCorrect: "off",
            autoCapitalize: "off",
            spellCheck: "false",
            ...rest
        })
    });
};
/* harmony default export */ const Input_Input = (Input);

// EXTERNAL MODULE: ./components/ui/Logo/Logo.tsx
var Logo = __webpack_require__(6108);
// EXTERNAL MODULE: ./components/ui/Button/Button.tsx
var Button = __webpack_require__(4106);
;// CONCATENATED MODULE: ./components/auth/ForgotPassword.tsx





const ForgotPassword = ()=>{
    // Form State
    const { 0: email , 1: setEmail  } = (0,external_react_.useState)("");
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    const { 0: message , 1: setMessage  } = (0,external_react_.useState)("");
    const { 0: dirty , 1: setDirty  } = (0,external_react_.useState)(false);
    const { 0: disabled , 1: setDisabled  } = (0,external_react_.useState)(false);
    const { setModalView , closeModal  } = (0,context/* useUI */.l8)();
    const handleResetPassword = async (e)=>{
        e.preventDefault();
        if (!dirty && !disabled) {
            setDirty(true);
            handleValidation();
        }
    };
    const handleValidation = (0,external_react_.useCallback)(()=>{
        // Unable to send form unless fields are valid.
        if (dirty) {
            setDisabled(!(0,external_email_validator_.validate)(email));
        }
    }, [
        email,
        dirty
    ]);
    (0,external_react_.useEffect)(()=>{
        handleValidation();
    }, [
        handleValidation
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        onSubmit: handleResetPassword,
        className: "w-80 flex flex-col justify-between p-3",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex justify-center pb-12 ",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Logo/* default */.Z, {
                    width: "64px",
                    height: "64px"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col space-y-4",
                children: [
                    message && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "text-red border border-red p-3",
                        children: message
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Input_Input, {
                        placeholder: "Email",
                        onChange: setEmail,
                        type: "email"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "pt-2 w-full flex flex-col",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                            variant: "slim",
                            type: "submit",
                            loading: loading,
                            disabled: disabled,
                            children: "Recover Password"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "pt-3 text-center text-sm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "text-accent-7",
                                children: "Do you have an account?"
                            }),
                            ` `,
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "text-accent-9 font-bold hover:underline cursor-pointer",
                                onClick: ()=>setModalView("LOGIN_VIEW")
                                ,
                                children: "Log In"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const auth_ForgotPassword = (ForgotPassword);


/***/ })

};
;