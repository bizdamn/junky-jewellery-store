"use strict";
exports.id = 174;
exports.ids = [174];
exports.modules = {

/***/ 20174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ChartComponent)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@mui/material/Paper"
var Paper_ = __webpack_require__(21598);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper_);
// EXTERNAL MODULE: external "@devexpress/dx-react-chart-material-ui"
var dx_react_chart_material_ui_ = __webpack_require__(92000);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(18442);
// EXTERNAL MODULE: external "@devexpress/dx-react-chart"
var dx_react_chart_ = __webpack_require__(37640);
;// CONCATENATED MODULE: ./components/data-vizualization.js
const confidence = [
    {
        year: 3,
        tvNews: 9,
        church: 29,
        military: 32
    },
    {
        year: 5,
        tvNews: 3,
        church: 32,
        military: 33
    },
    {
        year: 7,
        tvNews: 4,
        church: 35,
        military: 30
    },
    {
        year: 9,
        tvNews: 3,
        church: 32,
        military: 34
    },
    {
        year: 1,
        tvNews: 5,
        church: 28,
        military: 32
    },
    {
        year: 3,
        tvNews: 6,
        church: 27,
        military: 48
    },
    {
        year: 6,
        tvNews: 2,
        church: 28,
        military: 41
    },
    {
        year: 8,
        tvNews: 1,
        church: 26,
        military: 45
    },
    {
        year: 0,
        tvNews: 0,
        church: 25,
        military: 44
    },
    {
        year: 2,
        tvNews: 1,
        church: 25,
        military: 43
    },
    {
        year: 4,
        tvNews: 0,
        church: 25,
        military: 39
    },
    {
        year: 6,
        tvNews: 8,
        church: 20,
        military: 41
    },
    {
        year: 8,
        tvNews: 0,
        church: 20,
        military: 43
    }, 
];

;// CONCATENATED MODULE: ./pages/admin/analytics/chart.jsx







const PREFIX = "Demo";
const classes = {
    chart: `${PREFIX}-chart`
};
const format = ()=>(tick)=>tick
;
const Root = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.Legend.Root, {
        ...props,
        sx: {
            display: "flex",
            margin: "auto",
            flexDirection: "row"
        }
    })
;
const Label = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.Legend.Label, {
        sx: {
            pt: 1,
            whiteSpace: "nowrap"
        },
        ...props
    })
;
const Item = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.Legend.Item, {
        sx: {
            flexDirection: "column"
        },
        ...props
    })
;
const ValueLabel = (props)=>{
    const { text  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.ValueAxis.Label, {
        ...props,
        text: `${text}%`
    });
};
const StyledChart = (0,styles_.styled)(dx_react_chart_material_ui_.Chart)(()=>({
        [`&.${classes.chart}`]: {
            paddingRight: "20px"
        }
    })
);
class ChartComponent extends external_react_.PureComponent {
    constructor(props){
        super(props);
        this.state = {
            data: confidence
        };
    }
    render() {
        const { data: chartData  } = this.state;
        return /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(StyledChart, {
                data: chartData,
                className: classes.chart,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.ArgumentAxis, {
                        tickFormat: format
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.ValueAxis, {
                        max: 51,
                        labelComponent: ValueLabel
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.LineSeries, {
                        name: "TV news",
                        valueField: "tvNews",
                        argumentField: "year"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.LineSeries, {
                        name: "Church",
                        valueField: "church",
                        argumentField: "year"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.LineSeries, {
                        name: "Military",
                        valueField: "military",
                        argumentField: "year"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_material_ui_.Legend, {
                        position: "bottom",
                        rootComponent: Root,
                        itemComponent: Item,
                        labelComponent: Label
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(dx_react_chart_.Animation, {})
                ]
            })
        });
    }
};


/***/ })

};
;