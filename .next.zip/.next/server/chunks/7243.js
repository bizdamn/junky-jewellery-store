exports.id = 7243;
exports.ids = [7243];
exports.modules = {

/***/ 1208:
/***/ ((module) => {

// Exports
module.exports = {
	"skeleton": "Skeleton_skeleton__5r66i",
	"loading": "Skeleton_loading__rv977",
	"wrapper": "Skeleton_wrapper__KY8KJ",
	"show": "Skeleton_show__wL69o"
};


/***/ }),

/***/ 3178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Search)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(770);
/* harmony import */ var _components_product__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4437);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(510);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8190);
/* harmony import */ var _framework_product_use_search__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(606);
/* harmony import */ var _lib_get_slug__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3438);
/* harmony import */ var _lib_range_map__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2178);
/* harmony import */ var _lib_search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6457);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_product__WEBPACK_IMPORTED_MODULE_9__, _components_common__WEBPACK_IMPORTED_MODULE_12__]);
([_components_product__WEBPACK_IMPORTED_MODULE_9__, _components_common__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const SORT = {
    "trending-desc": "Trending",
    "latest-desc": "Latest arrivals",
    "price-asc": "Price: Low to high",
    "price-desc": "Price: High to low"
};

function Search({ categories , brands  }) {
    const { 0: activeFilter , 1: setActiveFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("");
    const { 0: toggleFilter , 1: setToggleFilter  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { asPath , locale  } = router;
    const { q , sort  } = router.query;
    // `q` can be included but because categories and designers can't be searched
    // in the same way of products, it's better to ignore the search input if one
    // of those is selected
    const query = (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .filterQuery */ .DQ)({
        sort
    });
    const { pathname , category , brand  } = (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .useSearchMeta */ .Ob)(asPath);
    const activeCategory = categories.find((cat)=>cat.slug === category
    );
    const activeBrand = brands.find((b)=>(0,_lib_get_slug__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(b.node.path) === `brands/${brand}`
    )?.node;
    const { data  } = (0,_framework_product_use_search__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)({
        search: typeof q === "string" ? q : "",
        categoryId: activeCategory?.id,
        brandId: activeBrand?.entityId,
        sort: typeof sort === "string" ? sort : "",
        locale
    });
    const handleClick = (event, filter)=>{
        if (filter !== activeFilter) {
            setToggleFilter(true);
        } else {
            setToggleFilter(!toggleFilter);
        }
        setActiveFilter(filter);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "grid grid-cols-1 lg:grid-cols-12 gap-4 mt-3 mb-20",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-span-8 lg:col-span-2 order-1 lg:order-none",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative inline-block w-full",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "lg:hidden",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "rounded-md shadow-sm",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            type: "button",
                                            onClick: (e)=>handleClick(e, "categories")
                                            ,
                                            className: "flex justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-4 hover:text-accent-5 focus:outline-none focus:border-blue-300 focus:shadow-outline-normal active:bg-accent-1 active:text-accent-8 transition ease-in-out duration-150",
                                            id: "options-menu",
                                            "aria-haspopup": "true",
                                            "aria-expanded": "true",
                                            children: [
                                                activeCategory?.name ? `Category: ${activeCategory?.name}` : "All Categories",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    className: "-mr-1 ml-2 h-5 w-5",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 20 20",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        fillRule: "evenodd",
                                                        d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",
                                                        clipRule: "evenodd"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `origin-top-left absolute lg:relative left-0 mt-2 w-full rounded-md shadow-lg lg:shadow-none z-10 mb-10 lg:block ${activeFilter !== "categories" || toggleFilter !== true ? "hidden" : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "rounded-sm bg-accent-0 shadow-xs lg:bg-none lg:shadow-none",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            role: "menu",
                                            "aria-orientation": "vertical",
                                            "aria-labelledby": "options-menu",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                            underline: !activeCategory?.name
                                                        }),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: {
                                                                pathname: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .getCategoryPath */ .IX)("", brand),
                                                                query
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                onClick: (e)=>handleClick(e, "categories")
                                                                ,
                                                                className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                                children: "All Categories"
                                                            })
                                                        })
                                                    }),
                                                    categories.map((cat)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                                underline: activeCategory?.id === cat.id
                                                            }),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                href: {
                                                                    pathname: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .getCategoryPath */ .IX)(cat.path, brand),
                                                                    query
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    onClick: (e)=>handleClick(e, "categories")
                                                                    ,
                                                                    className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                                    children: cat.name
                                                                })
                                                            })
                                                        }, cat.path)
                                                    )
                                                ]
                                            })
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative inline-block w-full",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "lg:hidden mt-3",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "rounded-md shadow-sm",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            type: "button",
                                            onClick: (e)=>handleClick(e, "brands")
                                            ,
                                            className: "flex justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-8 hover:text-accent-5 focus:outline-none focus:border-blue-300 focus:shadow-outline-normal active:bg-accent-1 active:text-accent-8 transition ease-in-out duration-150",
                                            id: "options-menu",
                                            "aria-haspopup": "true",
                                            "aria-expanded": "true",
                                            children: [
                                                activeBrand?.name ? `Design: ${activeBrand?.name}` : "All Designs",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                    className: "-mr-1 ml-2 h-5 w-5",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    viewBox: "0 0 20 20",
                                                    fill: "currentColor",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        fillRule: "evenodd",
                                                        d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",
                                                        clipRule: "evenodd"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: `origin-top-left absolute lg:relative left-0 mt-2 w-full rounded-md shadow-lg lg:shadow-none z-10 mb-10 lg:block ${activeFilter !== "brands" || toggleFilter !== true ? "hidden" : ""}`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "rounded-sm bg-accent-0 shadow-xs lg:bg-none lg:shadow-none",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            role: "menu",
                                            "aria-orientation": "vertical",
                                            "aria-labelledby": "options-menu",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                            underline: !activeBrand?.name
                                                        }),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: {
                                                                pathname: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .getDesignerPath */ .Rr)("", category),
                                                                query
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                onClick: (e)=>handleClick(e, "brands")
                                                                ,
                                                                className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                                children: "All Designers"
                                                            })
                                                        })
                                                    }),
                                                    brands.flatMap(({ node  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                                // @ts-ignore Shopify - Fix this types
                                                                underline: activeBrand?.entityId === node.entityId
                                                            }),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                href: {
                                                                    pathname: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .getDesignerPath */ .Rr)(node.path, category),
                                                                    query
                                                                },
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                    onClick: (e)=>handleClick(e, "brands")
                                                                    ,
                                                                    className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                                    children: node.name
                                                                })
                                                            })
                                                        }, node.path)
                                                    )
                                                ]
                                            })
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col-span-8 order-3 lg:order-none",
                    children: [
                        (q || activeCategory || activeBrand) && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mb-12 transition ease-in duration-75",
                            children: [
                                console.log(data),
                                data ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("animated", {
                                                fadeIn: data.found,
                                                hidden: !data.found
                                            }),
                                            children: [
                                                "Showing ",
                                                data.products.length,
                                                " results",
                                                " ",
                                                q && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        'for "',
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                            children: q
                                                        }),
                                                        '"'
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("animated", {
                                                fadeIn: !data.found,
                                                hidden: data.found
                                            }),
                                            children: q ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    'There are no products that match "',
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                                        children: q
                                                    }),
                                                    '"'
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: "There are no products that match the selected category."
                                            })
                                        })
                                    ]
                                }) : q ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        'Searching for: "',
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                            children: q
                                        }),
                                        '"'
                                    ]
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: "Searching..."
                                })
                            ]
                        }),
                        data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3",
                            children: data.products.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_product__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    variant: "simple",
                                    className: "animated fadeIn",
                                    product: product,
                                    imgProps: {
                                        width: 480,
                                        height: 480
                                    }
                                }, product.path)
                            )
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3",
                            children: (0,_lib_range_map__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(12, (i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "w-60 h-60"
                                    })
                                }, i)
                            )
                        }),
                        " "
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "col-span-8 lg:col-span-2 order-2 lg:order-none",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative inline-block w-full",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:hidden",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "rounded-md shadow-sm",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                        type: "button",
                                        onClick: (e)=>handleClick(e, "sort")
                                        ,
                                        className: "flex justify-between w-full rounded-sm border border-accent-3 px-4 py-3 bg-accent-0 text-sm leading-5 font-medium text-accent-4 hover:text-accent-5 focus:outline-none focus:border-blue-300 focus:shadow-outline-normal active:bg-accent-1 active:text-accent-8 transition ease-in-out duration-150",
                                        id: "options-menu",
                                        "aria-haspopup": "true",
                                        "aria-expanded": "true",
                                        children: [
                                            sort ? SORT[sort] : "Relevance",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                                className: "-mr-1 ml-2 h-5 w-5",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                viewBox: "0 0 20 20",
                                                fill: "currentColor",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                    fillRule: "evenodd",
                                                    d: "M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z",
                                                    clipRule: "evenodd"
                                                })
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `origin-top-left absolute lg:relative left-0 mt-2 w-full rounded-md shadow-lg lg:shadow-none z-10 mb-10 lg:block ${activeFilter !== "sort" || toggleFilter !== true ? "hidden" : ""}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "rounded-sm bg-accent-0 shadow-xs lg:bg-none lg:shadow-none",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        role: "menu",
                                        "aria-orientation": "vertical",
                                        "aria-labelledby": "options-menu",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 lg:text-base lg:no-underline lg:font-bold lg:tracking-wide hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                        underline: !sort
                                                    }),
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                        href: {
                                                            pathname,
                                                            query: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .filterQuery */ .DQ)({
                                                                q
                                                            })
                                                        },
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                            onClick: (e)=>handleClick(e, "sort")
                                                            ,
                                                            className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                            children: "Relevance"
                                                        })
                                                    })
                                                }),
                                                Object.entries(SORT).map(([key, text])=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()("block text-sm leading-5 text-accent-4 hover:bg-accent-1 lg:hover:bg-transparent hover:text-accent-8 focus:outline-none focus:bg-accent-1 focus:text-accent-8", {
                                                            underline: sort === key
                                                        }),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: {
                                                                pathname,
                                                                query: (0,_lib_search__WEBPACK_IMPORTED_MODULE_5__/* .filterQuery */ .DQ)({
                                                                    q,
                                                                    sort: key
                                                                })
                                                            },
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                                onClick: (e)=>handleClick(e, "sort")
                                                                ,
                                                                className: "block lg:inline-block px-4 py-2 lg:p-0 lg:my-2 lg:mx-4",
                                                                children: text
                                                            })
                                                        })
                                                    }, key)
                                                )
                                            ]
                                        })
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
Search.Layout = _components_common__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Skeleton_Skeleton)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./lib/to-pixels.ts
// Convert numbers or strings to pixel value
// Helpful for styled-jsx when using a prop
// height: ${toPixels(height)}; (supports height={20} and height="20px")
const toPixels = (value)=>{
    if (typeof value === "number") {
        return `${value}px`;
    }
    return value;
};
/* harmony default export */ const to_pixels = (toPixels);

// EXTERNAL MODULE: ./components/ui/Skeleton/Skeleton.module.css
var Skeleton_module = __webpack_require__(1208);
var Skeleton_module_default = /*#__PURE__*/__webpack_require__.n(Skeleton_module);
;// CONCATENATED MODULE: ./components/ui/Skeleton/Skeleton.tsx





const Skeleton = ({ style , width , height , children , className , show =true , boxHeight =height ,  })=>{
    // Automatically calculate the size if there are children
    // and no fixed sizes are specified
    const shouldAutoSize = !!children && !(width || height);
    // Defaults
    width = width || 24;
    height = height || 24;
    boxHeight = boxHeight || height;
    return /*#__PURE__*/ jsx_runtime_.jsx("span", {
        className: external_classnames_default()((Skeleton_module_default()).skeleton, className, {
            [(Skeleton_module_default()).show]: show,
            [(Skeleton_module_default()).wrapper]: shouldAutoSize,
            [(Skeleton_module_default()).loaded]: !shouldAutoSize && !!children
        }),
        style: shouldAutoSize ? {} : {
            minWidth: to_pixels(width),
            minHeight: to_pixels(height),
            marginBottom: `calc(${to_pixels(boxHeight)} - ${to_pixels(height)})`,
            ...style
        },
        children: children
    });
};
/* harmony default export */ const Skeleton_Skeleton = (Skeleton);


/***/ }),

/***/ 2178:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ rangeMap)
/* harmony export */ });
function rangeMap(n, fn) {
    const arr = [];
    while(n > arr.length){
        arr.push(fn(arr.length));
    }
    return arr;
};


/***/ }),

/***/ 3404:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "n": () => (/* binding */ getSearchStaticProps)
/* harmony export */ });
/* harmony import */ var _lib_api_commerce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7709);

async function getSearchStaticProps({ preview , locale , locales  }) {
    const config = {
        locale,
        locales
    };
    const pagesPromise = _lib_api_commerce__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getAllPages */ .Z.getAllPages({
        config,
        preview
    });
    const siteInfoPromise = _lib_api_commerce__WEBPACK_IMPORTED_MODULE_0__/* ["default"].getSiteInfo */ .Z.getSiteInfo({
        config,
        preview
    });
    const { pages  } = await pagesPromise;
    const { categories , brands  } = await siteInfoPromise;
    return {
        props: {
            pages,
            categories,
            brands
        },
        revalidate: 200
    };
}


/***/ }),

/***/ 6457:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DQ": () => (/* binding */ filterQuery),
/* harmony export */   "IX": () => (/* binding */ getCategoryPath),
/* harmony export */   "Ob": () => (/* binding */ useSearchMeta),
/* harmony export */   "Rr": () => (/* binding */ getDesignerPath)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _get_slug__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3438);


function useSearchMeta(asPath) {
    const { 0: pathname , 1: setPathname  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("/search");
    const { 0: category , 1: setCategory  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: brand , 1: setBrand  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // Only access asPath after hydration to avoid a server mismatch
        const path = asPath.split("?")[0];
        const parts = path.split("/");
        let c = parts[2];
        let b = parts[3];
        if (c === "designers") {
            c = parts[4];
        }
        if (path !== pathname) setPathname(path);
        if (c !== category) setCategory(c);
        if (b !== brand) setBrand(b);
    }, [
        asPath,
        pathname,
        category,
        brand
    ]);
    return {
        pathname,
        category,
        brand
    };
}
// Removes empty query parameters from the query object
const filterQuery = (query)=>Object.keys(query).reduce((obj, key)=>{
        if (query[key]?.length) {
            obj[key] = query[key];
        }
        return obj;
    }, {})
;
const getCategoryPath = (path, brand)=>{
    const category = (0,_get_slug__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(path);
    return `/search${brand ? `/designers/${brand}` : ""}${category ? `/${category}` : ""}`;
};
const getDesignerPath = (path, category)=>{
    const designer = (0,_get_slug__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)(path).replace(/^brands/, "designers");
    return `/search${designer ? `/${designer}` : ""}${category ? `/${category}` : ""}`;
};


/***/ })

};
;