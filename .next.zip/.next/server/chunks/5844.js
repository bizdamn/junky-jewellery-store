exports.id = 5844;
exports.ids = [5844];
exports.modules = {

/***/ 1445:
/***/ ((module) => {

// Exports
module.exports = {
	"body": "Text_body__ldD0k",
	"heading": "Text_heading__jNwbK",
	"pageHeading": "Text_pageHeading__VhZNf",
	"sectionHeading": "Text_sectionHeading__cIo0_"
};


/***/ }),

/***/ 4467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1445);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Text_module_css__WEBPACK_IMPORTED_MODULE_3__);




const Text = ({ style , className ="" , variant ="body" , children , html , onClick ,  })=>{
    const componentsMap = {
        body: "div",
        heading: "h1",
        pageHeading: "h1",
        sectionHeading: "h2"
    };
    const Component = componentsMap[variant];
    const htmlContentProps = html ? {
        dangerouslySetInnerHTML: {
            __html: html
        }
    } : {};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), {
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().body)]: variant === "body",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().heading)]: variant === "heading",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().pageHeading)]: variant === "pageHeading",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().sectionHeading)]: variant === "sectionHeading"
        }, className),
        onClick: onClick,
        style: style,
        ...htmlContentProps,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Text);


/***/ })

};
;