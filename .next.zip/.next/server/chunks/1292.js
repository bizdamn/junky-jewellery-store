"use strict";
exports.id = 1292;
exports.ids = [1292];
exports.modules = {

/***/ 1292:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ AdminDataStoreProvider),
/* harmony export */   "p": () => (/* binding */ AdminDataStore)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9915);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_1__]);
js_cookie__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const AdminDataStore = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.createContext)();
const initialState = {
    user: {
        username: "apoo",
        name: "",
        bio: "",
        pic: "",
        email: "",
        phone: "",
        country: ""
    },
    product: {
        accessType: "download",
        title: "",
        slug: "",
        status: false,
        isFeatured: false,
        isDeleted: false,
        sku: "",
        barcode: "",
        type: "",
        description: "",
        categories: [],
        features: [],
        images: {},
        pricing: {},
        options: {},
        size: {},
        rating: 0,
        numReviews: 0,
        inventory: 0
    },
    darkMode: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("darkMode") === "ON" ? true : false,
    cart: {
        shippingAddress: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("shippingAddress") ? JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("shippingAddress")) : {},
        paymentMethod: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("paymentMethod") ? js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("paymentMethod") : ""
    },
    adminStoreInfo: js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("adminStoreInfo") ? JSON.parse(js_cookie__WEBPACK_IMPORTED_MODULE_1__["default"].get("adminStoreInfo")) : null
};
function reducer(state, action) {
    switch(action.type){
        case "DARK_MODE_ON":
            return {
                ...state,
                darkMode: true
            };
        case "DARK_MODE_OFF":
            return {
                ...state,
                darkMode: false
            };
        case "UPDATE_CATEGORY":
            console.log("HEY HEY");
            console.log(action.payload);
            return {
                ...state,
                adminStoreInfo: {
                    ...state.adminStoreInfo,
                    categories: action.payload
                }
            };
        case "SAVE_SHIPPING_ADDRESS":
            return {
                ...state,
                cart: {
                    ...state.cart,
                    shippingAddress: action.payload
                }
            };
        case "SAVE_PAYMENT_METHOD":
            return {
                ...state,
                cart: {
                    ...state.cart,
                    paymentMethod: action.payload
                }
            };
        case "CART_CLEAR":
            return {
                ...state,
                cart: {
                    ...state.cart,
                    cartItems: []
                }
            };
        case "USER_LOGIN":
            return {
                ...state,
                adminStoreInfo: action.payload
            };
        case "USER_REGISTER":
            return {
                ...state,
                registerInfo: action.payload
            };
        case "USER_LOGOUT":
            return {
                ...state,
                adminStoreInfo: null
            };
        case "UPDATE_PRODUCT":
            return {
                ...state,
                product: action.payload
            };
        case "STORE_SEO":
            return {
                ...state,
                adminStoreInfo: {
                    ...state.adminStoreInfo,
                    title: action.payload.title,
                    metatitle: action.payload.metatitle,
                    metadescription: action.payload.metadescription
                }
            };
        case "STORE_DETAILS_ADD":
            return {
                ...state,
                adminStoreInfo: {
                    ...state.adminStoreInfo,
                    storeDetails: {
                        storeIndustry: action.payload.storeIndustry,
                        storeAudience: action.payload.storeAudience,
                        companyName: action.payload.companyName
                    }
                }
            };
        case "STORE_DETAILS_ADD_ADDRESS":
            return {
                ...state,
                adminStoreInfo: {
                    ...state.adminStoreInfo,
                    address: {
                        addressLine1: action.payload.addressLine1,
                        addressLine2: action.payload.addressLine2,
                        city: action.payload.city,
                        country: action.payload.country,
                        state: action.payload.state,
                        pinCode: action.payload.pinCode,
                        country: action.payload.country
                    }
                }
            };
        default:
            return state;
    }
}
function AdminDataStoreProvider(props) {
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useReducer)(reducer, initialState);
    const value = {
        state,
        dispatch
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AdminDataStore.Provider, {
        value: value,
        children: props.children
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;