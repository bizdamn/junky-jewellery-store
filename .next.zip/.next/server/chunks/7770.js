"use strict";
exports.id = 7770;
exports.ids = [7770];
exports.modules = {

/***/ 75217:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(36042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(67934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(48012);
/* harmony import */ var _mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71507);
/* harmony import */ var _mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_InputLabel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(60911);
/* harmony import */ var _mui_material_InputLabel__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_InputLabel__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(29271);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(42651);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Select__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(46555);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_12__]);
uuid__WEBPACK_IMPORTED_MODULE_12__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













function AddFeatures({ featureFields , setFeatureFields  }) {
    const handleChangeInput = (id, event)=>{
        const newfeatureFields = featureFields.map((i)=>{
            if (id === i.id) {
                i[event.target.name] = event.target.value;
            }
            return i;
        });
        setFeatureFields(newfeatureFields);
    };
    const handleAddFields = ()=>{
        setFeatureFields([
            ...featureFields,
            {
                id: (0,uuid__WEBPACK_IMPORTED_MODULE_12__.v4)(),
                name: "",
                vame: ""
            }
        ]);
    };
    const handleRemoveFields = (id)=>{
        const values = [
            ...featureFields
        ];
        values.splice(values.findIndex((value)=>value.id === id
        ), 1);
        setFeatureFields(values);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: featureFields.map((featureField)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                        sx: {
                            my: 2
                        },
                        fullWidth: true,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_InputLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                                id: "demo-simple-select-label",
                                children: "Feature Name"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Select__WEBPACK_IMPORTED_MODULE_10___default()), {
                                name: "name",
                                labelId: "demo-simple-select-label",
                                id: "demo-simple-select",
                                value: featureField.name,
                                onChange: (event)=>handleChangeInput(featureField.id, event)
                                ,
                                label: "Add Feature",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        value: "color",
                                        children: "Color"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        value: "size",
                                        children: "Size"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        value: "material",
                                        children: "Material"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_8___default()), {
                                        value: "style",
                                        children: "Style"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_2___default()), {
                        fullWidth: true,
                        name: "value",
                        label: "Feature Value",
                        variant: "outlined",
                        value: featureField.lastName,
                        onChange: (event)=>handleChangeInput(featureField.id, event)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_3___default()), {
                        disabled: featureFields.length === 1,
                        onClick: ()=>handleRemoveFields(featureField.id)
                        ,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_DeleteOutline__WEBPACK_IMPORTED_MODULE_4___default()), {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_3___default()), {
                        onClick: handleAddFields,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddCircleOutline__WEBPACK_IMPORTED_MODULE_5___default()), {})
                    })
                ]
            }, featureField.id)
        )
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddFeatures);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 58226:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ChooseCategories)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(58330);
/* harmony import */ var _mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2311);
/* harmony import */ var _mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_CheckBoxOutlineBlank__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(51779);
/* harmony import */ var _mui_icons_material_CheckBoxOutlineBlank__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CheckBoxOutlineBlank__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_CheckBox__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1783);
/* harmony import */ var _mui_icons_material_CheckBox__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CheckBox__WEBPACK_IMPORTED_MODULE_6__);







const icon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CheckBoxOutlineBlank__WEBPACK_IMPORTED_MODULE_5___default()), {
    fontSize: "small"
});
const checkedIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CheckBox__WEBPACK_IMPORTED_MODULE_6___default()), {
    fontSize: "small"
});
function ChooseCategories({ categories , setCategories  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Autocomplete__WEBPACK_IMPORTED_MODULE_4___default()), {
        multiple: true,
        sx: {
            my: 2
        },
        id: "checkboxes-tags-demo",
        options: categories,
        disableCloseOnSelect: true,
        getOptionLabel: (option)=>option.categoryName
        ,
        renderOption: (props, option, { selected  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                ...props,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Checkbox__WEBPACK_IMPORTED_MODULE_2___default()), {
                        icon: icon,
                        checkedIcon: checkedIcon,
                        style: {
                            marginRight: 8
                        },
                        checked: selected
                    }),
                    option.categoryName
                ]
            })
        ,
        style: {
            width: 500
        },
        renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TextField__WEBPACK_IMPORTED_MODULE_3___default()), {
                ...params,
                label: "Categories"
            })
    });
};


/***/ }),

/***/ 96932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ DigitalFileUpload)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_3__);




function DigitalFileUpload({ document , setDocument  }) {
    const { 0: createObjectURL , 1: setCreateObjectURL  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const uploadToClient = (event)=>{
        if (event.target.files && event.target.files[0]) {
            const i = event.target.files[0];
            setDocument(i);
            setCreateObjectURL(URL.createObjectURL(i));
        }
    };
    const documentUploadToServer = async (event)=>{
        const body = new FormData();
        body.append("file", document);
        const response = await fetch("/api/admin/document-upload", {
            method: "POST",
            body
        });
    };
    // useEffect(() => {
    //     const dropArea = document.querySelector(".drop_box");
    //       const   button = dropArea.querySelector("button");
    //        const  dragText = dropArea.querySelector("header");
    //       const   input = dropArea.querySelector("input");
    //     let file;
    //     var filename;
    //     button.onclick = () => {
    //         input.click();
    //     };
    //     input.addEventListener("change", function (e) {
    //         uploadToClient()
    //         var fileName = e.target.files[0].name;
    //         let filedata = `
    //       <h4>${fileName}</h4>
    //         `;
    //         dropArea.innerHTML = filedata;
    //     });
    // }, [])
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    mt: 3
                },
                component: "p",
                children: "You can upload a single PDF or compressed ZIP file, maximum 500MB."
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    marginTop: "1rem"
                },
                className: "upload-container",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "card",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                            component: "h3",
                            children: "Upload Files"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "drop_box",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        component: "h4",
                                        children: "Select File here"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    component: "p",
                                    children: "Files Supported: ZIP, PDF, TEXT, DOC , DOCX"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "file",
                                    onChange: uploadToClient,
                                    id: "files",
                                    name: "files",
                                    multiple: true
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    variant: "contained",
                                    component: "label",
                                    onClick: documentUploadToServer,
                                    children: "Upload File"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 94180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Price)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@mui/material/Checkbox"
var Checkbox_ = __webpack_require__(58330);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox_);
// EXTERNAL MODULE: external "@mui/material/Typography"
var Typography_ = __webpack_require__(27163);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography_);
// EXTERNAL MODULE: external "@mui/material/FormControlLabel"
var FormControlLabel_ = __webpack_require__(88185);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel_);
// EXTERNAL MODULE: external "@mui/material/OutlinedInput"
var OutlinedInput_ = __webpack_require__(37730);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput_);
// EXTERNAL MODULE: external "@mui/material/Grid"
var Grid_ = __webpack_require__(15612);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_);
// EXTERNAL MODULE: external "@mui/material/InputLabel"
var InputLabel_ = __webpack_require__(60911);
var InputLabel_default = /*#__PURE__*/__webpack_require__.n(InputLabel_);
// EXTERNAL MODULE: external "@mui/material/InputAdornment"
var InputAdornment_ = __webpack_require__(33103);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment_);
// EXTERNAL MODULE: external "@mui/material/FormControl"
var FormControl_ = __webpack_require__(68891);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl_);
// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(36042);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/Autocomplete"
var Autocomplete_ = __webpack_require__(2311);
var Autocomplete_default = /*#__PURE__*/__webpack_require__.n(Autocomplete_);
;// CONCATENATED MODULE: ./components/admin/products/add-product/CurrencySelect.jsx




function CurrencySelect({ price , setPrice  }) {
    const currencies = [
        {
            "symbol": "$",
            "name": "US Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "USD",
            "name_plural": "US dollars"
        },
        {
            "symbol": "CA$",
            "name": "Canadian Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "CAD",
            "name_plural": "Canadian dollars"
        },
        {
            "symbol": "\u20AC",
            "name": "Euro",
            "symbol_native": "\u20AC",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "EUR",
            "name_plural": "euros"
        },
        {
            "symbol": "AED",
            "name": "United Arab Emirates Dirham",
            "symbol_native": "\u062F.\u0625.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "AED",
            "name_plural": "UAE dirhams"
        },
        {
            "symbol": "Af",
            "name": "Afghan Afghani",
            "symbol_native": "\u060B",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "AFN",
            "name_plural": "Afghan Afghanis"
        },
        {
            "symbol": "ALL",
            "name": "Albanian Lek",
            "symbol_native": "Lek",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "ALL",
            "name_plural": "Albanian lek\xeb"
        },
        {
            "symbol": "AMD",
            "name": "Armenian Dram",
            "symbol_native": "\u0564\u0580.",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "AMD",
            "name_plural": "Armenian drams"
        },
        {
            "symbol": "AR$",
            "name": "Argentine Peso",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "ARS",
            "name_plural": "Argentine pesos"
        },
        {
            "symbol": "AU$",
            "name": "Australian Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "AUD",
            "name_plural": "Australian dollars"
        },
        {
            "symbol": "man.",
            "name": "Azerbaijani Manat",
            "symbol_native": "\u043C\u0430\u043D.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "AZN",
            "name_plural": "Azerbaijani manats"
        },
        {
            "symbol": "KM",
            "name": "Bosnia-Herzegovina Convertible Mark",
            "symbol_native": "KM",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BAM",
            "name_plural": "Bosnia-Herzegovina convertible marks"
        },
        {
            "symbol": "Tk",
            "name": "Bangladeshi Taka",
            "symbol_native": "\u09F3",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BDT",
            "name_plural": "Bangladeshi takas"
        },
        {
            "symbol": "BGN",
            "name": "Bulgarian Lev",
            "symbol_native": "\u043B\u0432.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BGN",
            "name_plural": "Bulgarian leva"
        },
        {
            "symbol": "BD",
            "name": "Bahraini Dinar",
            "symbol_native": "\u062F.\u0628.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "BHD",
            "name_plural": "Bahraini dinars"
        },
        {
            "symbol": "FBu",
            "name": "Burundian Franc",
            "symbol_native": "FBu",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "BIF",
            "name_plural": "Burundian francs"
        },
        {
            "symbol": "BN$",
            "name": "Brunei Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BND",
            "name_plural": "Brunei dollars"
        },
        {
            "symbol": "Bs",
            "name": "Bolivian Boliviano",
            "symbol_native": "Bs",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BOB",
            "name_plural": "Bolivian bolivianos"
        },
        {
            "symbol": "R$",
            "name": "Brazilian Real",
            "symbol_native": "R$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BRL",
            "name_plural": "Brazilian reals"
        },
        {
            "symbol": "BWP",
            "name": "Botswanan Pula",
            "symbol_native": "P",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BWP",
            "name_plural": "Botswanan pulas"
        },
        {
            "symbol": "Br",
            "name": "Belarusian Ruble",
            "symbol_native": "\u0440\u0443\u0431.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BYN",
            "name_plural": "Belarusian rubles"
        },
        {
            "symbol": "BZ$",
            "name": "Belize Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "BZD",
            "name_plural": "Belize dollars"
        },
        {
            "symbol": "CDF",
            "name": "Congolese Franc",
            "symbol_native": "FrCD",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "CDF",
            "name_plural": "Congolese francs"
        },
        {
            "symbol": "CHF",
            "name": "Swiss Franc",
            "symbol_native": "CHF",
            "decimal_digits": 2,
            "rounding": 0.05,
            "code": "CHF",
            "name_plural": "Swiss francs"
        },
        {
            "symbol": "CL$",
            "name": "Chilean Peso",
            "symbol_native": "$",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "CLP",
            "name_plural": "Chilean pesos"
        },
        {
            "symbol": "CN\xa5",
            "name": "Chinese Yuan",
            "symbol_native": "CN\xa5",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "CNY",
            "name_plural": "Chinese yuan"
        },
        {
            "symbol": "CO$",
            "name": "Colombian Peso",
            "symbol_native": "$",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "COP",
            "name_plural": "Colombian pesos"
        },
        {
            "symbol": "\u20A1",
            "name": "Costa Rican Col\xf3n",
            "symbol_native": "\u20A1",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "CRC",
            "name_plural": "Costa Rican col\xf3ns"
        },
        {
            "symbol": "CV$",
            "name": "Cape Verdean Escudo",
            "symbol_native": "CV$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "CVE",
            "name_plural": "Cape Verdean escudos"
        },
        {
            "symbol": "K\u010D",
            "name": "Czech Republic Koruna",
            "symbol_native": "K\u010D",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "CZK",
            "name_plural": "Czech Republic korunas"
        },
        {
            "symbol": "Fdj",
            "name": "Djiboutian Franc",
            "symbol_native": "Fdj",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "DJF",
            "name_plural": "Djiboutian francs"
        },
        {
            "symbol": "Dkr",
            "name": "Danish Krone",
            "symbol_native": "kr",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "DKK",
            "name_plural": "Danish kroner"
        },
        {
            "symbol": "RD$",
            "name": "Dominican Peso",
            "symbol_native": "RD$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "DOP",
            "name_plural": "Dominican pesos"
        },
        {
            "symbol": "DA",
            "name": "Algerian Dinar",
            "symbol_native": "\u062F.\u062C.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "DZD",
            "name_plural": "Algerian dinars"
        },
        {
            "symbol": "Ekr",
            "name": "Estonian Kroon",
            "symbol_native": "kr",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "EEK",
            "name_plural": "Estonian kroons"
        },
        {
            "symbol": "EGP",
            "name": "Egyptian Pound",
            "symbol_native": "\u062C.\u0645.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "EGP",
            "name_plural": "Egyptian pounds"
        },
        {
            "symbol": "Nfk",
            "name": "Eritrean Nakfa",
            "symbol_native": "Nfk",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "ERN",
            "name_plural": "Eritrean nakfas"
        },
        {
            "symbol": "Br",
            "name": "Ethiopian Birr",
            "symbol_native": "Br",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "ETB",
            "name_plural": "Ethiopian birrs"
        },
        {
            "symbol": "\xa3",
            "name": "British Pound Sterling",
            "symbol_native": "\xa3",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "GBP",
            "name_plural": "British pounds sterling"
        },
        {
            "symbol": "GEL",
            "name": "Georgian Lari",
            "symbol_native": "GEL",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "GEL",
            "name_plural": "Georgian laris"
        },
        {
            "symbol": "GH\u20B5",
            "name": "Ghanaian Cedi",
            "symbol_native": "GH\u20B5",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "GHS",
            "name_plural": "Ghanaian cedis"
        },
        {
            "symbol": "FG",
            "name": "Guinean Franc",
            "symbol_native": "FG",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "GNF",
            "name_plural": "Guinean francs"
        },
        {
            "symbol": "GTQ",
            "name": "Guatemalan Quetzal",
            "symbol_native": "Q",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "GTQ",
            "name_plural": "Guatemalan quetzals"
        },
        {
            "symbol": "HK$",
            "name": "Hong Kong Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "HKD",
            "name_plural": "Hong Kong dollars"
        },
        {
            "symbol": "HNL",
            "name": "Honduran Lempira",
            "symbol_native": "L",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "HNL",
            "name_plural": "Honduran lempiras"
        },
        {
            "symbol": "kn",
            "name": "Croatian Kuna",
            "symbol_native": "kn",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "HRK",
            "name_plural": "Croatian kunas"
        },
        {
            "symbol": "Ft",
            "name": "Hungarian Forint",
            "symbol_native": "Ft",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "HUF",
            "name_plural": "Hungarian forints"
        },
        {
            "symbol": "Rp",
            "name": "Indonesian Rupiah",
            "symbol_native": "Rp",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "IDR",
            "name_plural": "Indonesian rupiahs"
        },
        {
            "symbol": "\u20AA",
            "name": "Israeli New Sheqel",
            "symbol_native": "\u20AA",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "ILS",
            "name_plural": "Israeli new sheqels"
        },
        {
            "symbol": "Rs",
            "name": "Indian Rupee",
            "symbol_native": "\u099F\u0995\u09BE",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "INR",
            "name_plural": "Indian rupees"
        },
        {
            "symbol": "IQD",
            "name": "Iraqi Dinar",
            "symbol_native": "\u062F.\u0639.\u200F",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "IQD",
            "name_plural": "Iraqi dinars"
        },
        {
            "symbol": "IRR",
            "name": "Iranian Rial",
            "symbol_native": "\uFDFC",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "IRR",
            "name_plural": "Iranian rials"
        },
        {
            "symbol": "Ikr",
            "name": "Icelandic Kr\xf3na",
            "symbol_native": "kr",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "ISK",
            "name_plural": "Icelandic kr\xf3nur"
        },
        {
            "symbol": "J$",
            "name": "Jamaican Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "JMD",
            "name_plural": "Jamaican dollars"
        },
        {
            "symbol": "JD",
            "name": "Jordanian Dinar",
            "symbol_native": "\u062F.\u0623.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "JOD",
            "name_plural": "Jordanian dinars"
        },
        {
            "symbol": "\xa5",
            "name": "Japanese Yen",
            "symbol_native": "\uFFE5",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "JPY",
            "name_plural": "Japanese yen"
        },
        {
            "symbol": "Ksh",
            "name": "Kenyan Shilling",
            "symbol_native": "Ksh",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "KES",
            "name_plural": "Kenyan shillings"
        },
        {
            "symbol": "KHR",
            "name": "Cambodian Riel",
            "symbol_native": "\u17DB",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "KHR",
            "name_plural": "Cambodian riels"
        },
        {
            "symbol": "CF",
            "name": "Comorian Franc",
            "symbol_native": "FC",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "KMF",
            "name_plural": "Comorian francs"
        },
        {
            "symbol": "\u20A9",
            "name": "South Korean Won",
            "symbol_native": "\u20A9",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "KRW",
            "name_plural": "South Korean won"
        },
        {
            "symbol": "KD",
            "name": "Kuwaiti Dinar",
            "symbol_native": "\u062F.\u0643.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "KWD",
            "name_plural": "Kuwaiti dinars"
        },
        {
            "symbol": "KZT",
            "name": "Kazakhstani Tenge",
            "symbol_native": "\u0442\u04A3\u0433.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "KZT",
            "name_plural": "Kazakhstani tenges"
        },
        {
            "symbol": "L.L.",
            "name": "Lebanese Pound",
            "symbol_native": "\u0644.\u0644.\u200F",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "LBP",
            "name_plural": "Lebanese pounds"
        },
        {
            "symbol": "SLRs",
            "name": "Sri Lankan Rupee",
            "symbol_native": "SL Re",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "LKR",
            "name_plural": "Sri Lankan rupees"
        },
        {
            "symbol": "Lt",
            "name": "Lithuanian Litas",
            "symbol_native": "Lt",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "LTL",
            "name_plural": "Lithuanian litai"
        },
        {
            "symbol": "Ls",
            "name": "Latvian Lats",
            "symbol_native": "Ls",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "LVL",
            "name_plural": "Latvian lati"
        },
        {
            "symbol": "LD",
            "name": "Libyan Dinar",
            "symbol_native": "\u062F.\u0644.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "LYD",
            "name_plural": "Libyan dinars"
        },
        {
            "symbol": "MAD",
            "name": "Moroccan Dirham",
            "symbol_native": "\u062F.\u0645.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MAD",
            "name_plural": "Moroccan dirhams"
        },
        {
            "symbol": "MDL",
            "name": "Moldovan Leu",
            "symbol_native": "MDL",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MDL",
            "name_plural": "Moldovan lei"
        },
        {
            "symbol": "MGA",
            "name": "Malagasy Ariary",
            "symbol_native": "MGA",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "MGA",
            "name_plural": "Malagasy Ariaries"
        },
        {
            "symbol": "MKD",
            "name": "Macedonian Denar",
            "symbol_native": "MKD",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MKD",
            "name_plural": "Macedonian denari"
        },
        {
            "symbol": "MMK",
            "name": "Myanma Kyat",
            "symbol_native": "K",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "MMK",
            "name_plural": "Myanma kyats"
        },
        {
            "symbol": "MOP$",
            "name": "Macanese Pataca",
            "symbol_native": "MOP$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MOP",
            "name_plural": "Macanese patacas"
        },
        {
            "symbol": "MURs",
            "name": "Mauritian Rupee",
            "symbol_native": "MURs",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "MUR",
            "name_plural": "Mauritian rupees"
        },
        {
            "symbol": "MX$",
            "name": "Mexican Peso",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MXN",
            "name_plural": "Mexican pesos"
        },
        {
            "symbol": "RM",
            "name": "Malaysian Ringgit",
            "symbol_native": "RM",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MYR",
            "name_plural": "Malaysian ringgits"
        },
        {
            "symbol": "MTn",
            "name": "Mozambican Metical",
            "symbol_native": "MTn",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "MZN",
            "name_plural": "Mozambican meticals"
        },
        {
            "symbol": "N$",
            "name": "Namibian Dollar",
            "symbol_native": "N$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NAD",
            "name_plural": "Namibian dollars"
        },
        {
            "symbol": "\u20A6",
            "name": "Nigerian Naira",
            "symbol_native": "\u20A6",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NGN",
            "name_plural": "Nigerian nairas"
        },
        {
            "symbol": "C$",
            "name": "Nicaraguan C\xf3rdoba",
            "symbol_native": "C$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NIO",
            "name_plural": "Nicaraguan c\xf3rdobas"
        },
        {
            "symbol": "Nkr",
            "name": "Norwegian Krone",
            "symbol_native": "kr",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NOK",
            "name_plural": "Norwegian kroner"
        },
        {
            "symbol": "NPRs",
            "name": "Nepalese Rupee",
            "symbol_native": "\u0928\u0947\u0930\u0942",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NPR",
            "name_plural": "Nepalese rupees"
        },
        {
            "symbol": "NZ$",
            "name": "New Zealand Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "NZD",
            "name_plural": "New Zealand dollars"
        },
        {
            "symbol": "OMR",
            "name": "Omani Rial",
            "symbol_native": "\u0631.\u0639.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "OMR",
            "name_plural": "Omani rials"
        },
        {
            "symbol": "B/.",
            "name": "Panamanian Balboa",
            "symbol_native": "B/.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "PAB",
            "name_plural": "Panamanian balboas"
        },
        {
            "symbol": "S/.",
            "name": "Peruvian Nuevo Sol",
            "symbol_native": "S/.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "PEN",
            "name_plural": "Peruvian nuevos soles"
        },
        {
            "symbol": "\u20B1",
            "name": "Philippine Peso",
            "symbol_native": "\u20B1",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "PHP",
            "name_plural": "Philippine pesos"
        },
        {
            "symbol": "PKRs",
            "name": "Pakistani Rupee",
            "symbol_native": "\u20A8",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "PKR",
            "name_plural": "Pakistani rupees"
        },
        {
            "symbol": "z\u0142",
            "name": "Polish Zloty",
            "symbol_native": "z\u0142",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "PLN",
            "name_plural": "Polish zlotys"
        },
        {
            "symbol": "\u20B2",
            "name": "Paraguayan Guarani",
            "symbol_native": "\u20B2",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "PYG",
            "name_plural": "Paraguayan guaranis"
        },
        {
            "symbol": "QR",
            "name": "Qatari Rial",
            "symbol_native": "\u0631.\u0642.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "QAR",
            "name_plural": "Qatari rials"
        },
        {
            "symbol": "RON",
            "name": "Romanian Leu",
            "symbol_native": "RON",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "RON",
            "name_plural": "Romanian lei"
        },
        {
            "symbol": "din.",
            "name": "Serbian Dinar",
            "symbol_native": "\u0434\u0438\u043D.",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "RSD",
            "name_plural": "Serbian dinars"
        },
        {
            "symbol": "RUB",
            "name": "Russian Ruble",
            "symbol_native": "\u20BD.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "RUB",
            "name_plural": "Russian rubles"
        },
        {
            "symbol": "RWF",
            "name": "Rwandan Franc",
            "symbol_native": "FR",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "RWF",
            "name_plural": "Rwandan francs"
        },
        {
            "symbol": "SR",
            "name": "Saudi Riyal",
            "symbol_native": "\u0631.\u0633.\u200F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "SAR",
            "name_plural": "Saudi riyals"
        },
        {
            "symbol": "SDG",
            "name": "Sudanese Pound",
            "symbol_native": "SDG",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "SDG",
            "name_plural": "Sudanese pounds"
        },
        {
            "symbol": "Skr",
            "name": "Swedish Krona",
            "symbol_native": "kr",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "SEK",
            "name_plural": "Swedish kronor"
        },
        {
            "symbol": "S$",
            "name": "Singapore Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "SGD",
            "name_plural": "Singapore dollars"
        },
        {
            "symbol": "Ssh",
            "name": "Somali Shilling",
            "symbol_native": "Ssh",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "SOS",
            "name_plural": "Somali shillings"
        },
        {
            "symbol": "SY\xa3",
            "name": "Syrian Pound",
            "symbol_native": "\u0644.\u0633.\u200F",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "SYP",
            "name_plural": "Syrian pounds"
        },
        {
            "symbol": "\u0E3F",
            "name": "Thai Baht",
            "symbol_native": "\u0E3F",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "THB",
            "name_plural": "Thai baht"
        },
        {
            "symbol": "DT",
            "name": "Tunisian Dinar",
            "symbol_native": "\u062F.\u062A.\u200F",
            "decimal_digits": 3,
            "rounding": 0,
            "code": "TND",
            "name_plural": "Tunisian dinars"
        },
        {
            "symbol": "T$",
            "name": "Tongan Pa\u02BBanga",
            "symbol_native": "T$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "TOP",
            "name_plural": "Tongan pa\u02BBanga"
        },
        {
            "symbol": "TL",
            "name": "Turkish Lira",
            "symbol_native": "TL",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "TRY",
            "name_plural": "Turkish Lira"
        },
        {
            "symbol": "TT$",
            "name": "Trinidad and Tobago Dollar",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "TTD",
            "name_plural": "Trinidad and Tobago dollars"
        },
        {
            "symbol": "NT$",
            "name": "New Taiwan Dollar",
            "symbol_native": "NT$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "TWD",
            "name_plural": "New Taiwan dollars"
        },
        {
            "symbol": "TSh",
            "name": "Tanzanian Shilling",
            "symbol_native": "TSh",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "TZS",
            "name_plural": "Tanzanian shillings"
        },
        {
            "symbol": "\u20B4",
            "name": "Ukrainian Hryvnia",
            "symbol_native": "\u20B4",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "UAH",
            "name_plural": "Ukrainian hryvnias"
        },
        {
            "symbol": "USh",
            "name": "Ugandan Shilling",
            "symbol_native": "USh",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "UGX",
            "name_plural": "Ugandan shillings"
        },
        {
            "symbol": "$U",
            "name": "Uruguayan Peso",
            "symbol_native": "$",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "UYU",
            "name_plural": "Uruguayan pesos"
        },
        {
            "symbol": "UZS",
            "name": "Uzbekistan Som",
            "symbol_native": "UZS",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "UZS",
            "name_plural": "Uzbekistan som"
        },
        {
            "symbol": "Bs.F.",
            "name": "Venezuelan Bol\xedvar",
            "symbol_native": "Bs.F.",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "VEF",
            "name_plural": "Venezuelan bol\xedvars"
        },
        {
            "symbol": "\u20AB",
            "name": "Vietnamese Dong",
            "symbol_native": "\u20AB",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "VND",
            "name_plural": "Vietnamese dong"
        },
        {
            "symbol": "FCFA",
            "name": "CFA Franc BEAC",
            "symbol_native": "FCFA",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "XAF",
            "name_plural": "CFA francs BEAC"
        },
        {
            "symbol": "CFA",
            "name": "CFA Franc BCEAO",
            "symbol_native": "CFA",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "XOF",
            "name_plural": "CFA francs BCEAO"
        },
        {
            "symbol": "YR",
            "name": "Yemeni Rial",
            "symbol_native": "\u0631.\u064A.\u200F",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "YER",
            "name_plural": "Yemeni rials"
        },
        {
            "symbol": "R",
            "name": "South African Rand",
            "symbol_native": "R",
            "decimal_digits": 2,
            "rounding": 0,
            "code": "ZAR",
            "name_plural": "South African rand"
        },
        {
            "symbol": "ZK",
            "name": "Zambian Kwacha",
            "symbol_native": "ZK",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "ZMK",
            "name_plural": "Zambian kwachas"
        },
        {
            "symbol": "ZWL$",
            "name": "Zimbabwean Dollar",
            "symbol_native": "ZWL$",
            "decimal_digits": 0,
            "rounding": 0,
            "code": "ZWL",
            "name_plural": "Zimbabwean Dollar"
        }
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx((Autocomplete_default()), {
        id: "country-select-demo",
        options: currencies,
        autoHighlight: true,
        getOptionLabel: (option)=>option.code
        ,
        renderInput: (params)=>/*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                ...params,
                label: "Currency",
                inputProps: {
                    ...params.inputProps,
                    autoComplete: "new-password"
                },
                defaultValue: `${price.currencyCode}`,
                onBlur: (e)=>setPrice({
                        ...price,
                        currencyCode: e.target.value
                    })
                ,
                placeholder: `${price.currencyCode}`
            })
    });
};

;// CONCATENATED MODULE: ./components/admin/products/add-product/Pricing.jsx












function Price({ price , setPrice  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                sx: {
                    my: 2
                },
                container: true,
                justifyContent: "center",
                alignItems: "center",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(CurrencySelect, {
                            price: price,
                            setPrice: setPrice
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 5,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            type: "number",
                            value: price.value,
                            onChange: (e)=>setPrice({
                                    ...price,
                                    value: e.target.value
                                })
                            ,
                            InputProps: {
                                startAdornment: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((InputAdornment_default()), {
                                    position: "start",
                                    children: [
                                        price.currencyCode,
                                        " | "
                                    ]
                                })
                            },
                            label: "Price",
                            variant: "outlined"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 4,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            value: price.comparePrice,
                            type: "number",
                            onChange: (e)=>setPrice({
                                    ...price,
                                    comparePrice: e.target.value
                                })
                            ,
                            InputProps: {
                                startAdornment: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((InputAdornment_default()), {
                                    position: "start",
                                    children: [
                                        price.currencyCode,
                                        " | "
                                    ]
                                })
                            },
                            label: "Compare at Price",
                            variant: "outlined"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 4,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((FormControl_default()), {
                                fullWidth: true,
                                sx: {
                                    m: 1
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((InputLabel_default()), {
                                        htmlFor: "outlined-adornment-amount",
                                        children: "Cost Per Item"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                        id: "outlined-adornment-amount",
                                        type: "number",
                                        value: price.costPerItem,
                                        onChange: (e)=>setPrice({
                                                ...price,
                                                costPerItem: e.target.value
                                            })
                                        ,
                                        startAdornment: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((InputAdornment_default()), {
                                            position: "start",
                                            children: [
                                                price.currencyCode,
                                                " | "
                                            ]
                                        }),
                                        label: "Cost Per Item"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                component: "p",
                                fontSize: 13,
                                children: "Customers won\u2019t see this"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                component: "p",
                                fontSize: 16,
                                fontWeight: "bold",
                                children: "Margin"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                component: "p",
                                sx: {
                                    mt: 1
                                },
                                fontSize: 13,
                                children: [
                                    price.value && price.value != 0 ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: ([
                                            (price.value - price.costPerItem) / price.value
                                        ] * 100).toFixed(2)
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: "0"
                                    }),
                                    "%"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                        item: true,
                        xs: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                component: "p",
                                fontSize: 16,
                                fontWeight: "bold",
                                children: "Profit"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                component: "p",
                                sx: {
                                    mt: 1
                                },
                                fontSize: 13,
                                children: (price.value - price.costPerItem).toFixed(2)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                    defaultChecked: true
                }),
                label: "Charge tax on this product"
            })
        ]
    });
};


/***/ }),

/***/ 63751:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProductStatus)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(55374);
/* harmony import */ var _mui_material_Radio__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Radio__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(76563);
/* harmony import */ var _mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(88185);
/* harmony import */ var _mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(68891);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(76096);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_7__);








function ProductStatus({ status , setStatus  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_6___default()), {
        fullWidth: true,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_7___default()), {
                component: "legend",
                children: "Product Status"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_RadioGroup__WEBPACK_IMPORTED_MODULE_4___default()), {
                row: true,
                name: "controlled-radio-buttons-group",
                value: status,
                label: "Product Status",
                onChange: (e)=>setStatus(e.target.value)
                ,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default()), {
                        value: true,
                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                        label: "Active"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormControlLabel__WEBPACK_IMPORTED_MODULE_5___default()), {
                        value: false,
                        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Radio__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                        label: "Draft"
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 8923:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UploadImage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(53819);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(36042);
/* harmony import */ var _mui_material_TextField__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TextField__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);






function UploadImage({ image , setImage  }) {
    // const [file, setFile] = useState(null);
    const { 0: createObjectURL , 1: setCreateObjectURL  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Select Upload-Area
        const uploadArea = document.querySelector("#uploadArea");
        // Select Drop-Zoon Area
        const dropZoon = document.querySelector("#dropZoon");
        // Loading Text
        const loadingText = document.querySelector("#loadingText");
        // Slect File Input 
        const fileInput = document.querySelector("#fileInput");
        // Select Preview Image
        const previewImage = document.querySelector("#previewImage");
        // File-Details Area
        const fileDetails = document.querySelector("#fileDetails");
        // Uploaded File
        const uploadedFile = document.querySelector("#uploadedFile");
        // Uploaded File Info
        const uploadedFileInfo = document.querySelector("#uploadedFileInfo");
        // Uploaded File  Name
        const uploadedFileName = document.querySelector(".uploaded-file__name");
        // Uploaded File Icon
        const uploadedFileIconText = document.querySelector(".uploaded-file__icon-text");
        // Uploaded File Counter
        const uploadedFileCounter = document.querySelector(".uploaded-file__counter");
        // ToolTip Data
        const toolTipData = document.querySelector(".upload-area__tooltip-data");
        // Images Types
        const imagesTypes = [
            "jpeg",
            "png",
            "svg",
            "gif"
        ];
        // Append Images Types Array Inisde Tooltip Data
        toolTipData.innerHTML = [
            ...imagesTypes
        ].join(", .");
        // When (drop-zoon) has (dragover) Event 
        dropZoon.addEventListener("dragover", function(event) {
            // Prevent Default Behavior 
            event.preventDefault();
            // Add Class (drop-zoon--over) On (drop-zoon)
            dropZoon.classList.add("drop-zoon--over");
        });
        // When (drop-zoon) has (dragleave) Event 
        dropZoon.addEventListener("dragleave", function(event) {
            // Remove Class (drop-zoon--over) from (drop-zoon)
            dropZoon.classList.remove("drop-zoon--over");
        });
        // When (drop-zoon) has (drop) Event 
        dropZoon.addEventListener("drop", function(event) {
            // Prevent Default Behavior 
            event.preventDefault();
            // Remove Class (drop-zoon--over) from (drop-zoon)
            dropZoon.classList.remove("drop-zoon--over");
            // Select The Dropped File
            const file = event.dataTransfer.files[0];
            // Call Function uploadFile(), And Send To Her The Dropped File :)
            uploadFile(file);
        });
        // When (drop-zoon) has (click) Event 
        dropZoon.addEventListener("click", function(event) {
            // Click The (fileInput)
            fileInput.click();
        });
        // When (fileInput) has (change) Event 
        fileInput.addEventListener("change", function(event) {
            // Select The Chosen File
            const file = event.target.files[0];
            // Call Function uploadFile(), And Send To Her The Chosen File :)
            uploadFile(file);
        });
        // Upload File Function
        function uploadFile(file) {
            // FileReader()
            const fileReader = new FileReader();
            // File Type 
            const fileType = file.type;
            // File Size 
            const fileSize = file.size;
            // If File Is Passed from the (File Validation) Function
            if (fileValidate(fileType, fileSize)) {
                // Add Class (drop-zoon--Uploaded) on (drop-zoon)
                dropZoon.classList.add("drop-zoon--Uploaded");
                // Show Loading-text
                loadingText.style.display = "block";
                // Hide Preview Image
                previewImage.style.display = "none";
                // Remove Class (uploaded-file--open) From (uploadedFile)
                uploadedFile.classList.remove("uploaded-file--open");
                // Remove Class (uploaded-file__info--active) from (uploadedFileInfo)
                uploadedFileInfo.classList.remove("uploaded-file__info--active");
                // After File Reader Loaded 
                fileReader.addEventListener("load", function() {
                    // After Half Second 
                    setTimeout(function() {
                        // Add Class (upload-area--open) On (uploadArea)
                        uploadArea.classList.add("upload-area--open");
                        // Hide Loading-text (please-wait) Element
                        loadingText.style.display = "none";
                        // Show Preview Image
                        previewImage.style.display = "block";
                        // Add Class (file-details--open) On (fileDetails)
                        fileDetails.classList.add("file-details--open");
                        // Add Class (uploaded-file--open) On (uploadedFile)
                        uploadedFile.classList.add("uploaded-file--open");
                        // Add Class (uploaded-file__info--active) On (uploadedFileInfo)
                        uploadedFileInfo.classList.add("uploaded-file__info--active");
                    }, 500); // 0.5s
                    // Add The (fileReader) Result Inside (previewImage) Source
                    previewImage.setAttribute("src", fileReader.result);
                    // Add File Name Inside Uploaded File Name
                    uploadedFileName.innerHTML = file.name;
                    // Call Function progressMove();
                    progressMove();
                });
                // Read (file) As Data Url 
                fileReader.readAsDataURL(file);
            } else {
                this; // (this) Represent The fileValidate(fileType, fileSize) Function
            }
            ;
        }
        ;
        // Progress Counter Increase Function
        function progressMove() {
            // Counter Start
            let counter = 0;
            // After 600ms 
            setTimeout(()=>{
                // Every 100ms
                let counterIncrease = setInterval(()=>{
                    // If (counter) is equle 100 
                    if (counter === 100) {
                        // Stop (Counter Increase)
                        clearInterval(counterIncrease);
                    } else {
                        // plus 10 on counter
                        counter = counter + 10;
                        // add (counter) vlaue inisde (uploadedFileCounter)
                        uploadedFileCounter.innerHTML = `${counter}%`;
                    }
                }, 100);
            }, 600);
        }
        ;
        // Simple File Validate Function
        function fileValidate(fileType, fileSize) {
            // File Type Validation
            let isImage = imagesTypes.filter((type)=>fileType.indexOf(`image/${type}`) !== -1
            );
            // If The Uploaded File Type Is 'jpeg'
            if (isImage[0] === "jpeg") {
                // Add Inisde (uploadedFileIconText) The (jpg) Value
                uploadedFileIconText.innerHTML = "jpg";
            } else {
                // Add Inisde (uploadedFileIconText) The Uploaded File Type 
                uploadedFileIconText.innerHTML = isImage[0];
            }
            ;
            // If The Uploaded File Is An Image
            if (isImage.length !== 0) {
                // Check, If File Size Is 2MB or Less
                if (fileSize <= 10000000) {
                    return true;
                } else {
                    return alert("Please Your File Should be 2 Megabytes or Less");
                }
                ;
            } else {
                return alert("Please make sure to upload An Image File Type");
            }
            ;
        }
        ;
    // :)
    }, []);
    const uploadToClient = (event)=>{
        if (event.target.files && event.target.files[0]) {
            const i = event.target.files[0];
            setImage(i);
            setCreateObjectURL(URL.createObjectURL(i));
        }
    };
    const picUploadToServer = async (event)=>{
        const body = new FormData();
        body.append("file", image);
        const response = await fetch("/api/admin/file-upload", {
            method: "POST",
            body
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            id: "uploadArea",
            className: "upload-area",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "upload-area__header",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "upload-area__title",
                            variant: "h5",
                            component: "p",
                            children: "Upload your file"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                            sx: {
                                mt: 2
                            },
                            component: "p",
                            className: "upload-area__paragraph",
                            children: "File should be an image"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("strong", {
                            className: "upload-area__tooltip",
                            children: [
                                "Like",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "upload-area__tooltip-data"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "dropZoon",
                    className: "upload-area__drop-zoon drop-zoon",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "drop-zoon__icon",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "bx bxs-file-image"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                            component: "p",
                            className: "drop-zoon__paragraph",
                            children: "Drop your file here or Click to Browse"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            id: "loadingText",
                            className: "drop-zoon__loading-text",
                            children: "Please Wait"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "",
                            width: "300",
                            height: "300",
                            alt: "Preview Image",
                            id: "previewImage",
                            className: "drop-zoon__preview-image",
                            draggable: "false"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            type: "file",
                            onChange: uploadToClient,
                            id: "fileInput",
                            className: "drop-zoon__file-input",
                            accept: "image/*"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    id: "fileDetails",
                    className: "upload-area__file-details file-details",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "file-details__title",
                            component: "p",
                            children: "Uploaded File"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            id: "uploadedFile",
                            className: "uploaded-file",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "uploaded-file__icon-container",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                            className: "bx bxs-file-blank uploaded-file__icon"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "uploaded-file__icon-text"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    id: "uploadedFileInfo",
                                    className: "uploaded-file__info",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "uploaded-file__name",
                                            children: "Proejct 1"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "uploaded-file__counter",
                                            children: "0%"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_2___default()), {
                            onClick: picUploadToServer,
                            disabled: !image,
                            variant: "outlined",
                            children: "Save"
                        })
                    ]
                })
            ]
        })
    });
};


/***/ })

};
;