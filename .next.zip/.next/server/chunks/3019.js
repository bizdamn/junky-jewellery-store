"use strict";
exports.id = 3019;
exports.ids = [3019];
exports.modules = {

/***/ 5777:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2105);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9915);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6887);
/* harmony import */ var _Wrappers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3155);
/* harmony import */ var _Notification_Notification__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5579);
/* harmony import */ var _UserAvatar_UserAvatar__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8870);
/* harmony import */ var _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1292);
/* harmony import */ var _utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2735);
/* harmony import */ var _mui_icons_material_SwitchAccount__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8189);
/* harmony import */ var _mui_icons_material_SwitchAccount__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_SwitchAccount__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_icons_material_Help__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5538);
/* harmony import */ var _mui_icons_material_Help__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Help__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7608);
/* harmony import */ var _mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_7__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_16__]);
([js_cookie__WEBPACK_IMPORTED_MODULE_7__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









// styles

// components




// context




const messages = [
    {
        id: 0,
        variant: "warning",
        name: "Jane Hew",
        message: "Hey! How is it going?",
        time: "9:32"
    },
    {
        id: 1,
        variant: "success",
        name: "Lloyd Brown",
        message: "Check out my new Dashboard",
        time: "9:18"
    },
    {
        id: 2,
        variant: "primary",
        name: "Mark Winstein",
        message: "I want rearrange the appointment",
        time: "9:15"
    },
    {
        id: 3,
        variant: "secondary",
        name: "Liana Dutti",
        message: "Good news from sale department",
        time: "9:09"
    }, 
];
const notifications = [
    {
        id: 0,
        color: "warning",
        message: "Check out this awesome ticket"
    },
    {
        id: 1,
        color: "success",
        type: "info",
        message: "What is the best way to get ..."
    },
    {
        id: 2,
        color: "secondary",
        type: "notification",
        message: "This is just a simple notification"
    },
    {
        id: 3,
        color: "primary",
        type: "e-commerce",
        message: "12 new orders has arrived today"
    }, 
];
function Header(props) {
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_16__/* .AdminDataStore */ .p);
    const { adminStoreInfo  } = state;
    var classes = (0,_styles__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    // global
    var layoutState = (0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_17__/* .useLayoutState */ .Vn)();
    var layoutDispatch = (0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_17__/* .useLayoutDispatch */ .BQ)();
    // local
    var { 0: mailMenu , 1: setMailMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    var { 0: isMailsUnread , 1: setIsMailsUnread  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    var { 0: notificationsMenu , 1: setNotificationsMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    var { 0: isNotificationsUnread , 1: setIsNotificationsUnread  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    var { 0: profileMenu , 1: setProfileMenu  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    var { 0: isSearchOpen , 1: setSearchOpen  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const logoutClickHandler = ()=>{
        dispatch({
            type: "USER_LOGOUT"
        });
        js_cookie__WEBPACK_IMPORTED_MODULE_7__["default"].remove("adminStoreInfo");
        router.push("/admin/login");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.AppBar, {
        position: "fixed",
        className: classes.appBar,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Toolbar, {
            className: classes.toolbar,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                    color: "inherit",
                    onClick: ()=>(0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_17__/* .toggleSidebar */ .GB)(layoutDispatch)
                    ,
                    className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.headerMenuButtonSandwich, classes.headerMenuButtonCollapse),
                    children: layoutState.isSidebarOpened ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.ArrowBack, {
                        classes: {
                            root: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.headerIcon, classes.headerIconCollapse)
                        }
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.Menu, {
                        classes: {
                            root: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.headerIcon, classes.headerIconCollapse)
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: "/admin",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                            alt: "Make My Commerce",
                            src: "/admin/images/light-logo.svg",
                            width: 65,
                            height: 40
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: "/admin",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Typography */ .ZT, {
                            variant: "h6",
                            weight: "medium",
                            className: classes.logotype,
                            children: "Make My Commerce"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: classes.grow
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.search, {
                        [classes.searchFocused]: isSearchOpen
                    }),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.searchIcon, {
                                [classes.searchIconOpened]: isSearchOpen
                            }),
                            onClick: ()=>setSearchOpen(!isSearchOpen)
                            ,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.Search, {
                                classes: {
                                    root: classes.headerIcon
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.InputBase, {
                            placeholder: "Search\u2026",
                            classes: {
                                root: classes.inputRoot,
                                input: classes.inputInput
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                    color: "inherit",
                    "aria-controls": "mail-menu",
                    onClick: (e)=>{
                        setNotificationsMenu(e.currentTarget);
                        setIsNotificationsUnread(false);
                    },
                    className: classes.headerMenuButton,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Badge */ .Ct, {
                        badgeContent: isNotificationsUnread ? notifications.length : null,
                        color: "warning",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.NotificationsNone, {
                            classes: {
                                root: classes.headerIcon
                            }
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                    color: "inherit",
                    "aria-controls": "mail-menu",
                    onClick: (e)=>{
                        setMailMenu(e.currentTarget);
                        setIsMailsUnread(false);
                    },
                    className: classes.headerMenuButton,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Badge */ .Ct, {
                        badgeContent: isMailsUnread ? messages.length : null,
                        color: "secondary",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.MailOutline, {
                            classes: {
                                root: classes.headerIcon
                            }
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                    color: "inherit",
                    className: classes.headerMenuButton,
                    "aria-controls": "profile-menu",
                    onClick: (e)=>setProfileMenu(e.currentTarget)
                    ,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_5__.Person, {
                        classes: {
                            root: classes.headerIcon
                        }
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Menu, {
                    id: "notifications-menu",
                    open: Boolean(notificationsMenu),
                    anchorEl: notificationsMenu,
                    onClose: ()=>setNotificationsMenu(null)
                    ,
                    className: classes.headerMenu,
                    disableAutoFocusItem: true,
                    children: notifications.map((notification)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                            onClick: ()=>setNotificationsMenu(null)
                            ,
                            className: classes.headerMenuItem,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Notification_Notification__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                ...notification,
                                typographyVariant: "inherit"
                            })
                        }, notification.id)
                    )
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Menu, {
                    id: "profile-menu",
                    open: Boolean(profileMenu),
                    anchorEl: profileMenu,
                    onClose: ()=>setProfileMenu(null)
                    ,
                    className: classes.headerMenu,
                    classes: {
                        paper: classes.profileMenu
                    },
                    disableAutoFocusItem: true,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: classes.profileMenuUser,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Typography */ .ZT, {
                                            variant: "h5",
                                            component: "p",
                                            weight: "medium",
                                            children: adminStoreInfo ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: [
                                                    "  ",
                                                    adminStoreInfo.name
                                                ]
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                        })
                                    })
                                }),
                                adminStoreInfo ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        "  ",
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Typography */ .ZT, {
                                            component: "p",
                                            children: [
                                                " ",
                                                "Store ID:",
                                                " ",
                                                adminStoreInfo._id,
                                                "  "
                                            ]
                                        })
                                    ]
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/admin/profile",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.profileMenuItem, classes.headerMenuItem),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_SwitchAccount__WEBPACK_IMPORTED_MODULE_13___default()), {
                                            className: classes.profileMenuIcon
                                        }),
                                        " Manage Account"
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "https://makemycommerce.in/help-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.profileMenuItem, classes.headerMenuItem),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Help__WEBPACK_IMPORTED_MODULE_14___default()), {
                                            className: classes.profileMenuIcon
                                        }),
                                        "Help Center"
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "https://makemycommerce.in/consult-expert",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.MenuItem, {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_6___default()(classes.profileMenuItem, classes.headerMenuItem),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_VerifiedUser__WEBPACK_IMPORTED_MODULE_15___default()), {
                                            className: classes.profileMenuIcon
                                        }),
                                        "Consult a Expert"
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classes.profileMenuUser,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Wrappers__WEBPACK_IMPORTED_MODULE_10__/* .Typography */ .ZT, {
                                className: classes.profileMenuLink,
                                color: "primary",
                                onClick: logoutClickHandler,
                                children: "Sign Out"
                            })
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6887:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4628);
/* harmony import */ var _material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__.makeStyles)((theme)=>({
        logotype: {
            color: "white",
            marginLeft: theme.spacing(2.5),
            marginRight: theme.spacing(2.5),
            fontWeight: 500,
            fontSize: 18,
            whiteSpace: "nowrap",
            [theme.breakpoints.down("xs")]: {
                display: "none"
            }
        },
        appBar: {
            width: "100vw",
            zIndex: theme.zIndex.drawer + 1,
            transition: theme.transitions.create([
                "margin"
            ], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            })
        },
        toolbar: {
            paddingLeft: theme.spacing(2),
            paddingRight: theme.spacing(2)
        },
        hide: {
            display: "none"
        },
        grow: {
            flexGrow: 1
        },
        search: {
            position: "relative",
            borderRadius: 25,
            paddingLeft: theme.spacing(2.5),
            width: 36,
            backgroundColor: (0,_material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.common.black, 0),
            transition: theme.transitions.create([
                "background-color",
                "width"
            ]),
            "&:hover": {
                cursor: "pointer",
                backgroundColor: (0,_material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.common.black, 0.08)
            }
        },
        searchFocused: {
            backgroundColor: (0,_material_ui_core_styles_colorManipulator__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.common.black, 0.08),
            width: "100%",
            [theme.breakpoints.up("md")]: {
                width: 250
            }
        },
        searchIcon: {
            width: 36,
            right: 0,
            height: "100%",
            position: "absolute",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            transition: theme.transitions.create("right"),
            "&:hover": {
                cursor: "pointer"
            }
        },
        searchIconOpened: {
            right: theme.spacing(1.25)
        },
        inputRoot: {
            color: "inherit",
            width: "100%"
        },
        inputInput: {
            height: 36,
            padding: 0,
            paddingRight: 36 + theme.spacing(1.25),
            width: "100%"
        },
        messageContent: {
            display: "flex",
            flexDirection: "column"
        },
        headerMenu: {
            marginTop: theme.spacing(7)
        },
        headerMenuList: {
            display: "flex",
            flexDirection: "column"
        },
        headerMenuItem: {
            "&:hover, &:focus": {
                backgroundColor: theme.palette.background.light
            }
        },
        headerMenuButton: {
            marginLeft: theme.spacing(2),
            padding: theme.spacing(0.5)
        },
        headerMenuButtonSandwich: {
            marginLeft: 9,
            [theme.breakpoints.down("sm")]: {
                marginLeft: 0
            },
            padding: theme.spacing(0.5)
        },
        headerMenuButtonCollapse: {
            marginRight: theme.spacing(2)
        },
        headerIcon: {
            fontSize: 28,
            color: "rgba(255, 255, 255, 0.35)"
        },
        headerIconCollapse: {
            color: "white"
        },
        profileMenu: {
            minWidth: 265
        },
        profileMenuUser: {
            display: "flex",
            flexDirection: "column",
            padding: theme.spacing(2)
        },
        profileMenuItem: {
            color: theme.palette.text.hint
        },
        profileMenuIcon: {
            marginRight: theme.spacing(2),
            color: theme.palette.text.hint,
            "&:hover": {
                color: theme.palette.primary.main
            }
        },
        profileMenuLink: {
            fontSize: 16,
            textDecoration: "none",
            "&:hover": {
                cursor: "pointer"
            }
        },
        messageNotification: {
            height: "auto",
            display: "flex",
            alignItems: "center",
            "&:hover, &:focus": {
                backgroundColor: theme.palette.background.light
            }
        },
        messageNotificationSide: {
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            marginRight: theme.spacing(2)
        },
        messageNotificationBodySide: {
            alignItems: "flex-start",
            marginRight: 0
        },
        sendMessageButton: {
            margin: theme.spacing(4),
            marginTop: theme.spacing(2),
            marginBottom: theme.spacing(2),
            textTransform: "none"
        },
        sendButtonIcon: {
            marginLeft: theme.spacing(2)
        },
        purchaseBtn: {
            [theme.breakpoints.down("sm")]: {
                display: "none"
            },
            marginRight: theme.spacing(3)
        }
    })
));


/***/ }),

/***/ 5579:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Notification)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(8130);
// EXTERNAL MODULE: external "@material-ui/icons"
var icons_ = __webpack_require__(2105);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: external "tinycolor2"
var external_tinycolor2_ = __webpack_require__(2680);
var external_tinycolor2_default = /*#__PURE__*/__webpack_require__.n(external_tinycolor2_);
;// CONCATENATED MODULE: ./components/admin/ui/Notification/styles.js

/* harmony default export */ const styles = ((0,styles_.makeStyles)((theme)=>({
        notificationContainer: {
            display: "flex",
            alignItems: "center"
        },
        notificationContained: {
            borderRadius: 45,
            height: 45,
            boxShadow: theme.customShadows.widgetDark
        },
        notificationContainedShadowless: {
            boxShadow: "none"
        },
        notificationIconContainer: {
            minWidth: 45,
            height: 45,
            borderRadius: 45,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 24
        },
        notificationIconContainerContained: {
            fontSize: 18,
            color: "#FFFFFF80"
        },
        notificationIconContainerRounded: {
            marginRight: theme.spacing(2)
        },
        containedTypography: {
            color: "white"
        },
        messageContainer: {
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexGrow: 1
        },
        extraButton: {
            color: "white",
            "&:hover, &:focus": {
                background: "transparent"
            }
        }
    })
));

// EXTERNAL MODULE: ./components/admin/ui/Wrappers/Wrappers.js
var Wrappers = __webpack_require__(3155);
;// CONCATENATED MODULE: ./components/admin/ui/Notification/Notification.js







// styles

// components

const typesIcons = {
    "e-commerce": /*#__PURE__*/ jsx_runtime_.jsx(icons_.ShoppingCart, {}),
    notification: /*#__PURE__*/ jsx_runtime_.jsx(icons_.NotificationsNone, {}),
    offer: /*#__PURE__*/ jsx_runtime_.jsx(icons_.LocalOffer, {}),
    info: /*#__PURE__*/ jsx_runtime_.jsx(icons_.ThumbUp, {}),
    message: /*#__PURE__*/ jsx_runtime_.jsx(icons_.Email, {}),
    feedback: /*#__PURE__*/ jsx_runtime_.jsx(icons_.SmsFailed, {}),
    customer: /*#__PURE__*/ jsx_runtime_.jsx(icons_.AccountBox, {}),
    shipped: /*#__PURE__*/ jsx_runtime_.jsx(icons_.Done, {}),
    delivered: /*#__PURE__*/ jsx_runtime_.jsx(icons_.BusinessCenter, {}),
    defence: /*#__PURE__*/ jsx_runtime_.jsx(icons_.Error, {}),
    report: /*#__PURE__*/ jsx_runtime_.jsx(icons_.Report, {}),
    upload: /*#__PURE__*/ jsx_runtime_.jsx(icons_.Publish, {}),
    disc: /*#__PURE__*/ jsx_runtime_.jsx(icons_.DiscFull, {})
};
function Notification({ variant , ...props }) {
    var classes = styles();
    var theme = (0,styles_.useTheme)();
    const icon = getIconByType(props.type);
    const iconWithStyles = /*#__PURE__*/ external_react_default().cloneElement(icon, {
        classes: {
            root: classes.notificationIcon
        },
        style: {
            color: variant !== "contained" && theme.palette[props.color] && theme.palette[props.color].main
        }
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: external_classnames_default()(classes.notificationContainer, props.className, {
            [classes.notificationContained]: variant === "contained",
            [classes.notificationContainedShadowless]: props.shadowless
        }),
        style: {
            backgroundColor: variant === "contained" && theme.palette[props.color] && theme.palette[props.color].main
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: external_classnames_default()(classes.notificationIconContainer, {
                    [classes.notificationIconContainerContained]: variant === "contained",
                    [classes.notificationIconContainerRounded]: variant === "rounded"
                }),
                style: {
                    backgroundColor: variant === "rounded" && theme.palette[props.color] && external_tinycolor2_default()(theme.palette[props.color].main).setAlpha(0.15).toRgbString()
                },
                children: iconWithStyles
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: classes.messageContainer,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Wrappers/* Typography */.ZT, {
                        className: external_classnames_default()({
                            [classes.containedTypography]: variant === "contained"
                        }),
                        variant: props.typographyVariant,
                        size: variant !== "contained" && !props.typographyVariant && "md",
                        children: props.message
                    }),
                    props.extraButton && props.extraButtonClick && /*#__PURE__*/ jsx_runtime_.jsx(core_.Button, {
                        onClick: props.extraButtonClick,
                        disableRipple: true,
                        className: classes.extraButton,
                        children: props.extraButton
                    })
                ]
            })
        ]
    });
};
// ####################################################################
function getIconByType(type = "offer") {
    return typesIcons[type];
}


/***/ }),

/***/ 2229:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2105);
/* harmony import */ var _material_ui_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4492);
/* harmony import */ var _mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_TravelExplore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8551);
/* harmony import */ var _mui_icons_material_TravelExplore__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_TravelExplore__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9226);
/* harmony import */ var _mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_StoreMallDirectory__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4502);
/* harmony import */ var _mui_icons_material_StoreMallDirectory__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_StoreMallDirectory__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(32);
/* harmony import */ var _mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_CurrencyRupee__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3924);
/* harmony import */ var _mui_icons_material_CurrencyRupee__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_CurrencyRupee__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7197);
/* harmony import */ var _fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6466);
/* harmony import */ var _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3349);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1292);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3906);
/* harmony import */ var _components_SidebarLink_SidebarLink__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(396);
/* harmony import */ var _components_Dot__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1075);
/* harmony import */ var _utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2735);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_17__]);
_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_17__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















// styles

// components


// context

function Sidebar({ location  }) {
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_17__/* .AdminDataStore */ .p);
    const { adminStoreInfo  } = state;
    const structure = [
        {
            id: 0,
            label: "Home",
            link: "/admin/",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__.Home, {})
        },
        // { id: 0, label: 'Explore', link: '/admin/explore-products', icon: <TravelExploreIcon /> },
        {
            id: 1,
            label: "Products",
            link: "/admin/products",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10__.FontAwesomeIcon, {
                style: {
                    fontSize: "1.3rem"
                },
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11__.faTags
            }),
            children: [
                {
                    label: "All Products",
                    link: "/admin/products"
                },
                {
                    label: "Edit Products",
                    link: "/admin/edit-product"
                },
                {
                    label: "Inventory",
                    link: "/admin/products/inventory"
                },
                {
                    label: "Categories",
                    link: "/admin/products/categories"
                }, 
            ]
        },
        {
            id: 2,
            label: "Orders",
            link: "/admin/orders",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10__.FontAwesomeIcon, {
                style: {
                    fontSize: "1.3rem"
                },
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11__.faCartArrowDown
            })
        },
        {
            id: 3,
            label: "Analytics",
            link: "/admin/analytics",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_fortawesome_react_fontawesome__WEBPACK_IMPORTED_MODULE_10__.FontAwesomeIcon, {
                style: {
                    fontSize: "1.3rem"
                },
                icon: _fortawesome_free_solid_svg_icons__WEBPACK_IMPORTED_MODULE_11__.faChartBar
            })
        },
        {
            id: 5,
            type: "divider"
        },
        {
            id: 8,
            label: "SEO",
            link: "/admin/seo",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Google__WEBPACK_IMPORTED_MODULE_4___default()), {})
        },
        {
            id: 9,
            label: "Customers",
            link: "/admin/customers",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Email__WEBPACK_IMPORTED_MODULE_6___default()), {})
        },
        {
            id: 98,
            label: "Payment",
            link: "/admin/settings/payment-provider",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_CurrencyRupee__WEBPACK_IMPORTED_MODULE_9___default()), {})
        },
        {
            id: 23,
            label: "Settings",
            link: "/admin/settings",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Settings__WEBPACK_IMPORTED_MODULE_8___default()), {}),
            children: [
                {
                    label: "Store Details",
                    link: "/admin/settings"
                },
                {
                    label: "Address",
                    link: "/admin/settings/address"
                },
                {
                    label: "Shipping",
                    link: "/admin/shipping"
                },
                {
                    label: "Checkout",
                    link: "/admin/settings/checkout"
                },
                {
                    label: "Billing",
                    link: "/admin/settings/billing"
                },
                {
                    label: "Taxes",
                    link: "/admin/settings/taxes"
                },
                // { label: 'Locations', link: '/admin/settings/locations' },
                // { label: 'Languages', link: '/admin/settings/languages' },
                {
                    label: "Policies",
                    link: "/admin/settings/policies"
                }, 
            ]
        },
        {
            id: 6,
            type: "title",
            label: "ONLINE STORE"
        },
        {
            id: 29,
            label: "View Online Store",
            link: `${adminStoreInfo ? adminStoreInfo.storeLink : "/"}`,
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_StoreMallDirectory__WEBPACK_IMPORTED_MODULE_7___default()), {})
        },
        {
            id: 10,
            type: "divider"
        },
        {
            id: 11,
            type: "title",
            label: "Billing"
        },
        {
            id: 12,
            label: "Plans",
            link: "/admin/pricing",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Dot__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                size: "small",
                color: "secondary"
            })
        }, 
    ];
    var classes = (0,_styles__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    var theme = (0,_material_ui_styles__WEBPACK_IMPORTED_MODULE_12__.useTheme)();
    // global
    var { isSidebarOpened  } = (0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_18__/* .useLayoutState */ .Vn)();
    var layoutDispatch = (0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_18__/* .useLayoutDispatch */ .BQ)();
    // local
    var { 0: isPermanent , 1: setPermanent  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(function() {
        window.addEventListener("resize", handleWindowWidthChange);
        handleWindowWidthChange();
        return function cleanup() {
            window.removeEventListener("resize", handleWindowWidthChange);
        };
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Drawer, {
        variant: isPermanent ? "permanent" : "temporary",
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()(classes.drawer, {
            [classes.drawerOpen]: isSidebarOpened,
            [classes.drawerClose]: !isSidebarOpened
        }),
        classes: {
            paper: classnames__WEBPACK_IMPORTED_MODULE_13___default()({
                [classes.drawerOpen]: isSidebarOpened,
                [classes.drawerClose]: !isSidebarOpened
            })
        },
        open: isSidebarOpened,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classes.toolbar
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classes.mobileBackButton,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                    onClick: ()=>(0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_18__/* .toggleSidebar */ .GB)(layoutDispatch)
                    ,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_icons__WEBPACK_IMPORTED_MODULE_3__.ArrowBack, {
                        classes: {
                            root: classnames__WEBPACK_IMPORTED_MODULE_13___default()(classes.headerIcon, classes.headerIconCollapse)
                        }
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.List, {
                className: classes.sidebarList,
                children: structure.map((link)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_SidebarLink_SidebarLink__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                        location: location,
                        isSidebarOpened: isSidebarOpened,
                        ...link
                    }, link.id)
                )
            })
        ]
    });
    // ##################################################################
    function handleWindowWidthChange() {
        var windowWidth = window.innerWidth;
        var breakpointWidth = theme.breakpoints.values.md;
        var isSmallScreen = windowWidth < breakpointWidth;
        if (isSmallScreen && isPermanent) {
            setPermanent(false);
        } else if (!isSmallScreen && !isPermanent) {
            setPermanent(true);
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dot)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3349);
/* harmony import */ var _material_ui_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);




// styles
var useStyles = (0,_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__.makeStyles)((theme)=>({
        dotBase: {
            width: 8,
            height: 8,
            backgroundColor: theme.palette.text.hint,
            borderRadius: "50%",
            transition: theme.transitions.create("background-color")
        },
        dotSmall: {
            width: 5,
            height: 5
        },
        dotLarge: {
            width: 11,
            height: 11
        }
    })
);
function Dot({ size , color  }) {
    var classes = useStyles();
    var theme = (0,_material_ui_styles__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(classes.dotBase, {
            [classes.dotLarge]: size === "large",
            [classes.dotSmall]: size === "small"
        }),
        style: {
            backgroundColor: color && theme.palette[color] && theme.palette[color].main
        }
    });
};


/***/ }),

/***/ 396:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SidebarLink)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(8130);
// EXTERNAL MODULE: external "@material-ui/icons"
var icons_ = __webpack_require__(2105);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
;// CONCATENATED MODULE: ./components/admin/ui/Sidebar/components/SidebarLink/styles.js

/* harmony default export */ const styles = ((0,styles_.makeStyles)((theme)=>({
        link: {
            textDecoration: "none",
            "&:hover, &:focus": {
                backgroundColor: theme.palette.background.light
            }
        },
        externalLink: {
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            textDecoration: "none"
        },
        linkActive: {
            backgroundColor: theme.palette.background.light
        },
        linkNested: {
            paddingLeft: 0,
            "&:hover, &:focus": {
                backgroundColor: "#FFFFFF"
            }
        },
        linkIcon: {
            marginRight: theme.spacing(1),
            color: theme.palette.text.secondary + "99",
            transition: theme.transitions.create("color"),
            width: 24,
            display: "flex",
            justifyContent: "center"
        },
        linkIconActive: {
            color: theme.palette.primary.main
        },
        linkText: {
            padding: 0,
            color: theme.palette.text.secondary + "CC",
            transition: theme.transitions.create([
                "opacity",
                "color"
            ]),
            fontSize: 16
        },
        linkTextActive: {
            color: theme.palette.text.primary
        },
        linkTextHidden: {
            opacity: 0
        },
        nestedList: {
            paddingLeft: theme.spacing(2) + 3
        },
        sectionTitle: {
            marginLeft: theme.spacing(4.5),
            marginTop: theme.spacing(2),
            marginBottom: theme.spacing(2)
        },
        divider: {
            marginTop: theme.spacing(2),
            marginBottom: theme.spacing(4),
            height: 1,
            backgroundColor: "#D8D8D880"
        }
    })
));

// EXTERNAL MODULE: ./components/admin/ui/Sidebar/components/Dot.js
var Dot = __webpack_require__(1075);
;// CONCATENATED MODULE: ./components/admin/ui/Sidebar/components/SidebarLink/SidebarLink.js







// styles

// components

function SidebarLink({ link , icon , label , children , location , isSidebarOpened , nested , type ,  }) {
    const router = (0,router_.useRouter)();
    var classes = styles();
    // local
    var { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    var isLinkActive = link === router.pathname;
    if (type === "title") return /*#__PURE__*/ jsx_runtime_.jsx(core_.Typography, {
        className: external_classnames_default()(classes.linkText, classes.sectionTitle, {
            [classes.linkTextHidden]: !isSidebarOpened
        }),
        children: label
    });
    if (type === "divider") return /*#__PURE__*/ jsx_runtime_.jsx(core_.Divider, {
        className: classes.divider
    });
    if (link && link.includes("http")) {
        return /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItem, {
            button: true,
            className: classes.link,
            classes: {
                root: external_classnames_default()(classes.linkRoot, {
                    [classes.linkActive]: isLinkActive && !nested,
                    [classes.linkNested]: nested
                })
            },
            disableRipple: true,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                className: classes.externalLink,
                href: link,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemIcon, {
                        className: external_classnames_default()(classes.linkIcon, {
                            [classes.linkIconActive]: isLinkActive
                        }),
                        children: nested ? /*#__PURE__*/ jsx_runtime_.jsx(Dot/* default */.Z, {
                            color: isLinkActive && "primary"
                        }) : icon
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemText, {
                        classes: {
                            primary: external_classnames_default()(classes.linkText, {
                                [classes.linkTextActive]: isLinkActive,
                                [classes.linkTextHidden]: !isSidebarOpened
                            })
                        },
                        primary: label
                    })
                ]
            })
        });
    }
    if (!children) return /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
        href: link,
        passHref: true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.ListItem, {
            button: true,
            // component={link && Link}
            // to={link}
            // className={classes.link}
            // classes={{
            //   root: classnames(classes.linkRoot, {
            //     [classes.linkActive]: isLinkActive && !nested,
            //     [classes.linkNested]: nested,
            //   }),
            // }}
            disableRipple: true,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemIcon, {
                    className: external_classnames_default()(classes.linkIcon, {
                        [classes.linkIconActive]: isLinkActive
                    }),
                    children: nested ? /*#__PURE__*/ jsx_runtime_.jsx(Dot/* default */.Z, {
                        color: isLinkActive && "primary"
                    }) : icon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemText, {
                    classes: {
                        primary: external_classnames_default()(classes.linkText, {
                            [classes.linkTextActive]: isLinkActive,
                            [classes.linkTextHidden]: !isSidebarOpened
                        })
                    },
                    primary: label
                })
            ]
        })
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: link,
                passHref: true,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.ListItem, {
                    button: true,
                    // component={link && Link}
                    // to={link}
                    onClick: toggleCollapse,
                    className: classes.link,
                    disableRipple: true,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemIcon, {
                            className: external_classnames_default()(classes.linkIcon, {
                                [classes.linkIconActive]: isLinkActive
                            }),
                            children: icon ? icon : /*#__PURE__*/ jsx_runtime_.jsx(icons_.Inbox, {})
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemText, {
                            classes: {
                                primary: external_classnames_default()(classes.linkText, {
                                    [classes.linkTextActive]: isLinkActive,
                                    [classes.linkTextHidden]: !isSidebarOpened
                                })
                            },
                            primary: label
                        })
                    ]
                })
            }),
            children && /*#__PURE__*/ jsx_runtime_.jsx(core_.Collapse, {
                in: isOpen && isSidebarOpened,
                timeout: "auto",
                unmountOnExit: true,
                className: classes.nestedList,
                children: /*#__PURE__*/ jsx_runtime_.jsx(core_.List, {
                    component: "div",
                    disablePadding: true,
                    children: children.map((childrenLink)=>/*#__PURE__*/ jsx_runtime_.jsx(SidebarLink, {
                            location: location,
                            isSidebarOpened: isSidebarOpened,
                            classes: classes,
                            nested: true,
                            ...childrenLink
                        }, childrenLink && childrenLink.link)
                    )
                })
            })
        ]
    });
    // ###########################################################
    function toggleCollapse(e) {
        if (isSidebarOpened) {
            e.preventDefault();
            setIsOpen(!isOpen);
        }
    }
};


/***/ }),

/***/ 3906:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const drawerWidth = 240;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__.makeStyles)((theme)=>({
        menuButton: {
            marginLeft: 12,
            marginRight: 36
        },
        hide: {
            display: "none"
        },
        drawer: {
            width: drawerWidth,
            flexShrink: 0,
            whiteSpace: "nowrap"
        },
        drawerOpen: {
            width: drawerWidth,
            transition: theme.transitions.create("width", {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        },
        drawerClose: {
            transition: theme.transitions.create("width", {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            }),
            overflowX: "hidden",
            width: theme.spacing(7) + 40,
            [theme.breakpoints.down("sm")]: {
                width: drawerWidth
            }
        },
        toolbar: {
            ...theme.mixins.toolbar,
            [theme.breakpoints.down("sm")]: {
                display: "none"
            }
        },
        content: {
            flexGrow: 1,
            padding: theme.spacing(3)
        },
        /* sidebarList: {
    marginTop: theme.spacing(6),
  }, */ mobileBackButton: {
            marginTop: theme.spacing(0.5),
            marginLeft: 18,
            [theme.breakpoints.only("sm")]: {
                marginTop: theme.spacing(0.625)
            },
            [theme.breakpoints.up("md")]: {
                display: "none"
            }
        }
    })
));


/***/ }),

/***/ 8870:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@material-ui/styles"
var styles_ = __webpack_require__(3349);
// EXTERNAL MODULE: external "@material-ui/core/styles"
var core_styles_ = __webpack_require__(8308);
;// CONCATENATED MODULE: ./components/admin/ui/UserAvatar/styles.js

/* harmony default export */ const styles = ((0,core_styles_.makeStyles)(()=>({
        avatar: {
            width: 30,
            height: 30,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            borderRadius: "50%"
        },
        text: {
            color: "white"
        }
    })
));

// EXTERNAL MODULE: ./components/admin/ui/Wrappers/Wrappers.js
var Wrappers = __webpack_require__(3155);
;// CONCATENATED MODULE: ./components/admin/ui/UserAvatar/UserAvatar.js



// styles

// components

function UserAvatar({ color ="primary" , ...props }) {
    var classes = useStyles();
    var theme = useTheme();
    var letters = props.name.split(" ").map((word)=>word[0]
    ).join("");
    return /*#__PURE__*/ _jsx("div", {
        className: classes.avatar,
        style: {
            backgroundColor: theme.palette[color].main
        },
        children: /*#__PURE__*/ _jsx(Typography, {
            className: classes.text,
            children: letters
        })
    });
};


/***/ }),

/***/ 3155:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ct": () => (/* binding */ Badge),
/* harmony export */   "ZT": () => (/* binding */ Typography)
/* harmony export */ });
/* unused harmony export Button */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);





// styles
var useStyles = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__.makeStyles)((theme)=>({
        badge: {
            fontWeight: 600,
            height: 16,
            minWidth: 16
        }
    })
);
function Badge({ children , colorBrightness , color , ...props }) {
    var classes = useStyles();
    var theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    var Styled = createStyled({
        badge: {
            backgroundColor: getColor(color, theme, colorBrightness)
        }
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Styled, {
        children: (styledProps)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Badge, {
                classes: {
                    badge: classnames__WEBPACK_IMPORTED_MODULE_4___default()(classes.badge, styledProps.classes.badge)
                },
                ...props,
                children: children
            })
    });
}
function Typography({ children , weight , size , colorBrightness , color , ...props }) {
    var theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__.Typography, {
        style: {
            color: getColor(color, theme, colorBrightness),
            fontWeight: getFontWeight(weight),
            fontSize: getFontSize(size, props.variant, theme)
        },
        ...props,
        children: children
    });
}
function Button({ children , color , className , ...props }) {
    var theme = useTheme();
    var Styled = createStyled({
        root: {
            color: getColor(color, theme)
        },
        contained: {
            backgroundColor: getColor(color, theme),
            boxShadow: theme.widget,
            color: `${color ? "white" : theme.palette.text.primary} !important`,
            "&:hover": {
                backgroundColor: getColor(color, theme, "light"),
                boxShadow: theme.widgetWide
            },
            "&:active": {
                boxShadow: theme.widgetWide
            }
        },
        outlined: {
            color: getColor(color, theme),
            borderColor: getColor(color, theme)
        },
        select: {
            backgroundColor: theme.palette.primary.main,
            color: "#fff"
        }
    });
    return /*#__PURE__*/ _jsx(Styled, {
        children: ({ classes  })=>/*#__PURE__*/ _jsx(ButtonBase, {
                classes: {
                    contained: classes.contained,
                    root: classes.root,
                    outlined: classes.outlined
                },
                ...props,
                className: classnames({
                    [classes.select]: props.select
                }, className),
                children: children
            })
    });
}

// ########################################################################
function getColor(color, theme, brigtness = "main") {
    if (color && theme.palette[color] && theme.palette[color][brigtness]) {
        return theme.palette[color][brigtness];
    }
}
function getFontWeight(style) {
    switch(style){
        case "light":
            return 300;
        case "medium":
            return 500;
        case "bold":
            return 600;
        default:
            return 400;
    }
}
function getFontSize(size, variant = "", theme) {
    var multiplier;
    switch(size){
        case "sm":
            multiplier = 0.8;
            break;
        case "md":
            multiplier = 1.5;
            break;
        case "xl":
            multiplier = 2;
            break;
        case "xxl":
            multiplier = 3;
            break;
        default:
            multiplier = 1;
            break;
    }
    var defaultSize = variant && theme.typography[variant] ? theme.typography[variant].fontSize : theme.typography.fontSize + "px";
    return `calc(${defaultSize} * ${multiplier})`;
}
function createStyled(styles, options) {
    var Styled = function(props) {
        const { children , ...other } = props;
        return children(other);
    };
    return (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__.withStyles)(styles, options)(Styled);
}


/***/ }),

/***/ 3103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AdminLayoutState)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2735);
/* harmony import */ var _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1292);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2163);
/* harmony import */ var _components_admin_ui_Header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5777);
/* harmony import */ var _components_admin_ui_Sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2229);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_admin_ui_Header__WEBPACK_IMPORTED_MODULE_3__, _components_admin_ui_Sidebar__WEBPACK_IMPORTED_MODULE_4__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__]);
([_components_admin_ui_Header__WEBPACK_IMPORTED_MODULE_3__, _components_admin_ui_Sidebar__WEBPACK_IMPORTED_MODULE_4__, _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





// import { Box, IconButton, Link } from '@material-ui/core'
// import LinearProgressComponent from './LinearProgressComponent'
// import Icon from '@mui/material/Icon';
//icons
// import {
//   FacebookIcon,
//   TwitterIcon,
//   GithubIcon,
// } from '@mui/icons-material'
// styles

// components


// context

function AdminLayoutState(props) {
    const { state  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__/* .AdminDataStore */ .p);
    const { adminStoreInfo  } = state;
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    // useEffect(() => {
    //   if (!adminStoreInfo) {
    //     router.push('/admin/login');
    //   }
    // }, []);
    var classes = (0,_styles__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    // global
    var layoutState = (0,_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_8__/* .useLayoutState */ .Vn)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            sx: {
                backgroundColor: "#F6F6F7"
            },
            className: classes.root,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_ui_Header__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_admin_ui_Sidebar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(classes.content, {
                        [classes.contentShift]: layoutState.isSidebarOpened
                    }),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classes.fakeToolbar
                        }),
                        props.children
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3019:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3142);
/* harmony import */ var notistack__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(notistack__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2929);
/* harmony import */ var _paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_paypal_react_paypal_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2735);
/* harmony import */ var _utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1292);
/* harmony import */ var _AdminLayoutState__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3103);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _themes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3878);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__, _AdminLayoutState__WEBPACK_IMPORTED_MODULE_8__]);
([_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__, _AdminLayoutState__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const theme = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.createTheme)({
    palette: {
        primary: {
            main: "#008060"
        }
    }
});
function Layout(props) {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const jssStyles = document.querySelector("#jss-server-side");
        if (jssStyles) {
            jssStyles.parentElement.removeChild(jssStyles);
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_admin_LayoutContext__WEBPACK_IMPORTED_MODULE_5__/* .LayoutProvider */ .aM, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(notistack__WEBPACK_IMPORTED_MODULE_2__.SnackbarProvider, {
                anchorOrigin: {
                    vertical: "top",
                    horizontal: "center"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_admin_AdminDataStore__WEBPACK_IMPORTED_MODULE_6__/* .AdminDataStoreProvider */ .Q, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.ThemeProvider, {
                        theme: theme,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_4__.ThemeProvider, {
                            theme: _themes__WEBPACK_IMPORTED_MODULE_7__/* ["default"]["default"] */ .Z["default"],
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AdminLayoutState__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                children: props.children
                            })
                        })
                    })
                })
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2163:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8308);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__.makeStyles)((theme)=>({
        root: {
            display: "flex",
            maxWidth: "100vw",
            overflowX: "hidden"
        },
        content: {
            flexGrow: 1,
            padding: theme.spacing(3),
            width: `calc(100vw - 240px)`,
            minHeight: "100vh"
        },
        contentShift: {
            width: `calc(100vw - ${240 + theme.spacing(6)}px)`,
            transition: theme.transitions.create([
                "width",
                "margin"
            ], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        },
        fakeToolbar: {
            ...theme.mixins.toolbar
        },
        link: {
            "&:not(:first-child)": {
                paddingLeft: 15
            }
        }
    })
));


/***/ }),

/***/ 3878:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layouts_themes)
});

// EXTERNAL MODULE: external "@material-ui/core/styles"
var styles_ = __webpack_require__(8308);
// EXTERNAL MODULE: external "tinycolor2"
var external_tinycolor2_ = __webpack_require__(2680);
var external_tinycolor2_default = /*#__PURE__*/__webpack_require__.n(external_tinycolor2_);
;// CONCATENATED MODULE: ./layouts/themes/default.js

const primary = "#008060";
const secondary = "#008060";
const warning = "#FFC260";
const success = "#3CD4A0";
const info = "#9013FE";
const lightenRate = 7.5;
const darkenRate = 15;
const defaultTheme = {
    palette: {
        primary: {
            main: "#008060",
            light: external_tinycolor2_default()(secondary).lighten(lightenRate).toHexString(),
            dark: external_tinycolor2_default()(secondary).darken(darkenRate).toHexString(),
            contrastText: "#FFFFFF"
        },
        secondary: {
            main: secondary,
            light: external_tinycolor2_default()(secondary).lighten(lightenRate).toHexString(),
            dark: external_tinycolor2_default()(secondary).darken(darkenRate).toHexString(),
            contrastText: "#FFFFFF"
        },
        warning: {
            main: warning,
            light: external_tinycolor2_default()(warning).lighten(lightenRate).toHexString(),
            dark: external_tinycolor2_default()(warning).darken(darkenRate).toHexString()
        },
        success: {
            main: success,
            light: external_tinycolor2_default()(success).lighten(lightenRate).toHexString(),
            dark: external_tinycolor2_default()(success).darken(darkenRate).toHexString()
        },
        info: {
            main: info,
            light: external_tinycolor2_default()(info).lighten(lightenRate).toHexString(),
            dark: external_tinycolor2_default()(info).darken(darkenRate).toHexString()
        },
        text: {
            primary: "#4A4A4A",
            secondary: "#6E6E6E",
            hint: "#B9B9B9"
        },
        background: {
            default: "#F6F7FF",
            light: "#F3F5FF"
        }
    },
    customShadows: {
        widget: "0px 3px 11px 0px #E8EAFC, 0 3px 3px -2px #B2B2B21A, 0 1px 8px 0 #9A9A9A1A",
        widgetDark: "0px 3px 18px 0px #4558A3B3, 0 3px 3px -2px #B2B2B21A, 0 1px 8px 0 #9A9A9A1A",
        widgetWide: "0px 12px 33px 0px #E8EAFC, 0 3px 3px -2px #B2B2B21A, 0 1px 8px 0 #9A9A9A1A"
    },
    overrides: {
        MuiBackdrop: {
            root: {
                backgroundColor: "#4A4A4A1A"
            }
        },
        MuiMenu: {
            paper: {
                boxShadow: "0px 3px 11px 0px #E8EAFC, 0 3px 3px -2px #B2B2B21A, 0 1px 8px 0 #9A9A9A1A"
            }
        },
        MuiSelect: {
            icon: {
                color: "#B9B9B9"
            }
        },
        MuiListItem: {
            root: {
                "&$selected": {
                    backgroundColor: "#F3F5FF !important",
                    "&:focus": {
                        backgroundColor: "#F3F5FF"
                    }
                }
            },
            button: {
                "&:hover, &:focus": {
                    backgroundColor: "#F3F5FF"
                }
            }
        },
        MuiTouchRipple: {
            child: {
                backgroundColor: "white"
            }
        },
        MuiTableRow: {
            root: {
                height: 56
            }
        },
        MuiTableCell: {
            root: {
                borderBottom: "1px solid rgba(224, 224, 224, .5)",
                paddingLeft: 24
            },
            head: {
                fontSize: "0.95rem"
            },
            body: {
                fontSize: "0.95rem"
            }
        },
        PrivateSwitchBase: {
            root: {
                marginLeft: 10
            }
        }
    }
};
/* harmony default export */ const themes_default = (defaultTheme);

;// CONCATENATED MODULE: ./layouts/themes/index.js


const overrides = {
    typography: {
        h1: {
            fontSize: "3rem"
        },
        h2: {
            fontSize: "2rem"
        },
        h3: {
            fontSize: "1.64rem"
        },
        h4: {
            fontSize: "1.5rem"
        },
        h5: {
            fontSize: "1.285rem"
        },
        h6: {
            fontSize: "1.142rem"
        }
    }
};
const themes = {
    default: (0,styles_.createTheme)({
        ...themes_default,
        ...overrides
    })
};
/* harmony default export */ const layouts_themes = (themes);


/***/ }),

/***/ 2735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BQ": () => (/* binding */ useLayoutDispatch),
/* harmony export */   "GB": () => (/* binding */ toggleSidebar),
/* harmony export */   "Vn": () => (/* binding */ useLayoutState),
/* harmony export */   "aM": () => (/* binding */ LayoutProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var LayoutStateContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext();
var LayoutDispatchContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1___default().createContext();
function layoutReducer(state, action) {
    switch(action.type){
        case "TOGGLE_SIDEBAR":
            return {
                ...state,
                isSidebarOpened: !state.isSidebarOpened
            };
        default:
            {
                throw new Error(`Unhandled action type: ${action.type}`);
            }
    }
}
function LayoutProvider({ children  }) {
    var [state, dispatch] = react__WEBPACK_IMPORTED_MODULE_1___default().useReducer(layoutReducer, {
        isSidebarOpened: true
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LayoutStateContext.Provider, {
        value: state,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LayoutDispatchContext.Provider, {
            value: dispatch,
            children: children
        })
    });
}
function useLayoutState() {
    var context = react__WEBPACK_IMPORTED_MODULE_1___default().useContext(LayoutStateContext);
    if (context === undefined) {
        throw new Error("useLayoutState must be used within a LayoutProvider");
    }
    return context;
}
function useLayoutDispatch() {
    var context = react__WEBPACK_IMPORTED_MODULE_1___default().useContext(LayoutDispatchContext);
    if (context === undefined) {
        throw new Error("useLayoutDispatch must be used within a LayoutProvider");
    }
    return context;
}

// ###########################################################
function toggleSidebar(dispatch) {
    dispatch({
        type: "TOGGLE_SIDEBAR"
    });
}


/***/ })

};
;