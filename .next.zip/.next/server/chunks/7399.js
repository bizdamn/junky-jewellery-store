exports.id = 7399;
exports.ids = [7399];
exports.modules = {

/***/ 71436:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductTag_root__Nxivt",
	"name": "ProductTag_name__C_niq",
	"fontsizing": "ProductTag_fontsizing__XnIPn",
	"price": "ProductTag_price__RDK06"
};


/***/ }),

/***/ 59047:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "WishlistButton_root__crSyc",
	"icon": "WishlistButton_icon__J690_",
	"loading": "WishlistButton_loading__BcgF9",
	"inWishlist": "WishlistButton_inWishlist__uwrZI"
};


/***/ }),

/***/ 10343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71436);
/* harmony import */ var _ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2__);



const ProductTag = ({ name , price , className ="" , fontSize =32 ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2___default().root), className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2___default().name),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_1___default()({
                        [(_ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2___default().fontsizing)]: fontSize < 32
                    }),
                    style: {
                        fontSize: `${fontSize}px`,
                        lineHeight: `${fontSize}px`
                    },
                    children: name
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_ProductTag_module_css__WEBPACK_IMPORTED_MODULE_2___default().price),
                children: price
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductTag);


/***/ }),

/***/ 72354:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23968);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(80505);
/* harmony import */ var _framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90774);
/* harmony import */ var _framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(12633);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59047);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52767);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__]);
_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const WishlistButton = ({ productId , variant , className , ...props })=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__/* .DataStore */ .K);
    const { customerInfo ,  } = state;
    const addToWishlist = async ()=>{
    // const existItem = state.cart.cartItems.find((x:any) => x._id === product._id);
    // const quantity = existItem ? existItem.quantity + 1 : 1;
    // const { data } = await axios.get(`/api/products/${product._id}`);
    // if (data.countInStock < quantity) {
    //   window.alert('Sorry. Product is out of stock');
    //   return;
    // }
    // await dispatch({ type: 'WISHLIST_ADD_ITEM', payload: { ...product, quantity } });
    // setLoading(false)
    };
    const { data  } = (0,_framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP)();
    const removeItem = (0,_framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { openModal , setModalView  } = (0,_components_ui__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // @ts-ignore Wishlist is not always enabled
    const itemInWishlist = data?.items?.find(// @ts-ignore Wishlist is not always enabled
    (item)=>item.product_id === Number(productId) && item.variant_id === Number(variant.id)
    );
    const handleWishlistChange = async (e)=>{
        e.preventDefault();
        if (loading) return;
        // A login is required before adding an item to the wishlist
        if (!customerInfo) {
            setModalView("LOGIN_VIEW");
            return openModal();
        }
        setLoading(true);
        try {
            if (itemInWishlist) {
                await removeItem({
                    id: itemInWishlist.id
                });
            } else {
                addToWishlist();
            }
            setLoading(false);
        } catch (err) {
            setLoading(false);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        "aria-label": "Add to wishlist",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().root), className),
        onClick: handleWishlistChange,
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().icon), {
                [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().loading)]: loading,
                [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().inWishlist)]: itemInWishlist
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WishlistButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 12633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export emptyHook */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function emptyHook(options) {
    const useEmptyHook = async ({ id  })=>{
        return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async function() {
            return Promise.resolve();
        }, []);
    };
    return useEmptyHook;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (emptyHook);


/***/ }),

/***/ 90774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports fetcher, extendHook */
const defaultOpts = {};
const fetcher = ()=>{
    return null;
};
function extendHook(customFetcher, // swrOptions?: SwrOptions<Wishlist | null, UseWishlistInput>
swrOptions) {
    const useWishlist = ({ includeProducts  } = {})=>{
        return {
            data: null
        };
    };
    useWishlist.extend = extendHook;
    return useWishlist;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extendHook(fetcher));


/***/ })

};
;