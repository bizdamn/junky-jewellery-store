exports.id = 4437;
exports.ids = [4437];
exports.modules = {

/***/ 39264:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ProductCard_root__HqXTt",
	"productImage": "ProductCard_productImage__nbfNy",
	"header": "ProductCard_header__qlwPO",
	"name": "ProductCard_name__YciuQ",
	"price": "ProductCard_price___JB_V",
	"wishlistButton": "ProductCard_wishlistButton__jS6Lf",
	"imageContainer": "ProductCard_imageContainer__G6HoR",
	"simple": "ProductCard_simple__HMkuK",
	"slim": "ProductCard_slim__nclhL"
};


/***/ }),

/***/ 44437:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(39264);
/* harmony import */ var _ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_wishlist_WishlistButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(72354);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(79747);
/* harmony import */ var _ProductTag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(10343);
/* harmony import */ var _ProductTag_CustomProductTag__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_wishlist_WishlistButton__WEBPACK_IMPORTED_MODULE_6__]);
_components_wishlist_WishlistButton__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const placeholderImg = "/product-img-placeholder.svg";
const ProductCard = ({ product , imgProps , className , noNameTag =false , variant ="default" ,  })=>{
    const { price  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP)({
        amount: product.price.value,
        baseAmount: product.price.retailPrice,
        currencyCode: product.price.currencyCode
    });
    const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_1___default()((_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().root), {
        [(_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().slim)]: variant === "slim",
        [(_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().simple)]: variant === "simple"
    }, className);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        href: `/product/${product.slug}`,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
            className: rootClassName,
            "aria-label": product.name,
            children: [
                variant === "slim" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().header),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: product.name
                            })
                        }),
                        product?.images && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                quality: "85",
                                src: `/assets${product.images[0].url}` || placeholderImg,
                                alt: product.name || "Product Image",
                                height: 320,
                                width: 320,
                                layout: "fixed",
                                ...imgProps
                            })
                        })
                    ]
                }),
                variant === "simple" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        process.env.COMMERCE_WISHLIST_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_wishlist_WishlistButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().wishlistButton),
                            productId: product.id,
                            variant: product.variants[0]
                        }),
                        !noNameTag && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().header),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().name),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: product.name
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().price),
                                    children: `${product.price?.value} ${product.price?.currencyCode}`
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().imageContainer),
                            children: product?.images && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    alt: product.name || "Product Image",
                                    className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().productImage),
                                    src: `/assets${product.images[0].url}` || placeholderImg,
                                    height: 540,
                                    width: 540,
                                    quality: "85",
                                    layout: "responsive",
                                    ...imgProps
                                })
                            })
                        })
                    ]
                }),
                variant === "default" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        process.env.COMMERCE_WISHLIST_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_wishlist_WishlistButton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().wishlistButton),
                            productId: product.id,
                            variant: product.variants[0]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().imageContainer),
                            children: product?.images && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    alt: product.name || "Product Image",
                                    className: (_ProductCard_module_css__WEBPACK_IMPORTED_MODULE_5___default().productImage),
                                    src: `/assets${product.images[0].url}` || placeholderImg,
                                    height: 540,
                                    width: 540,
                                    quality: "85",
                                    layout: "responsive",
                                    ...imgProps
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductTag__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            name: product.name,
                            price: `${product.price?.value}`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductTag_CustomProductTag__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            name: product.name,
                            price: `${product.price?.value}`,
                            comparePrice: `${product.price?.comparePrice}`
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 49189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_1__);


const CustomProductTag = ({ name , price , comparePrice , className ="" , fontSize =32 ,  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_1___default()), {
                component: "h2",
                sx: {
                    fontWeight: 700
                },
                children: name
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_1___default()), {
                component: "p",
                sx: {
                    color: "	#1564a2",
                    marginTop: 2
                },
                children: [
                    "\u20B9",
                    price,
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("del", {
                        children: comparePrice ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                "\u20B9",
                                comparePrice
                            ]
                        }) : null
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomProductTag);


/***/ })

};
;