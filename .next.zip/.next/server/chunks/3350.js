"use strict";
exports.id = 3350;
exports.ids = [3350];
exports.modules = {

/***/ 33350:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const shippingZoneSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    storeID: {
        type: String,
        required: true
    },
    shippingZones: [
        {
            zoneName: {
                type: String,
                required: true
            },
            countries: {
                type: Array,
                required: true
            },
            rate: [
                {
                    rateName: {
                        type: String,
                        required: true
                    },
                    price: {
                        type: String,
                        required: true
                    },
                    conditions: [
                        {
                            conditionName: {
                                type: String,
                                required: true
                            },
                            min: {
                                type: Number,
                                required: true
                            },
                            max: {
                                type: Number,
                                required: true
                            }
                        }
                    ]
                }
            ]
        }
    ]
}, {
    timestamps: true
});
const ShippingZone = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.ShippingZone) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("ShippingZone", shippingZoneSchema, "shipping");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShippingZone);


/***/ })

};
;