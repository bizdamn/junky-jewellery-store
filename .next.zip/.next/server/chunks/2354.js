exports.id = 2354;
exports.ids = [2354];
exports.modules = {

/***/ 9047:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "WishlistButton_root__crSyc",
	"icon": "WishlistButton_icon__J690_",
	"loading": "WishlistButton_loading__BcgF9",
	"inWishlist": "WishlistButton_inWishlist__uwrZI"
};


/***/ }),

/***/ 2354:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3968);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(505);
/* harmony import */ var _framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(774);
/* harmony import */ var _framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2633);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9047);
/* harmony import */ var _WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _utils_DataStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2767);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__]);
_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const WishlistButton = ({ productId , variant , className , ...props })=>{
    const { state , dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_utils_DataStore__WEBPACK_IMPORTED_MODULE_3__/* .DataStore */ .K);
    const { customerInfo ,  } = state;
    const addToWishlist = async ()=>{
    // const existItem = state.cart.cartItems.find((x:any) => x._id === product._id);
    // const quantity = existItem ? existItem.quantity + 1 : 1;
    // const { data } = await axios.get(`/api/products/${product._id}`);
    // if (data.countInStock < quantity) {
    //   window.alert('Sorry. Product is out of stock');
    //   return;
    // }
    // await dispatch({ type: 'WISHLIST_ADD_ITEM', payload: { ...product, quantity } });
    // setLoading(false)
    };
    const { data  } = (0,_framework_wishlist_use_wishlist__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP)();
    const removeItem = (0,_framework_wishlist_use_remove_item__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { openModal , setModalView  } = (0,_components_ui__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // @ts-ignore Wishlist is not always enabled
    const itemInWishlist = data?.items?.find(// @ts-ignore Wishlist is not always enabled
    (item)=>item.product_id === Number(productId) && item.variant_id === Number(variant.id)
    );
    const handleWishlistChange = async (e)=>{
        e.preventDefault();
        if (loading) return;
        // A login is required before adding an item to the wishlist
        if (!customerInfo) {
            setModalView("LOGIN_VIEW");
            return openModal();
        }
        setLoading(true);
        try {
            if (itemInWishlist) {
                await removeItem({
                    id: itemInWishlist.id
                });
            } else {
                addToWishlist();
            }
            setLoading(false);
        } catch (err) {
            setLoading(false);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        "aria-label": "Add to wishlist",
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().root), className),
        onClick: handleWishlistChange,
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().icon), {
                [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().loading)]: loading,
                [(_WishlistButton_module_css__WEBPACK_IMPORTED_MODULE_7___default().inWishlist)]: itemInWishlist
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WishlistButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export emptyHook */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function emptyHook(options) {
    const useEmptyHook = async ({ id  })=>{
        return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(async function() {
            return Promise.resolve();
        }, []);
    };
    return useEmptyHook;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (emptyHook);


/***/ }),

/***/ 774:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports fetcher, extendHook */
const defaultOpts = {};
const fetcher = ()=>{
    return null;
};
function extendHook(customFetcher, // swrOptions?: SwrOptions<Wishlist | null, UseWishlistInput>
swrOptions) {
    const useWishlist = ({ includeProducts  } = {})=>{
        return {
            data: null
        };
    };
    useWishlist.extend = extendHook;
    return useWishlist;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extendHook(fetcher));


/***/ })

};
;