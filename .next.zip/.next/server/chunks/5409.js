"use strict";
exports.id = 5409;
exports.ids = [5409];
exports.modules = {

/***/ 25409:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const supplierProductSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    supplierID: {
        type: String,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
        required: false
    },
    location: {
        type: String,
        required: false
    },
    slug: {
        type: String,
        required: true,
        unique: true
    },
    status: {
        type: Boolean,
        required: true
    },
    liked: {
        type: Boolean,
        required: true
    },
    added: {
        type: Boolean,
        required: true
    },
    isFeatured: {
        type: Boolean,
        required: true
    },
    isDeleted: {
        type: Boolean,
        required: true
    },
    categories: {
        type: String,
        required: false
    },
    features: {
        type: Array,
        required: false
    },
    image: {
        type: Array,
        required: false
    },
    reviews: {
        customer: {
            type: String,
            required: false
        },
        name: {
            type: String,
            required: false
        },
        rating: {
            type: Number,
            required: false
        },
        comment: {
            type: String,
            required: false
        }
    },
    pricing: {
        type: Object,
        required: false
    },
    options: {
        type: Object,
        required: false
    },
    rating: {
        type: Number,
        required: false,
        default: 0
    },
    numReviews: {
        type: Number,
        required: false,
        default: 0
    },
    size: {
        type: Object,
        required: false
    },
    sku: {
        type: String,
        required: false,
        unique: true
    },
    barcode: {
        type: String,
        required: false,
        unique: true
    },
    inventory: {
        type: Number,
        required: true,
        default: 0
    }
}, {
    timestamps: true
});
const SupplierProduct = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.SupplierProduct) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("SupplierProduct", supplierProductSchema, "supplierProducts");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SupplierProduct);


/***/ })

};
;