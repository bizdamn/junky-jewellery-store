"use strict";
exports.id = 9441;
exports.ids = [9441];
exports.modules = {

/***/ 69441:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ commerce)
});

;// CONCATENATED MODULE: ./framework/commerce/api/operations.ts
const noop = ()=>{
    throw new Error("Not implemented");
};
const OPERATIONS = [
    "login",
    "getAllPages",
    "getPage",
    "getSiteInfo",
    "getCustomerWishlist",
    "getAllProductPaths",
    "getAllProducts",
    "getProduct", 
];
const defaultOperations = OPERATIONS.reduce((ops, k)=>{
    ops[k] = noop;
    return ops;
}, {});

;// CONCATENATED MODULE: ./framework/commerce/api/index.ts

class CommerceAPICore {
    constructor(provider){
        this.provider = provider;
    }
    getConfig(userConfig = {}) {
        return Object.entries(userConfig).reduce((cfg, [key, value])=>Object.assign(cfg, {
                [key]: value
            })
        , {
            ...this.provider.config
        });
    }
    setConfig(newConfig) {
        Object.assign(this.provider.config, newConfig);
    }
}
function getCommerceApi(customProvider) {
    const commerce = Object.assign(new CommerceAPICore(customProvider), defaultOperations);
    const ops = customProvider.operations;
    OPERATIONS.forEach((k)=>{
        const op = ops[k];
        if (op) {
            commerce[k] = op({
                commerce
            });
        }
    });
    return commerce;
}
function getEndpoint(commerce, context) {
    const cfg = commerce.getConfig(context.config);
    return function apiHandler(req, res) {
        return context.handler({
            req,
            res,
            commerce,
            config: cfg,
            handlers: context.handlers,
            options: context.options ?? {}
        });
    };
}
const createEndpoint = (endpoint)=>(commerce, context)=>{
        return getEndpoint(commerce, {
            ...endpoint,
            ...context
        });
    }
;

;// CONCATENATED MODULE: ./framework/commerce/utils/errors.ts
class CommerceError extends Error {
    constructor({ message , code , errors  }){
        const error = message ? {
            message,
            ...code ? {
                code
            } : {}
        } : errors[0];
        super(error.message);
        this.errors = message ? [
            error
        ] : errors;
        if (error.code) this.code = error.code;
    }
}
// Used for errors that come from a bad implementation of the hooks
class ValidationError extends (/* unused pure expression or super */ null && (CommerceError)) {
    constructor(options){
        super(options);
        this.code = "validation_error";
    }
}
class FetcherError extends CommerceError {
    constructor(options){
        super(options);
        this.status = options.status;
    }
}

// EXTERNAL MODULE: external "@vercel/fetch"
var fetch_ = __webpack_require__(33666);
var fetch_default = /*#__PURE__*/__webpack_require__.n(fetch_);
;// CONCATENATED MODULE: ./framework/local/api/utils/fetch.ts

/* harmony default export */ const fetch = (fetch_default()());

;// CONCATENATED MODULE: ./framework/local/api/utils/fetch-local.ts


const fetchGraphqlApi = (getConfig)=>async (query, { variables , preview  } = {}, fetchOptions)=>{
        const config = getConfig();
        const res = await fetch(config.commerceUrl, {
            ...fetchOptions,
            method: "POST",
            headers: {
                ...fetchOptions?.headers,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                query,
                variables
            })
        });
        const json = await res.json();
        if (json.errors) {
            throw new FetcherError({
                errors: json.errors ?? [
                    {
                        message: "Failed to fetch for API"
                    }
                ],
                status: res.status
            });
        }
        return {
            data: json.data,
            res
        };
    }
;
/* harmony default export */ const fetch_local = (fetchGraphqlApi);

;// CONCATENATED MODULE: ./framework/local/api/operations/get-all-pages.ts
function getAllPagesOperation() {
    function getAllPages({ config , preview  }) {
        return Promise.resolve({
            pages: []
        });
    }
    return getAllPages;
};

;// CONCATENATED MODULE: ./framework/local/api/operations/get-page.ts
function getPageOperation() {
    function getPage() {
        return Promise.resolve({});
    }
    return getPage;
};

;// CONCATENATED MODULE: ./framework/local/api/operations/get-site-info.ts
function getSiteInfoOperation({}) {
    function getSiteInfo({ query , variables , config: cfg  } = {}) {
        return Promise.resolve({
            categories: [
                {
                    id: "new-arrivals",
                    name: "New Arrivals",
                    slug: "new-arrivals",
                    path: "/new-arrivals"
                },
                {
                    id: "featured",
                    name: "Featured",
                    slug: "featured",
                    path: "/featured"
                }, 
            ],
            brands: []
        });
    }
    return getSiteInfo;
};

;// CONCATENATED MODULE: ./framework/local/api/operations/get-customer-wishlist.ts
function getCustomerWishlistOperation() {
    function getCustomerWishlist() {
        return {
            wishlist: {}
        };
    }
    return getCustomerWishlist;
};

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(52167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./framework/local/api/operations/get-all-product-paths.ts

async function getAllProductPathsOperation() {
    async function getAllProductPaths() {
        const { data  } = await external_axios_default().post("/api/products", {
            _id: process.env.STORE_OBJECT_ID
        });
        return Promise.resolve({
            products: data.physicalProducts.map(({ path  })=>({
                    path
                })
            )
        });
    }
    return getAllProductPaths;
};

;// CONCATENATED MODULE: ./framework/local/api/operations/get-all-products.ts

function getAllProductsOperation({ commerce  }) {
    async function getAllProducts({ query ="" , variables , config  } = {}) {
        const { data  } = await external_axios_default().post("/api/products", {
            _id: process.env.STORE_OBJECT_ID
        });
        return {
            products: data.physicalProducts
        };
    }
    return getAllProducts;
};

;// CONCATENATED MODULE: ./framework/local/api/operations/get-product.ts

function getProductOperation({ commerce  }) {
    async function getProduct({ query ="" , variables , config  } = {}) {
        const { data  } = await external_axios_default().post("/api/products/id", {
            slug: variables.slug
        });
        return {
            product: data.physicalProducts
        };
    }
    return getProduct;
};

;// CONCATENATED MODULE: ./framework/local/api/index.ts









const config = {
    commerceUrl: "",
    apiToken: "",
    cartCookie: "",
    customerCookie: "",
    cartCookieMaxAge: 2592000,
    fetch: fetch_local(()=>api_getCommerceApi().getConfig()
    )
};
const operations = {
    getAllPages: getAllPagesOperation,
    getPage: getPageOperation,
    getSiteInfo: getSiteInfoOperation,
    getCustomerWishlist: getCustomerWishlistOperation,
    getAllProductPaths: getAllProductPathsOperation,
    getAllProducts: getAllProductsOperation,
    getProduct: getProductOperation
};
const provider = {
    config,
    operations
};
function api_getCommerceApi(customProvider = provider) {
    return getCommerceApi(customProvider);
}

;// CONCATENATED MODULE: ./lib/api/commerce.ts

/* harmony default export */ const commerce = (api_getCommerceApi());


/***/ })

};
;