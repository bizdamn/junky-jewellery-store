"use strict";
exports.id = 7765;
exports.ids = [7765];
exports.modules = {

/***/ 7765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ TextEditor)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);



const QuillNoSSRWrapper = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\admin\\ui\\TextEditor.jsx -> " + "react-quill"
        ]
    },
    ssr: false,
    loading: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            children: "Loading..."
        })
});
const modules = {
    toolbar: [
        [
            {
                header: "1"
            },
            {
                header: "2"
            },
            {
                font: []
            }
        ],
        [
            {
                size: []
            }
        ],
        [
            "bold",
            "italic",
            "underline",
            "strike",
            "blockquote"
        ],
        [
            {
                list: "ordered"
            },
            {
                list: "bullet"
            },
            {
                indent: "-1"
            },
            {
                indent: "+1"
            }, 
        ],
        [
            "link",
            "image",
            "video"
        ],
        [
            "clean"
        ], 
    ],
    clipboard: {
        // toggle to add extra line breaks when pasting HTML:
        matchVisual: false
    }
};
/*
 * Quill editor formats
 * See https://quilljs.com/docs/formats/
 */ const formats = [
    "header",
    "font",
    "size",
    "bold",
    "italic",
    "underline",
    "strike",
    "blockquote",
    "list",
    "bullet",
    "indent",
    "link",
    "image",
    "video", 
];
function TextEditor({ text , setText  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(QuillNoSSRWrapper, {
        value: text,
        onChange: setText,
        modules: modules,
        formats: formats,
        theme: "snow"
    });
};


/***/ })

};
;