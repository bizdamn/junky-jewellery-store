"use strict";
exports.id = 3417;
exports.ids = [3417];
exports.modules = {

/***/ 83417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const digitalProductSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    storeID: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    path: {
        type: String,
        required: true,
        unique: true
    },
    slug: {
        type: String,
        required: true,
        unique: true
    },
    price: {
        value: {
            type: String,
            required: false
        },
        currencyCode: {
            type: String,
            required: false
        },
        comparePrice: {
            type: String,
            required: false
        },
        costPerItem: {
            type: String,
            required: false
        }
    },
    listPrice: {
        type: Number,
        required: false
    },
    descriptionHtml: {
        type: String,
        required: false
    },
    images: {
        type: Array,
        required: false
    },
    variants: {
        type: Array,
        required: false
    },
    options: {
        type: Array,
        required: false
    },
    status: {
        type: Boolean,
        required: true
    },
    isFeatured: {
        type: Boolean,
        required: true
    },
    isDeleted: {
        type: Boolean,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    categories: {
        type: Array,
        required: false
    },
    features: {
        type: Array,
        required: false
    },
    reviews: {
        customer: {
            type: String,
            required: false
        },
        name: {
            type: String,
            required: false
        },
        rating: {
            type: Number,
            required: false
        },
        comment: {
            type: String,
            required: false
        }
    },
    rating: {
        type: Number,
        required: false,
        default: 0
    },
    digitalAccessType: {
        type: String,
        required: false
    }
}, {
    timestamps: true
});
const DigitalProduct = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.DigitalProduct) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("DigitalProduct", digitalProductSchema, "digitalProducts");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DigitalProduct);


/***/ })

};
;