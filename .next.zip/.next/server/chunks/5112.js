"use strict";
exports.id = 5112;
exports.ids = [5112];
exports.modules = {

/***/ 5112:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const storeSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    storeName: {
        type: String,
        required: false,
        unique: true
    },
    storeLink: {
        type: String,
        required: false,
        unique: true
    },
    name: {
        type: String,
        required: false
    },
    email: {
        type: String,
        required: false,
        unique: true
    },
    phone: {
        type: Number,
        required: false
    },
    verified: {
        type: Boolean,
        required: false,
        default: false
    },
    plan: {
        type: String,
        required: false,
        default: "Basic"
    },
    password: {
        type: String,
        required: false
    },
    companyName: {
        type: String,
        required: false
    },
    title: {
        type: String,
        required: false
    },
    metatitle: {
        type: String,
        required: false
    },
    metadescription: {
        type: String,
        required: false
    },
    // gst: { type: String, required: false },
    // logo: { type: String, required: false },
    bio: {
        type: String,
        required: false
    },
    ceo: {
        type: String,
        required: false
    },
    about: {
        type: String,
        required: false
    },
    // languages: { type: Array, required: false, default: ['eng'] },
    categories: {
        type: Array,
        required: false,
        default: []
    },
    // taxes: { type: Object, required: false },
    address: {
        addressLine1: {
            type: String,
            required: false
        },
        addressLine2: {
            type: String,
            required: false
        },
        city: {
            type: String,
            required: false
        },
        state: {
            type: String,
            required: false
        },
        pinCode: {
            type: Number,
            required: false
        },
        country: {
            type: String,
            required: false
        }
    },
    storeDetails: {
        storeIndustry: {
            type: String,
            required: false
        },
        storeAudience: {
            type: String,
            required: false
        },
        companyName: {
            type: String,
            required: false
        }
    },
    paymentProviders: {
        CodAvailable: {
            type: Boolean,
            required: false,
            default: true
        },
        razorpay: {
            type: Object,
            required: false
        }
    },
    checkout: {
        checkoutCustomerAccount: {
            type: String,
            required: false,
            default: "required"
        },
        checkoutCustomerContact: {
            type: String,
            required: false,
            default: "phoneEmail"
        },
        marketingConsent: {
            emailMarketingSubscribe: {
                type: Boolean,
                required: false,
                default: true
            },
            smsMarketingSubscribe: {
                type: Boolean,
                required: false,
                default: false
            }
        },
        formOptions: {
            lastName: {
                type: String,
                required: false,
                default: "hidden"
            },
            companyName: {
                type: String,
                required: false,
                default: "hidden"
            },
            addressLine2: {
                type: String,
                required: false,
                default: "hidden"
            },
            shippingAddressPhone: {
                type: String,
                required: false,
                default: "hidden"
            }
        }
    },
    taxes: {
        allPricesIncludeTaxes: {
            type: Boolean,
            required: false,
            default: false
        },
        shippingRatesTax: {
            type: Boolean,
            required: false,
            default: false
        },
        digitalProductVAT: {
            type: Boolean,
            required: false,
            default: false
        }
    },
    policies: {
        RefundPolicyHtml: {
            type: Boolean,
            required: false,
            default: false
        },
        PrivacyPolicyHtml: {
            type: Boolean,
            required: false,
            default: false
        },
        ShippingPolicyHtml: {
            type: Boolean,
            required: false,
            default: false
        },
        TermsOfServiceHtml: {
            type: Boolean,
            required: false,
            default: false
        }
    }
}, {
    timestamps: true
});
const Store = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Store) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Store", storeSchema, "stores");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Store);


/***/ })

};
;