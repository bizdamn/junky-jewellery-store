"use strict";
exports.id = 4615;
exports.ids = [4615];
exports.modules = {

/***/ 4615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const customerSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    storeID: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: false
    },
    orders_count: {
        type: Number,
        required: false,
        default: 0
    },
    tax_exempt: {
        type: Boolean,
        required: false,
        default: false
    },
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    addresses: [
        {
            addressLine1: {
                type: String,
                required: false
            },
            addressLine2: {
                type: String,
                required: false
            },
            city: {
                type: String,
                required: false
            },
            country: {
                type: String,
                required: false
            },
            state: {
                type: String,
                required: false
            },
            pinCode: {
                type: Number,
                required: false
            }
        }
    ],
    paymentMethods: [
        {
            type: {
                type: String,
                required: false
            }
        }
    ]
}, {
    timestamps: true
});
const Customer = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.Customer) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("Customer", customerSchema, "customers");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Customer);


/***/ })

};
;