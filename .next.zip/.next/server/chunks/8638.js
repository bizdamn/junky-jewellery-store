"use strict";
exports.id = 8638;
exports.ids = [8638];
exports.modules = {

/***/ 18638:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(11185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const productSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({
    storeID: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    vendor: {
        type: String,
        required: false
    },
    path: {
        type: String,
        required: true,
        unique: true
    },
    slug: {
        type: String,
        required: true,
        unique: true
    },
    price: {
        value: {
            type: String,
            required: false
        },
        currencyCode: {
            type: String,
            required: false
        },
        comparePrice: {
            type: String,
            required: false
        },
        costPerItem: {
            type: String,
            required: false
        }
    },
    listPrice: {
        type: Number,
        required: false
    },
    descriptionHtml: {
        type: String,
        required: false
    },
    detailsHtml: {
        type: String,
        required: false
    },
    images: {
        type: Array,
        required: false
    },
    documents: {
        type: Array,
        required: false
    },
    variants: {
        type: Array,
        required: false
    },
    options: {
        type: Array,
        required: false
    },
    status: {
        type: Boolean,
        required: true
    },
    isFeatured: {
        type: Boolean,
        required: true
    },
    isDeleted: {
        type: Boolean,
        required: true
    },
    type: {
        type: String,
        required: true
    },
    categories: {
        type: Array,
        required: false
    },
    features: {
        type: Array,
        required: false
    },
    reviews: {
        customer: {
            type: String,
            required: false
        },
        name: {
            type: String,
            required: false
        },
        rating: {
            type: Number,
            required: false
        },
        comment: {
            type: String,
            required: false
        }
    },
    rating: {
        type: Number,
        required: false,
        default: 0
    },
    sku: {
        type: String,
        required: false
    },
    barcode: {
        type: String,
        required: false
    },
    inventory: {
        type: Number,
        required: true,
        default: 0
    },
    size: {
        type: Object,
        required: false
    }
}, {
    timestamps: true
});
const PhysicalProduct = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.PhysicalProduct) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model("PhysicalProduct", productSchema, "physicalProducts");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PhysicalProduct);


/***/ })

};
;